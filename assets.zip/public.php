<?php

class System {
    
}

print_r($_REQUEST);