<?php
declare(strict_types=1);

require_once __DIR__ . '/HtmlNode.php';
require_once __DIR__ . '/HtmlFragment.php';
require_once __DIR__ . '/HtmlDocument.php';
require_once __DIR__ . '/RatioSerial.php';

final class HtmlTagCrawler
{
    public const array DEFAULT_URIS = [
        'https://html.spec.whatwg.org/multipage/indices.html',
        'https://html.spec.whatwg.org/multipage/rendering.html',
    ];

    private const string TAG_RE = '/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/';
    private const array CSS_NOISE = ['from' => true, 'to' => true];

    /** Spec lists "empty" children for these, but they still need a closing tag. */
    private const array NOT_VOID = ['iframe' => true, 'template' => true, 'selectedcontent' => true];

    /** @var array<string, array{desc: string, void: ?bool, src: array<string, true>}> */
    private array $tags = [];

    /** @var array<string, true> */
    private array $seen = [];

    /** @var list<string> */
    public private(set) array $log = [];

    /** @var array{css: array<string, string>, js: array<string, string>} source key => raw text */
    public private(set) array $assets = ['css' => [], 'js' => []];

    public function __construct(
        private readonly int $depth = 1,
        private readonly int $timeout = 20,
    ) {}

    // ---------- Crawl ----------

    /** @param iterable<string> $uris */
    public function crawl(iterable $uris): self
    {
        // Parse the sources with NO aliases active, so <link> etc. keep their real names.
        $savedAlias = $GLOBALS[HtmlFragment::ALIAS_KEY] ?? null;
        $savedVoid  = $GLOBALS[HtmlFragment::VOID_KEY] ?? null;
        unset($GLOBALS[HtmlFragment::ALIAS_KEY], $GLOBALS[HtmlFragment::VOID_KEY]);

        try {
            foreach ($uris as $uri) {
                $this->visit(trim($uri), 0);
            }
        } finally {
            if ($savedAlias !== null) {
                $GLOBALS[HtmlFragment::ALIAS_KEY] = $savedAlias;
            }
            if ($savedVoid !== null) {
                $GLOBALS[HtmlFragment::VOID_KEY] = $savedVoid;
            }
        }
        return $this;
    }

    private function visit(string $uri, int $level): void
    {
        if ($uri === '' || isset($this->seen[$uri])) {
            return;
        }
        $this->seen[$uri] = true;

        $res = $this->fetch($uri);
        if ($res === null) {
            $this->log[] = "FAIL   $uri";
            return;
        }
        [$body, $type] = $res;
        $before = count($this->tags);

        if (str_contains($type, 'javascript') || preg_match('~\.m?js(?:[?#]|$)~i', $uri) === 1) {
            $this->keep('js', $uri, $body);
            $this->log[] = "JS     $uri";
            return;
        }

        if (str_contains($type, 'text/css') || preg_match('~\.css(?:[?#]|$)~i', $uri) === 1) {
            $this->keep('css', $uri, $body);
            $this->readCss($body, $uri);
            $this->log[] = sprintf('CSS    %s (+%d tags)', $uri, count($this->tags) - $before);
            return;
        }

        $doc = new HtmlDocument($body);
        unset($body);
        $links = [];
        $n     = 0;

        foreach (self::walk($doc->roots) as $node) {
            if (!$node instanceof HtmlFragment) {
                continue;
            }
            $name = $node->tagname;
            $cls  = $node->attrs['class'] ?? '';

            if ($name === 'table') {
                $this->readTable($node, $uri);
            } elseif ($name === 'style' || preg_match('/(?:^|\s)css(?:\s|$)/', $cls) === 1) {
                $raw = self::textOf($node, false);
                $this->keep('css', $uri . '#style' . (++$n), $raw);
                $this->readCss($raw, $uri);
            } elseif ($name === 'script') {
                $srcAttr = $node->attrs['src'] ?? '';
                if ($srcAttr !== '') {
                    $links[] = self::resolve($uri, $srcAttr);
                } else {
                    $this->keep('js', $uri . '#script' . (++$n), self::textOf($node, false));
                }
            } elseif ($name === 'link'
                && preg_match('/(?:^|\s)stylesheet(?:\s|$)/i', $node->attrs['rel'] ?? '') === 1
                && ($node->attrs['href'] ?? '') !== '') {
                $links[] = self::resolve($uri, $node->attrs['href']);
            }
        }
        $this->log[] = sprintf('HTML   %s (+%d tags)', $uri, count($this->tags) - $before);

        if ($level < $this->depth) {
            foreach ($links as $link) {
                $this->visit($link, $level + 1);
            }
        }
    }

    // ---------- Fetching ----------

    /** @return array{0: string, 1: string}|null  [body, content-type] */
    private function fetch(string $uri): ?array
    {
        if (!preg_match('~^https?://~i', $uri)) {
            $path = preg_replace('~^file://~i', '', $uri);
            $body = is_file($path) ? file_get_contents($path) : false;
            return $body === false ? null : [$body, ''];
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($uri);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 5,
                CURLOPT_TIMEOUT        => $this->timeout,
                CURLOPT_ENCODING       => '',
                CURLOPT_USERAGENT      => 'HtmlTagCrawler/1.0',
                CURLOPT_PROTOCOLS      => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            ]);
            $body = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $type = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
            return ($body === false || $code >= 400) ? null : [(string) $body, $type];
        }

        $ctx  = stream_context_create(['http' => [
            'timeout' => $this->timeout,
            'header'  => "User-Agent: HtmlTagCrawler/1.0\r\n",
        ]]);
        $body = @file_get_contents($uri, false, $ctx);
        return $body === false ? null : [$body, ''];
    }

    private static function resolve(string $base, string $rel): string
    {
        if (preg_match('~^[a-z][a-z0-9+.-]*:~i', $rel)) {
            return $rel;
        }
        $b = parse_url($base);
        if (!is_array($b) || !isset($b['host'])) {
            return dirname($base) . '/' . $rel;            // local file base
        }
        $scheme = $b['scheme'] ?? 'https';
        if (str_starts_with($rel, '//')) {
            return "$scheme:$rel";
        }
        $auth = $scheme . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
        $path = str_starts_with($rel, '/')
            ? $rel
            : preg_replace('~[^/]*$~', '', $b['path'] ?? '/') . $rel;

        [$path, $query] = array_pad(explode('?', $path, 2), 2, null);
        $out = [];
        foreach (explode('/', $path) as $seg) {
            if ($seg === '..') {
                array_pop($out);
            } elseif ($seg !== '.') {
                $out[] = $seg;
            }
        }
        return $auth . implode('/', $out) . ($query !== null ? "?$query" : '');
    }

    // ---------- Tree helpers (built on HtmlDocument / HtmlFragment) ----------

    /** Pre-order walk over a tree of HtmlNodes. */
    private static function walk(array $nodes): Generator
    {
        foreach ($nodes as $node) {
            yield $node;
            if ($node instanceof HtmlFragment) {
                yield from self::walk($node->children());
            }
        }
    }

    private static function textOf(HtmlFragment $f, bool $decode = true): string
    {
        $t = '';
        foreach (self::walk($f->children()) as $n) {
            if ($n instanceof HtmlText) {
                $t .= $n->text;
            }
        }
        return $decode ? html_entity_decode($t, ENT_QUOTES | ENT_HTML5, 'UTF-8') : $t;
    }

    // ---------- Element table (Element | Description | ... | Children) ----------

    private function readTable(HtmlFragment $table, string $src): void
    {
        // Spec markup omits </td>, </th>, </tr>, so rows/cells are split on their START
        // tags in document order instead of relying on the tree nesting.
        $rows = [];
        $r = $c = -1;
        foreach (self::walk($table->children()) as $n) {
            if ($n instanceof HtmlText) {
                if ($r >= 0 && $c >= 0) {
                    $rows[$r][$c] .= $n->text;
                }
                continue;
            }
            if ($n->tagname === 'tr') {
                $rows[] = [];
                $r++;
                $c = -1;
            } elseif ($n->tagname === 'td' || $n->tagname === 'th') {
                if ($r < 0) {
                    $rows[] = [];
                    $r = 0;
                }
                $rows[$r][] = '';
                $c = count($rows[$r]) - 1;
            }
        }
        if (!$rows) {
            return;
        }

        $norm   = static fn(string $s): string =>
            trim(preg_replace('/\s+/', ' ', html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        $header = array_map(static fn(string $s): string => strtolower($norm($s)), $rows[0]);
        $iName  = array_search('element', $header, true);
        $iDesc  = array_search('description', $header, true);
        $iKids  = array_search('children', $header, true);
        if ($iName === false || $iKids === false) {
            return;                                         // not the element index
        }

        for ($i = 1, $n = count($rows); $i < $n; $i++) {
            $row = $rows[$i];
            if (!isset($row[$iName])) {
                continue;
            }
            $names = [];
            preg_match_all('/[A-Za-z][A-Za-z0-9-]*/', $norm($row[$iName]), $m);
            foreach ($m[0] as $name) {
                $names[] = strtolower($name);
            }
            $desc = $iDesc !== false ? $norm($row[$iDesc] ?? '') : '';
            $void = strtolower($norm($row[$iKids] ?? '')) === 'empty';
            foreach ($names as $name) {
                $this->addTag($name, $desc, $void, $src);
            }
        }
    }

    // ---------- CSS ----------

    private function readCss(string $css, string $src): void
    {
        $css = preg_replace('~/\*.*?\*/~s', '', $css) ?? '';
        $css = preg_replace('~@[^;{}]*;~', '', $css) ?? '';       // @import, @namespace, @charset

        if (!preg_match_all('~([^{}]+)\{[^{}]*\}~', $css, $m)) {
            return;
        }
        foreach ($m[1] as $sel) {
            $sel = trim($sel);
            if ($sel === '' || $sel[0] === '@') {
                continue;
            }
            $sel = preg_replace('~"[^"]*"|\'[^\']*\'~', '', $sel);          // strings
            $sel = preg_replace('~\[[^\]]*\]~', '', $sel);                   // [attr=value]
            do {                                                             // :is(a, b) keeps its tags
                $sel = preg_replace('~:(?:is|where|matches|-webkit-any|-moz-any)\(([^()]*)\)~i', ' $1 ', $sel, -1, $count);
            } while ($count > 0);
            $sel = preg_replace('~::?[\w-]+(\((?:[^()]|(?1))*\))?~', '', $sel); // :hover, ::before, :not(..)
            $sel = preg_replace('~[.#][\w-]+~', '', $sel);                   // .class, #id
            $sel = preg_replace('~[\w*-]*\|~', '', $sel);                    // ns|tag

            if (!preg_match_all('~(?<![\w-])[a-z][a-z0-9-]*~i', $sel, $t)) {
                continue;
            }
            foreach ($t[0] as $tag) {
                $tag = strtolower($tag);
                if (preg_match(self::TAG_RE, $tag) === 1 && !isset(self::CSS_NOISE[$tag])) {
                    $this->addTag($tag, '', null, $src);
                }
            }
        }
    }

    // ---------- Registry ----------

    private function addTag(string $name, string $desc, ?bool $void, string $src): void
    {
        if (preg_match(self::TAG_RE, $name) !== 1) {
            return;
        }
        $t = &$this->tags[$name];
        $t ??= ['desc' => '', 'void' => null, 'src' => []];
        if ($t['desc'] === '' && $desc !== '') {
            $t['desc'] = $desc;
        }
        if ($void !== null) {
            $t['void'] = $void;
        }
        $t['src'][$src] = true;
    }

    /** @return list<string> */
    public function tagNames(): array
    {
        $names = array_keys($this->tags);
        sort($names);
        return $names;
    }

    /** @return array<string, true> */
    public function voidMap(): array
    {
        $out = [];
        foreach ($this->tags as $name => $t) {
            if ($t['void'] === true && !isset(self::NOT_VOID[$name])) {
                $out[$name] = true;
            }
        }
        ksort($out);
        return $out;
    }

    /**
     * Builds the alias map. Overrides win; then each tag's own name (+ capitalised form);
     * then a short PascalCase alias from the spec description (e.g. "Hyperlink") if still free.
     *
     * @param list<array{aliases: list<string>, pair: SplFixedArray}> $overrides
     * @return list<array{aliases: list<string>, pair: SplFixedArray}>
     */
    public function aliasMap(array $overrides = []): array
    {
        $map     = [];
        $claimed = [];

        foreach ($overrides as $entry) {
            $map[] = $entry;
            foreach ($entry['aliases'] as $alias) {
                $claimed[strtolower($alias)] = true;
            }
        }

        $entries = [];
        foreach ($this->tagNames() as $tag) {
            $aliases = [];
            foreach ([$tag, ucfirst($tag)] as $alias) {
                if (!isset($claimed[strtolower($alias)])) {
                    $claimed[strtolower($alias)] = true;
                    $aliases[] = $alias;
                }
            }
            $entries[$tag] = $aliases;
        }

        foreach ($entries as $tag => $aliases) {
            $alias = self::pascal($this->tags[$tag]['desc']);
            if ($alias !== null && !isset($claimed[strtolower($alias)])) {
                $claimed[strtolower($alias)] = true;
                $aliases[] = $alias;
            }
            if ($aliases) {
                $map[] = ['aliases' => $aliases, 'pair' => SplFixedArray::fromArray(['/', $tag])];
            }
        }
        return $map;
    }

    private static function pascal(string $desc): ?string
    {
        $desc  = preg_replace('~\(.*?\)|\[.*?\]~', '', $desc);
        $words = preg_split('~[^A-Za-z0-9]+~', trim($desc), -1, PREG_SPLIT_NO_EMPTY);
        if (!$words || count($words) > 2) {
            return null;
        }
        return implode('', array_map(static fn(string $w): string => ucfirst(strtolower($w)), $words));
    }

    // ---------- CSS / JS assets (one serial file per source) ----------

    private function keep(string $kind, string $key, string $text): void
    {
        if (trim($text) !== '') {
            $this->assets[$kind][$key] = $text;
        }
    }

    /** One .rsr per asset plus manifest.json (file => source). Returns [file => source]. */
    public function saveAssets(string $dir): array
    {
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new RuntimeException("Cannot create $dir");
        }
        $written = [];
        foreach ($this->assets as $kind => $items) {
            foreach ($items as $key => $text) {
                $slug = trim(preg_replace('~[^a-z0-9]+~', '-', strtolower(
                    preg_replace('~^[a-z][a-z0-9+.-]*://~i', '', $key))), '-');
                $slug = substr($slug, 0, 60);
                $file = sprintf('%s-%s-%s.rsr', $kind, $slug, substr(sha1($key), 0, 8));
                RatioSerial::save("$dir/$file", $text, $kind);
                $written[$file] = $key;
            }
        }
        file_put_contents("$dir/manifest.json",
            json_encode($written, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return $written;
    }

    // ---------- Cache file ----------

    public function export(string $path, array $overrides = []): void
    {
        $lines = [
            '<?php',
            '// Generated by HtmlTagCrawler on ' . gmdate('c'),
        ];
        foreach (array_keys($this->seen) as $uri) {
            $lines[] = '// source: ' . str_replace(["\r", "\n"], '', $uri);
        }
        $lines[] = '';
        $lines[] = "\$GLOBALS['HtmlFragmentAliasMap'] = [";
        foreach ($this->aliasMap($overrides) as $e) {
            $aliases = implode(', ', array_map(static fn($a) => var_export($a, true), $e['aliases']));
            $lines[] = sprintf(
                "    ['aliases' => [%s], 'pair' => SplFixedArray::fromArray([%s, %s])],",
                $aliases,
                var_export($e['pair'][0], true),
                var_export($e['pair'][1], true)
            );
        }
        $lines[] = '];';
        $lines[] = '';
        $voids = implode(', ', array_map(
            static fn($t) => var_export($t, true) . ' => true',
            array_keys($this->voidMap())
        ));
        if ($voids !== '') {
            $lines[] = "\$GLOBALS['HtmlFragmentVoidMap'] = [$voids];";
        }
        file_put_contents($path, implode("\n", $lines) . "\n");
    }
}