<?php
declare(strict_types=1);

ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/HtmlNode.php';
require_once __DIR__ . '/HtmlFragment.php';
require_once __DIR__ . '/HtmlDocument.php';
require_once __DIR__ . '/RatioSerial.php';
require_once __DIR__ . '/HtmlTagCrawler.php';

/*
 * CLI:
 *   php test.php                          use the cache if tags + assets exist, else crawl the defaults
 *   php test.php URI [URI ...]            crawl these URIs
 *   php test.php --list=uris.txt          one URI per line, # comments allowed
 *   php test.php --refresh                force a crawl
 *   php test.php --depth=2 --out=tags.php --assets=/path/to/assets URI ...
 * Browser:
 *   test.php?refresh=1                    force a crawl
 */
$argv ??= [];
$restIndex = 1;
$opts = PHP_SAPI === 'cli'
    ? getopt('', ['depth::', 'out::', 'list::', 'assets::', 'refresh'], $restIndex)
    : [];

$uris     = PHP_SAPI === 'cli' ? array_slice($argv, $restIndex) : [];
$depth    = (int) ($opts['depth'] ?? 1);
$out      = (string) ($opts['out'] ?? __DIR__ . '/HtmlTags.generated.php');
$assetDir = (string) ($opts['assets'] ?? __DIR__ . '/assets');
$refresh  = isset($opts['refresh']) || isset($_GET['refresh']);

if (isset($opts['list']) && is_file((string) $opts['list'])) {
    foreach (file((string) $opts['list'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line !== '' && $line[0] !== '#') {
            $uris[] = $line;
        }
    }
}

// Hand-picked aliases. They take priority over generated ones.
// (Not 'Link': that would shadow the real <link> element.)
$overrides = [
    ['aliases' => ['Bold'],   'pair' => SplFixedArray::fromArray(['/', 'b'])],
    ['aliases' => ['Italic'], 'pair' => SplFixedArray::fromArray(['/', 'i'])],
    ['aliases' => ['Anchor'], 'pair' => SplFixedArray::fromArray(['/', 'a'])],
];

// Use the cache only if the tag file AND the saved serials already exist
$useCache = !$uris && !$refresh && is_file($out) && is_file("$assetDir/manifest.json");

if ($useCache) {
    require $out;
    echo "Loaded cache: $out\n";
} else {
    $uris    = $uris ?: HtmlTagCrawler::DEFAULT_URIS;
    $crawler = (new HtmlTagCrawler($depth))->crawl($uris);

    echo "=== CRAWL LOG ===\n", implode("\n", $crawler->log), "\n";

    if (!$crawler->tagNames()) {
        fwrite(STDERR, "\nNo tags found. Check the URIs, network access, or the allow_url_fopen/curl setup.\n");
        exit(1);
    }

    $GLOBALS['HtmlFragmentAliasMap'] = $crawler->aliasMap($overrides);
    if ($crawler->voidMap()) {
        $GLOBALS['HtmlFragmentVoidMap'] = $crawler->voidMap();
    }
    $crawler->export($out, $overrides);
    echo "\nWrote $out\n";

    $files = $crawler->saveAssets($assetDir);
    printf("Saved %d serials to %s\n", count($files), $assetDir);
}

$map = $GLOBALS['HtmlFragmentAliasMap'];
echo "\n=== GLOBALS ===\n";
printf("%d alias entries, %d void elements\n", count($map), count($GLOBALS['HtmlFragmentVoidMap'] ?? []));
echo 'void: ', implode(' ', array_keys($GLOBALS['HtmlFragmentVoidMap'] ?? [])), "\n";
foreach (array_slice($map, 0, 8) as $e) {
    printf("  [%s] => ['%s', '%s']\n", implode(', ', $e['aliases']), $e['pair'][0], $e['pair'][1]);
}

$GLOBALS['hrefMap'] = [
    'home' => 'https://example.com/home',
    'docs' => 'https://example.com/docs',
];

// ---------- Demo using the generated aliases ----------
$doc = new HtmlDocument(
    '<Bold>Hello <Italic>world</Italic>! <Anchor href="home">home</Anchor></Bold>'
    . '<DIV class="x">a<BR>b<IMG src="p.png"></DIV>'
    . '<iframe src="f.html"></iframe><script>if (a < b) { x(); }</script>'
);

echo "\n=== RECONSTRUCTED HTML ===\n", $doc, "\n";
// <b>Hello <i>world</i>! <a href="https://example.com/home">home</a></b><div class="x">a<br>b<img src="p.png"></div><iframe src="f.html"></iframe><script>if (a < b) { x(); }</script>

echo "\n=== JSON (pruned) ===\n", $doc->roots[0]->toJSON(), "\n";
echo "\n=== ROUND TRIP ===\n", HtmlFragment::fromJSON($doc->roots[0]->toJSON()), "\n";
echo "\n=== SPARSE ARRAY + ALIAS ===\n", HtmlFragment::fromArray(['tagname' => 'Bold', 'text' => 'hi']), "\n";

echo "\n=== EXPLICIT HREF ===\n";
$link = new HtmlFragment('Anchor');
$link->setText('Go to docs')->href('docs');
echo $link, "\n";

echo "\n=== STREAMING ===\n";
$bytes = $doc->writeTo(fopen('php://output', 'w'));
echo "\n($bytes bytes)\n";

// ---------- Saved CSS / JS serials: serial -> source -> serial ----------
echo "\n=== CSS / JS SERIAL (live crawl, one file per source) ===\n";

$manifestFile = "$assetDir/manifest.json";
$manifest     = is_file($manifestFile)
    ? (json_decode((string) file_get_contents($manifestFile), true) ?: [])
    : [];

if (!$manifest) {
    echo "No saved assets. Run: php test.php --refresh   (or open test.php?refresh=1)\n";
}

$totalSrc = $totalSer = $bad = 0;
foreach ($manifest as $file => $source) {
    try {
        $path = "$assetDir/$file";
        $r    = RatioSerial::load($path);                          // serial -> source
        $re   = RatioSerial::encode($r['source'], $r['kind']);     // source -> serial
        $ok   = RatioSerial::decode($re)['source'] === $r['source'];

        $sizeSrc = strlen($r['source']);
        $sizeSer = (int) filesize($path);
        $totalSrc += $sizeSrc;
        $totalSer += $sizeSer;
        $bad      += $ok ? 0 : 1;

        printf("%-4s %7d -> %7d bytes  K:V:S:G %-18s %s  %s\n",
            $r['kind'], $sizeSrc, $sizeSer, $r['ratio']['tokenRatio'],
            $ok ? 'OK' : 'FAILED', $source);
    } catch (Throwable $e) {
        $bad++;
        printf("FAIL %s: %s\n", $file, $e->getMessage());
    }
}
if ($manifest) {
    printf("\n%d files, %d -> %d bytes total, %d failures\n", count($manifest), $totalSrc, $totalSer, $bad);
}

printf("\npeak %.1f MB\n", memory_get_peak_usage() / 1048576);