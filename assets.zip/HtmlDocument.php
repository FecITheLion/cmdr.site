<?php
declare(strict_types=1);

require_once __DIR__ . '/HtmlNode.php';
require_once __DIR__ . '/HtmlFragment.php';

final class HtmlDocument implements Stringable
{
    use RendersHtml;

    private const string ATTR = '/([\w:-]+)(?:=(?:"([^"]*)"|\'([^\']*)\'|(\S+)))?/';

    /** @var list<HtmlNode> */
    public readonly array $roots;

    public function __construct(string $input)
    {
        $this->roots = self::parse($input);
    }

    /**
     * Yields 'tag' => "<...>" or 'text' => "..." without building a token array.
     * The body of <script> and <style> is yielded as one raw text token.
     */
    private static function tokens(string $in): Generator
    {
        $i = 0;
        $n = strlen($in);
        while ($i < $n) {
            if ($in[$i] === '<') {
                $end = strpos($in, '>', $i + 1);
                if ($end !== false && $end > $i + 1) {
                    $tag = substr($in, $i, $end - $i + 1);
                    yield 'tag' => $tag;
                    $i = $end + 1;

                    if (preg_match('~^<(script|style)(?=[\s>/])~i', $tag, $m) === 1
                        && !str_ends_with($tag, '/>')) {
                        $close = stripos($in, '</' . $m[1], $i);
                        $stop  = $close === false ? $n : $close;
                        if ($stop > $i) {
                            yield 'text' => substr($in, $i, $stop - $i);
                            $i = $stop;
                        }
                    }
                    continue;
                }
            }
            // text: consume at least one char so a stray '<' cannot loop forever
            $len = ($i + 1 < $n) ? strcspn($in, '<', $i + 1) + 1 : 1;
            yield 'text' => substr($in, $i, $len);
            $i += $len;
        }
    }

    private static function parse(string $input): array
    {
        $roots = [];
        $stack = new SplStack();

        $attach = static function (HtmlNode $node) use (&$roots, $stack): void {
            if ($stack->isEmpty()) {
                $roots[] = $node;
            } else {
                $stack->top()->addChild($node);
            }
        };

        foreach (self::tokens($input) as $kind => $tok) {
            if ($kind === 'text' || $tok[1] === '!' || $tok[1] === '?') {
                $attach(new HtmlText($tok));            // text, comments, doctype: passed through
                continue;
            }

            if ($tok[1] === '/') {                      // closing tag
                self::closeTo($stack, HtmlFragment::canonicalTag(trim(substr($tok, 2, -1))));
                continue;
            }

            $inner     = trim(substr($tok, 1, -1));
            $selfClose = str_ends_with($inner, '/');
            if ($selfClose) {
                $inner = rtrim(substr($inner, 0, -1));
            }

            $len  = strcspn($inner, " \t\r\n");
            $name = substr($inner, 0, $len);
            if ($name === '') {
                $attach(new HtmlText($tok));
                continue;
            }

            $frag = new HtmlFragment($name);
            if ($len < strlen($inner)) {
                self::readAttributes($frag, substr($inner, $len));
            }

            $attach($frag);
            if (!$selfClose && !HtmlFragment::isVoid($frag->tagname)) {
                $stack->push($frag);
            }
        }

        return $roots;
    }

    private static function readAttributes(HtmlFragment $frag, string $s): void
    {
        if (!preg_match_all(self::ATTR, $s, $m, PREG_SET_ORDER | PREG_UNMATCHED_AS_NULL)) {
            return;
        }
        foreach ($m as $a) {
            $value = $a[2] ?? $a[3] ?? $a[4] ?? '';
            if ($a[1] === 'href') {
                $frag->href($value);
            } else {
                $frag->setAttribute($a[1], $value);
            }
        }
    }

    /** Pops up to and including the nearest open element with this tag; ignores stray closers. */
    private static function closeTo(SplStack $stack, string $tag): void
    {
        $depth = 0;
        $hit   = false;
        foreach ($stack as $open) {                     // SplStack iterates top-first
            ++$depth;
            if ($open->tagname === $tag) {
                $hit = true;
                break;
            }
        }
        if ($hit) {
            while ($depth-- > 0) {
                $stack->pop();
            }
        }
    }

    #[\Override]
    public function chunks(): Generator
    {
        foreach ($this->roots as $root) {
            yield from $root->chunks();
        }
    }

    #[\Override]
    public function toArray(): array
    {
        return array_map(static fn(HtmlNode $r): array|string => $r->toArray(), $this->roots);
    }
}