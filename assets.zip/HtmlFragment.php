<?php
declare(strict_types=1);

require_once __DIR__ . '/HtmlNode.php';

/**
 * <heading><leadhead tagname attrs leadtail>head text children tail</tailhead tagname tailtail>tailing
 */
final class HtmlFragment implements HtmlNode
{
    use RendersHtml;

    public const string ALIAS_KEY = 'HtmlFragmentAliasMap';
    public const string HREF_KEY  = 'hrefMap';
    public const string VOID_KEY  = 'HtmlFragmentVoidMap';

    private const array VOID = [
        'area' => true, 'base' => true, 'br' => true, 'col' => true, 'embed' => true,
        'hr' => true, 'img' => true, 'input' => true, 'link' => true, 'meta' => true,
        'source' => true, 'track' => true, 'wbr' => true,
    ];

    /** The spec lists "empty" children for these, but they still need a closing tag. */
    private const array NOT_VOID = ['iframe' => true, 'template' => true, 'selectedcontent' => true];

    /** String members that are copied verbatim by fromArray(). */
    private const array STRING_KEYS = [
        'heading', 'leadhead', 'leadtail', 'head', 'text', 'tail',
        'tailhead', 'tailtail', 'tailing',
    ];

    // ---------- Alias index (built from the global, cached) ----------

    /** @var array<string, SplFixedArray> lowercase alias => [solidus, tagname] */
    private static array $index = [];
    private static ?array $source = null;

    // ---------- Members ----------

    public string $heading  = '';
    public string $leadhead = '';

    /** Setting an alias (e.g. "Bold") resolves tagname and tailhead via the global map. */
    public string $tagname = 'a' {
        set(string $value) {
            $pair = self::lookup($value);
            $this->tailhead = $pair?->offsetGet(0) ?? '/';
            $this->tagname  = $pair?->offsetGet(1) ?? $value;
        }
    }

    /** Raw extra text placed after the generated attributes. */
    public string $leadtail = '';
    public string $head     = '';
    public string $text     = '';
    public string $tail     = '';
    public string $tailhead = '/';
    public string $tailtail = '';
    public string $tailing  = '';

    /** @var array<string, string> */
    public private(set) array $attrs = [];

    /** The shared alias pair this fragment was created from, if any. */
    public private(set) ?SplFixedArray $anchor = null;

    /** Virtual: no storage, read from attrs. */
    public string $resolvedHref {
        get => $this->attrs['href'] ?? '';
    }

    private ?WeakReference $parentRef = null;

    /** @var list<HtmlNode> */
    private array $children = [];

    public function __construct(string $alias = '')
    {
        if ($alias !== '') {
            $this->anchor  = self::lookup($alias);
            $this->tagname = $alias;
        }
    }

    public function __clone()
    {
        $kids = $this->children;
        $this->children  = [];
        $this->parentRef = null;
        foreach ($kids as $kid) {
            $this->addChild(clone $kid);
        }
    }

    // ---------- Aliases ----------

    private static function lookup(string $name): ?SplFixedArray
    {
        $map = $GLOBALS[self::ALIAS_KEY] ?? [];
        if (!is_array($map)) {
            $map = [];
        }
        if ($map !== self::$source) {
            self::rebuildIndex($map);
        }
        return self::$index[strtolower($name)] ?? null;
    }

    private static function rebuildIndex(array $map): void
    {
        $index = [];
        foreach ($map as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $pair = $entry['pair'] ?? null;
            if (is_array($pair)) {
                $pair = SplFixedArray::fromArray(array_values($pair));
            }
            if (!$pair instanceof SplFixedArray || $pair->getSize() < 2
                || !is_string($pair[0]) || !is_string($pair[1])) {
                continue;
            }
            foreach ((array) ($entry['aliases'] ?? []) as $alias) {
                if (is_string($alias) && $alias !== '') {
                    $index[strtolower($alias)] = $pair;   // one shared pair per entry
                }
            }
        }
        self::$index  = $index;
        self::$source = $map;
    }

    /**
     * Global map shape:
     * $GLOBALS['HtmlFragmentAliasMap'] = [
     *   ['aliases' => ['Anchor', 'A'], 'pair' => SplFixedArray::fromArray(['/', 'a'])],
     * ];
     * pair[0] = solidus, pair[1] = tagname. Unknown names resolve to ['/', $name].
     */
    public static function resolveAlias(string $name): SplFixedArray
    {
        return self::lookup($name) ?? SplFixedArray::fromArray(['/', $name]);
    }

    public static function canonicalTag(string $name): string
    {
        $pair = self::lookup($name);
        return $pair === null ? $name : $pair[1];
    }

    public static function isVoid(string $tagname): bool
    {
        $t = strtolower($tagname);
        if (isset(self::NOT_VOID[$t])) {
            return false;
        }
        $extra = $GLOBALS[self::VOID_KEY] ?? null;
        return is_array($extra) ? isset($extra[$t]) : isset(self::VOID[$t]);
    }

    // ---------- Attributes / href ----------

    public function setAttribute(string $name, string $value): self
    {
        $this->attrs[$name] = $value;
        return $this;
    }

    /** Accepts a URL, or an id looked up in $GLOBALS['hrefMap']. */
    public function href(string $value): self
    {
        return $value === '' ? $this : $this->setAttribute('href', self::resolveHref($value));
    }

    private static function resolveHref(string $value): string
    {
        if (filter_var($value, FILTER_VALIDATE_URL) !== false) {
            return $value;
        }
        $map = $GLOBALS[self::HREF_KEY] ?? null;
        $candidate = is_array($map) ? ($map[$value] ?? null) : null;

        return is_string($candidate) && filter_var($candidate, FILTER_VALIDATE_URL) !== false
            ? $candidate
            : $value;
    }

    // ---------- Children ----------

    public function addChild(HtmlNode $child): self
    {
        if ($child instanceof self) {
            $child->parentRef = WeakReference::create($this);
        }
        $this->children[] = $child;
        return $this;
    }

    public function addText(string $text): self
    {
        return $this->addChild(new HtmlText($text));
    }

    /** @return list<HtmlNode> */
    public function children(): array
    {
        return $this->children;
    }

    public function parent(): ?self
    {
        return $this->parentRef?->get();
    }

    // ---------- Fluent setters ----------

    public function setHeading(string $v): self  { $this->heading  = $v; return $this; }
    public function setLeadhead(string $v): self { $this->leadhead = $v; return $this; }
    public function setTagname(string $v): self  { $this->tagname  = $v; return $this; }
    public function setLeadtail(string $v): self { $this->leadtail = $v; return $this; }
    public function setHead(string $v): self     { $this->head     = $v; return $this; }
    public function setText(string $v): self     { $this->text     = $v; return $this; }
    public function setTail(string $v): self     { $this->tail     = $v; return $this; }
    public function setTailhead(string $v): self { $this->tailhead = $v; return $this; }
    public function setTailtail(string $v): self { $this->tailtail = $v; return $this; }
    public function setTailing(string $v): self  { $this->tailing  = $v; return $this; }

    // ---------- Output (streamed) ----------

    #[\Override]
    public function chunks(): Generator
    {
        $open = $this->heading . '<' . $this->leadhead . $this->tagname;
        foreach ($this->attrs as $name => $value) {
            $open .= ' ' . $name . '="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"';
        }
        $open .= $this->leadtail . '>';

        if ($this->text === '' && !$this->children && self::isVoid($this->tagname)) {
            yield $open . $this->tailing;           // <br>, <img>, ... have no closing tag
            return;
        }

        yield $open . $this->head . $this->text;
        foreach ($this->children as $child) {
            yield from $child->chunks();
        }
        yield $this->tail . '<' . $this->tailhead . $this->tagname . $this->tailtail . '>' . $this->tailing;
    }

    // ---------- Pruned export ----------

    #[\Override]
    public function toArray(): array
    {
        // Empty members are omitted; defaults ('a' and '/') are assumed on reconstruction.
        $out = array_filter([
            'heading'  => $this->heading,
            'leadhead' => $this->leadhead,
            'tagname'  => $this->tagname === 'a' ? '' : $this->tagname,
            'attrs'    => $this->attrs,
            'leadtail' => $this->leadtail,
            'head'     => $this->head,
            'text'     => $this->text,
            'tail'     => $this->tail,
            'tailhead' => $this->tailhead === '/' ? '' : $this->tailhead,
            'tailtail' => $this->tailtail,
            'tailing'  => $this->tailing,
        ], static fn(mixed $v): bool => $v !== '' && $v !== []);

        if ($this->children) {
            $out['children'] = array_map(
                static fn(HtmlNode $c): array|string => $c->toArray(),
                $this->children
            );
        }
        return $out;
    }

    // ---------- Tolerant reconstruction ----------

    /**
     * Accepts a sparse array (or a plain string for a text node). Missing keys take
     * defaults; unknown keys and wrong types are ignored. 'tagname' may be an alias.
     */
    public static function fromArray(mixed $d): HtmlNode
    {
        if (is_string($d)) {
            return new HtmlText($d);
        }
        $o = new self();
        if (!is_array($d)) {
            return $o;
        }

        if (($d['node'] ?? null) === 'text') {
            return new HtmlText(is_string($d['text'] ?? null) ? $d['text'] : '');
        }

        if (is_string($d['tagname'] ?? null) && $d['tagname'] !== '') {
            $o->anchor  = self::lookup($d['tagname']);
            $o->tagname = $d['tagname'];            // hook sets tailhead too
        }

        // Explicit values override alias-derived ones
        foreach (self::STRING_KEYS as $key) {
            if (is_string($d[$key] ?? null) && $d[$key] !== '') {
                $o->$key = $d[$key];
            }
        }

        if (is_array($d['attrs'] ?? null)) {
            foreach ($d['attrs'] as $name => $value) {
                if (is_scalar($value)) {
                    $o->attrs[(string) $name] = (string) $value;
                }
            }
        }

        if (is_array($d['children'] ?? null)) {
            foreach ($d['children'] as $child) {
                if (is_string($child) || is_array($child)) {
                    $o->addChild(self::fromArray($child));
                }
            }
        }
        return $o;
    }

    public static function fromJSON(string $json): HtmlNode
    {
        return self::fromArray(json_decode($json, true));
    }
}