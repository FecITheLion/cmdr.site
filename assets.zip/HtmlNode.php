<?php
declare(strict_types=1);

interface HtmlNode extends Stringable
{
    /** Streams the rendered HTML in pieces. */
    public function chunks(): Generator;

    /** Pruned export: array for elements, plain string for text nodes. */
    public function toArray(): array|string;

    public function toString(): string;
    public function toJSON(int $flags = 0): string;

    /** @param resource $stream */
    public function writeTo(mixed $stream): int;
}

trait RendersHtml
{
    abstract public function chunks(): Generator;
    abstract public function toArray(): array|string;

    public function toString(): string
    {
        $out = '';
        foreach ($this->chunks() as $chunk) {
            $out .= $chunk;
        }
        return $out;
    }

    public function __toString(): string
    {
        return $this->toString();
    }

    public function toJSON(int $flags = 0): string
    {
        return json_encode(
            $this->toArray(),
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR | $flags
        );
    }

    /** @param resource $stream  Returns bytes written. */
    public function writeTo(mixed $stream): int
    {
        $bytes = 0;
        foreach ($this->chunks() as $chunk) {
            $written = fwrite($stream, $chunk);
            if ($written === false) {
                throw new RuntimeException('Stream write failed');
            }
            $bytes += $written;
        }
        return $bytes;
    }
}

final class HtmlText implements HtmlNode
{
    use RendersHtml;

    public function __construct(public string $text = '') {}

    #[\Override]
    public function chunks(): Generator
    {
        yield $this->text;
    }

    #[\Override]
    public function toArray(): string
    {
        return $this->text;
    }
}