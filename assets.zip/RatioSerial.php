<?php
declare(strict_types=1);

/**
 * Lossless CSS/JS <-> compact serial.
 *
 * Tokens are classed Key / Value / Space / Glyph. Each unique string is stored once per
 * class; the source is a stream of varint(index << 2 | class). The header keeps the token
 * and character counts (and their reduced ratios) plus a CRC32 of the original.
 *
 * Classification only decides which table a string lives in. Every byte of the source is
 * kept in some token, so decode(encode($x)) === $x even if a token is classed "wrongly".
 */
final class RatioSerial
{
    public const string MAGIC = 'RSR1';

    private const int KEY   = 0;
    private const int VALUE = 1;
    private const int SPACE = 2;
    private const int GLYPH = 3;

    private const array NAMES = ['key', 'value', 'space', 'glyph'];

    private const array JS_LITERALS = [
        'true' => 1, 'false' => 1, 'null' => 1, 'undefined' => 1, 'NaN' => 1, 'Infinity' => 1,
    ];

    // groups: s = space, v = value, h = hex colour (CSS), w = word. No match => glyph.
    private const string CSS_RE =
        '~\G(?:(?<s>\s+|/\*.*?\*/)'
        . '|(?<v>"(?:[^"\\\\]|\\\\.)*"|\'(?:[^\'\\\\]|\\\\.)*\'|[+-]?(?:\d+\.?\d*|\.\d+)(?:[a-zA-Z%]+)?)'
        . '|(?<h>\#[0-9A-Fa-f]{3,8}\b)'
        . '|(?<w>[A-Za-z_@!-][\w-]*))~s';

    private const string JS_RE =
        '~\G(?:(?<s>\s+|//[^\n]*|/\*.*?\*/)'
        . '|(?<v>"(?:[^"\\\\\n]|\\\\.)*"|\'(?:[^\'\\\\\n]|\\\\.)*\'|`(?:[^`\\\\]|\\\\.)*`'
        . '|0[xXbBoO][\da-fA-F_]+n?|\d[\d_]*\.?\d*(?:[eE][+-]?\d+)?n?|\.\d+)'
        . '|(?<w>[A-Za-z_$][\w$]*))~s';

    // ---------- Tokenizer ----------

    /** @return Generator<array{0: int, 1: string}> */
    private static function tokens(string $src, string $kind): Generator
    {
        $css     = $kind === 'css';
        $re      = $css ? self::CSS_RE : self::JS_RE;
        $n       = strlen($src);
        $pos     = 0;
        $depth   = 0;
        $inValue = false;
        $prev    = self::GLYPH;

        while ($pos < $n) {
            if (preg_match($re, $src, $m, PREG_UNMATCHED_AS_NULL, $pos) !== 1) {
                $text = $src[$pos];                       // also the path if PCRE errors out
                $cls  = self::GLYPH;
            } else {
                $text = $m[0];
                if ($m['s'] !== null) {
                    $cls = self::SPACE;
                } elseif ($m['v'] !== null) {
                    $cls = self::VALUE;
                } elseif (($m['h'] ?? null) !== null) {
                    $cls = $inValue ? self::VALUE : self::KEY;
                } elseif ($css) {
                    $cls = $inValue ? self::VALUE : self::KEY;
                } else {
                    $cls = isset(self::JS_LITERALS[$text]) ? self::VALUE : self::KEY;
                }
            }

            if ($css && $cls === self::GLYPH) {
                if ($text === '{') {
                    $depth++;
                    $inValue = false;
                } elseif ($text === '}') {
                    $depth   = max(0, $depth - 1);
                    $inValue = false;
                } elseif ($text === ';') {
                    $inValue = false;
                } elseif ($text === ':' && $depth > 0 && $prev === self::KEY) {
                    $inValue = true;                      // "property:" inside a block
                }
            }
            if ($cls !== self::SPACE) {
                $prev = $cls;
            }

            yield [$cls, $text];
            $pos += strlen($text);
        }
    }

    // ---------- Encode ----------

    public static function encode(string $src, string $kind = 'css', bool $compress = true): string
    {
        $kindByte = match ($kind) {
            'css'   => 1,
            'js'    => 2,
            default => throw new InvalidArgumentException("Unknown kind: $kind"),
        };

        $ids    = [[], [], [], []];
        $list   = [[], [], [], []];
        $tokens = [0, 0, 0, 0];
        $chars  = [0, 0, 0, 0];
        $stream = '';
        $count  = 0;

        foreach (self::tokens($src, $kind) as [$cls, $text]) {
            $id = $ids[$cls][$text] ?? null;
            if ($id === null) {
                $id = count($list[$cls]);
                $ids[$cls][$text] = $id;
                $list[$cls][]     = $text;
            }
            $tokens[$cls]++;
            $chars[$cls] += strlen($text);
            $stream      .= self::put(($id << 2) | $cls);
            $count++;
        }

        $p = chr($kindByte) . pack('N', crc32($src));
        foreach ($tokens as $t) {
            $p .= self::put($t);
        }
        foreach ($chars as $c) {
            $p .= self::put($c);
        }
        foreach ($list as $table) {
            $p .= self::put(count($table));
            foreach ($table as $s) {
                $p .= self::put(strlen($s)) . $s;
            }
        }
        $p .= self::put($count) . $stream;

        if ($compress && function_exists('gzdeflate')) {
            $z = gzdeflate($p, 9);
            if ($z !== false && strlen($z) < strlen($p)) {
                return self::MAGIC . "\x01" . $z;
            }
        }
        return self::MAGIC . "\x00" . $p;
    }

    // ---------- Decode ----------

    /** @return array{kind: string, source: string, ratio: array} */
    public static function decode(string $serial): array
    {
        $b = self::payload($serial);
        $p = 0;
        $h = self::header($b, $p);
        $len = strlen($b);

        $tables = [];
        for ($c = 0; $c < 4; $c++) {
            $n = self::get($b, $p);
            $t = [];
            while ($n-- > 0) {
                $l = self::get($b, $p);
                if ($p + $l > $len) {
                    throw new UnexpectedValueException('Truncated table');
                }
                $t[] = substr($b, $p, $l);
                $p  += $l;
            }
            $tables[] = $t;
        }

        $count = self::get($b, $p);
        $out   = [];
        $seen  = [0, 0, 0, 0];
        while ($count-- > 0) {
            $v     = self::get($b, $p);
            $cls   = $v & 3;
            $out[] = $tables[$cls][$v >> 2] ?? throw new UnexpectedValueException('Bad table index');
            $seen[$cls]++;
        }

        $src = implode('', $out);
        if ($seen !== $h['tokens']) {
            throw new UnexpectedValueException('Token ratio mismatch');
        }
        if (crc32($src) !== $h['crc']) {
            throw new UnexpectedValueException('Checksum mismatch');
        }
        return ['kind' => $h['kind'], 'source' => $src, 'ratio' => self::ratioOf($h)];
    }

    /** Reads only the header. */
    public static function ratio(string $serial): array
    {
        $b = self::payload($serial);
        $p = 0;
        return self::ratioOf(self::header($b, $p));
    }

    // ---------- Files ----------

    public static function save(string $path, string $src, string $kind = 'css'): int
    {
        $written = file_put_contents($path, self::encode($src, $kind), LOCK_EX);
        if ($written === false) {
            throw new RuntimeException("Cannot write $path");
        }
        return $written;
    }

    /** @return array{kind: string, source: string, ratio: array} */
    public static function load(string $path): array
    {
        $serial = is_file($path) ? file_get_contents($path) : false;
        if ($serial === false) {
            throw new RuntimeException("Cannot read $path");
        }
        return self::decode($serial);
    }

    // ---------- Internals ----------

    private static function payload(string $serial): string
    {
        if (strlen($serial) < 5 || !str_starts_with($serial, self::MAGIC)) {
            throw new InvalidArgumentException('Not a ratio serial');
        }
        $body = substr($serial, 5);
        if ($serial[4] === "\x01") {
            $body = function_exists('gzinflate') ? @gzinflate($body) : false;
            if ($body === false) {
                throw new InvalidArgumentException('Corrupt or unsupported compressed payload');
            }
        }
        return $body;
    }

    /** @return array{kind: string, crc: int, tokens: list<int>, chars: list<int>} */
    private static function header(string $b, int &$p): array
    {
        if (strlen($b) < 5) {
            throw new UnexpectedValueException('Truncated header');
        }
        $kind = match (ord($b[0])) {
            1       => 'css',
            2       => 'js',
            default => throw new UnexpectedValueException('Unknown kind byte'),
        };
        $crc = unpack('N', $b, 1)[1];
        $p   = 5;

        $tokens = [];
        $chars  = [];
        for ($i = 0; $i < 4; $i++) {
            $tokens[] = self::get($b, $p);
        }
        for ($i = 0; $i < 4; $i++) {
            $chars[] = self::get($b, $p);
        }
        return ['kind' => $kind, 'crc' => $crc, 'tokens' => $tokens, 'chars' => $chars];
    }

    private static function ratioOf(array $h): array
    {
        return [
            'order'      => implode(':', self::NAMES),
            'tokens'     => array_combine(self::NAMES, $h['tokens']),
            'chars'      => array_combine(self::NAMES, $h['chars']),
            'tokenRatio' => self::reduce($h['tokens']),
            'charRatio'  => self::reduce($h['chars']),
        ];
    }

    private static function reduce(array $n): string
    {
        $g = 0;
        foreach ($n as $x) {
            $g = self::gcd($g, $x);
        }
        return implode(':', $g > 0 ? array_map(static fn(int $x): int => intdiv($x, $g), $n) : $n);
    }

    private static function gcd(int $a, int $b): int
    {
        while ($b !== 0) {
            [$a, $b] = [$b, $a % $b];
        }
        return $a;
    }

    private static function put(int $n): string
    {
        $o = '';
        while ($n >= 0x80) {
            $o .= chr(($n & 0x7F) | 0x80);
            $n >>= 7;
        }
        return $o . chr($n);
    }

    private static function get(string $b, int &$p): int
    {
        $n     = 0;
        $shift = 0;
        $len   = strlen($b);
        while (true) {
            if ($p >= $len || $shift > 56) {
                throw new UnexpectedValueException('Truncated or corrupt varint');
            }
            $c  = ord($b[$p++]);
            $n |= ($c & 0x7F) << $shift;
            if (($c & 0x80) === 0) {
                return $n;
            }
            $shift += 7;
        }
    }
}