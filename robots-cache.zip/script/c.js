// Compliant consent banner for local storage and cookies
(function () {
    function showBanner() {
        if (document.getElementById('consent')) return;
        var banner = document.createElement('div');
        banner.id = 'consent';
        banner.setAttribute('role', 'dialog');
        banner.setAttribute('aria-label', 'Cookie and local storage consent');
        banner.innerHTML =
            '<p>This site uses local storage to remember your preferred search provider. ' +
            'We do not set tracking cookies. Essential functionality does not require storage. ' +
            'You can change this choice at any time.</p>' +
            '<div class="actions">' +
            '<button class="accept">Accept</button>' +
            '<button class="decline">Decline</button>' +
            '<button class="manage">Manage</button>' +
            '</div>';
        document.body.appendChild(banner);

        banner.querySelector('.accept').addEventListener('click', function () {
            localStorage.setItem('cmdr-consent', 'accepted');
            banner.remove();
        });
        banner.querySelector('.decline').addEventListener('click', function () {
            localStorage.setItem('cmdr-consent', 'declined');
            localStorage.removeItem('cmdr-search-pref');
            banner.remove();
        });
        banner.querySelector('.manage').addEventListener('click', function () {
            var current = localStorage.getItem('cmdr-consent') || 'not set';
            if (confirm('Current preference: ' + current + '\n\nClear all stored preferences?')) {
                localStorage.removeItem('cmdr-consent');
                localStorage.removeItem('cmdr-search-pref');
                banner.remove();
                setTimeout(showBanner, 100);
            }
        });
    }

    if (!localStorage.getItem('cmdr-consent')) {
        showBanner();
    }
})();