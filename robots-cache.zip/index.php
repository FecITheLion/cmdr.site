<?php
/**
 * Mister Rogers' Neighborhood — Keyword Web & Search Provider Hub
 *
 * Single-file application that:
 * - Manages a ranked list of search providers
 * - Crawls linked pages to build a "keyword web" of related destinations
 * - Scans the local filesystem for folders and detects circular link trails
 * - Serves a PWA (manifest + service worker)
 * - Renders a floating-pill UI with search, discovery, and redirect warnings
 * - Mouse and touchscreen input: short taps on pills act as clicks; drag tracks; pinch-zoom and pan remain available
 * - Search pop-up is always centered and styled as a clean search bar
 * - Compliant consent banner for local storage and cookies
 */

declare(strict_types=1);

// ---------------------------------------------------------------------------
// Configuration & Paths
// ---------------------------------------------------------------------------

const STORE_PROVIDERS = __DIR__ . '/search-providers.json';
const STORE_WEB       = __DIR__ . '/crawl-web.json';
const STORE_BAN       = __DIR__ . '/provider-ban.json';
const DIR_LOGS        = __DIR__ . '/provider-logs';
const DIR_ROBOTS      = __DIR__ . '/robots-cache';
const LOG_CIRCULAR    = __DIR__ . '/crawl-circular.log';

const DEFAULT_PROVIDERS = [
    ['id' => 'google',     'name' => 'Google',     'template' => 'https://www.google.com/search?q={term}', 'hits' => 0, 'updated' => 0],
    ['id' => 'bing',       'name' => 'Bing',       'template' => 'https://www.bing.com/search?q={term}', 'hits' => 0, 'updated' => 0],
    ['id' => 'ddg',        'name' => 'DuckDuckGo', 'template' => 'https://duckduckgo.com/?q={term}', 'hits' => 0, 'updated' => 0],
    ['id' => 'brave',      'name' => 'Brave',      'template' => 'https://search.brave.com/search?q={term}', 'hits' => 0, 'updated' => 0],
    ['id' => 'wiki',       'name' => 'Wikipedia',  'template' => 'https://en.wikipedia.org/w/index.php?search={term}', 'hits' => 0, 'updated' => 0],
    ['id' => 'perplexity', 'name' => 'Perplexity', 'template' => 'https://www.perplexity.ai/search?q={term}', 'hits' => 0, 'updated' => 0],
    ['id' => 'you',        'name' => 'You.com',    'template' => 'https://you.com/search?q={term}', 'hits' => 0, 'updated' => 0],
];

const SOCIAL_SEEDS = [
    ['keyword' => 'YouTube',   'uri' => 'https://www.youtube.com/@CMDRSit'],
    ['keyword' => 'LinkedIn',  'uri' => 'https://www.linkedin.com/in/cmdr-site/'],
    ['keyword' => 'GitHub',    'uri' => 'https://github.com/FecITheLion/'],
    ['keyword' => 'Facebook',  'uri' => 'https://www.facebook.com/CMDRSit/'],
    ['keyword' => 'Twitter',   'uri' => 'https://x.com/bidth64892'],
    ['keyword' => 'Instagram', 'uri' => 'https://www.instagram.com/cmdr.site'],
];

// ---------------------------------------------------------------------------
// File Helpers
// ---------------------------------------------------------------------------

function load_json(string $path, array $fallback = []): array
{
    if (!is_file($path)) {
        return $fallback;
    }
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : $fallback;
}

function save_json(string $path, array $data): bool
{
    $fp = fopen($path, 'c+');
    if (!$fp) {
        return false;
    }
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode(array_values($data)));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

// ---------------------------------------------------------------------------
// Search Providers
// ---------------------------------------------------------------------------

function load_providers(): array
{
    return load_json(STORE_PROVIDERS, DEFAULT_PROVIDERS);
}

function save_providers(array $list): bool
{
    return save_json(STORE_PROVIDERS, $list);
}

function valid_template(string $url): bool
{
    return preg_match('#^https://#i', $url) === 1
        && preg_match('/\{[a-z0-9_]+\}/i', $url) === 1;
}

function normalize_template(string $url): string
{
    return preg_replace('/\{[a-z0-9_]+\}/i', '{term}', $url, 1);
}

function param_count(string $url): int
{
    $query = parse_url($url, PHP_URL_QUERY);
    if (!$query) {
        return substr_count($url, '{term}');
    }
    parse_str($query, $params);
    return count($params);
}

// ---------------------------------------------------------------------------
// Provider Ban / Autocorrect
// ---------------------------------------------------------------------------

function load_ban(): array
{
    return load_json(STORE_BAN);
}

function save_ban(array $ban): void
{
    file_put_contents(STORE_BAN, json_encode($ban));
}

function is_banned(string $raw, array $ban): bool
{
    $key = strtolower(trim($raw));
    return isset($ban[$key]) && ($ban[$key]['fails'] ?? 0) >= 2;
}

function note_fail(string $raw): void
{
    $ban = load_ban();
    $key = strtolower(trim($raw));
    if (!isset($ban[$key])) {
        $ban[$key] = ['fails' => 0, 'asks' => 0];
    }
    $ban[$key]['fails']++;
    $ban[$key]['asks'] += 3;
    save_ban($ban);
}

function claim_aliases(string $name): void
{
    $ban = load_ban();
    $id = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));
    if (!is_dir(DIR_LOGS)) {
        mkdir(DIR_LOGS, 0755, true);
    }
    $kept = [];
    $log = [];
    foreach ($ban as $alias => $row) {
        similar_text(strtolower($name), $alias, $pct);
        if ($pct >= 55) {
            $log[] = $alias;
        } else {
            $kept[$alias] = $row;
        }
    }
    if ($log) {
        file_put_contents(DIR_LOGS . '/' . $id . '.log', implode("\n", $log) . "\n", FILE_APPEND);
    }
    save_ban($kept);
}

function autocorrect(string $raw): ?string
{
    if (!is_dir(DIR_LOGS)) {
        return null;
    }
    foreach (glob(DIR_LOGS . '/*.log') as $file) {
        $lines = file($file, FILE_IGNORE_NEW_LINES);
        if (in_array(strtolower(trim($raw)), array_map('strtolower', $lines), true)) {
            return basename($file, '.log');
        }
    }
    return null;
}

// ---------------------------------------------------------------------------
// HTTP & HTML Helpers
// ---------------------------------------------------------------------------

function http_get(string $url): string
{
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_USERAGENT      => 'cmdr-site/1.0 (+https://cmdr.site/; keyword-web)',
        CURLOPT_MAXREDIRS      => 3,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($body && $code >= 200 && $code < 400) ? $body : '';
}

function term_pct(string $html, string $raw): float
{
    $text = strtolower(strip_tags($html));
    $parts = preg_split('/\s+/', strtolower(trim($raw)));
    $hit = 0;
    $n = 0;
    foreach ($parts as $p) {
        if (strlen($p) < 2) {
            continue;
        }
        $n++;
        if (strpos($text, $p) !== false) {
            $hit++;
        }
    }
    return $n ? $hit / $n : 0.0;
}

function abs_url(?string $href, string $base): ?string
{
    $href = trim(html_entity_decode((string) $href));
    if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'javascript:') === 0) {
        return null;
    }
    if (preg_match('#^https?://#i', $href)) {
        return preg_replace('/#.*$/', '', $href);
    }
    if (strpos($href, '//') === 0) {
        $scheme = parse_url($base, PHP_URL_SCHEME) ?: 'https';
        return $scheme . ':' . preg_replace('/#.*$/', '', $href);
    }
    $parts = parse_url($base);
    if (!$parts || empty($parts['host'])) {
        return null;
    }
    $scheme = $parts['scheme'] ?? 'https';
    $path = $parts['path'] ?? '/';
    if ($href[0] !== '/') {
        $path = preg_replace('#/[^/]*$#', '/', $path) . $href;
    } else {
        $path = $href;
    }
    $segs = [];
    foreach (explode('/', $path) as $seg) {
        if ($seg === '' || $seg === '.') {
            continue;
        }
        if ($seg === '..') {
            array_pop($segs);
            continue;
        }
        $segs[] = $seg;
    }
    return $scheme . '://' . $parts['host'] . '/' . implode('/', $segs);
}

// ---------------------------------------------------------------------------
// Search Pattern Discovery
// ---------------------------------------------------------------------------

function patterns_from_dom(string $html, string $raw): string
{
    if ($html === '') {
        return '';
    }
    $found = [];
    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    $xp = new DOMXPath($doc);

    foreach ($xp->query('//a[@href]|//link[@href]|//*[@content]') as $node) {
        $url = $node->getAttribute('href') ?: $node->getAttribute('content');
        if (!preg_match('#^https?://#', $url)) {
            continue;
        }
        if (!preg_match('/(?:[?&](?:q|query|search|search_query|p)=)|\{(?:term|searchTerms|search_term_string)\}/i', $url)) {
            continue;
        }
        $found[] = ['url' => normalize_template($url), 'pct' => term_pct($html, $raw)];
    }

    if (preg_match_all('#https?://[^\s"\'<>]+\{(?:term|searchTerms|search_term_string)\}[^\s"\'<>]*#i', $html, $m)) {
        foreach ($m[0] as $url) {
            $found[] = ['url' => normalize_template(html_entity_decode($url)), 'pct' => term_pct($html, $raw)];
        }
    }

    usort($found, fn($a, $b) => $b['pct'] <=> $a['pct']);
    return $found[0]['url'] ?? '';
}

function pick_three(array $candidates, int $wanted): string
{
    $best = null;
    foreach ($candidates as $url) {
        if (!$url) {
            continue;
        }
        $score = strlen($url) + abs(param_count($url) - $wanted) * 40;
        if ($best === null || $score < $best[0]) {
            $best = [$score, $url];
        }
    }
    return $best[1] ?? '';
}

// ---------------------------------------------------------------------------
// Site Origin & Keyword Helpers
// ---------------------------------------------------------------------------

function site_origin(): string
{
    $host = $_SERVER['HTTP_HOST'] ?? 'cmdr.site';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    return ($https ? 'https' : 'http') . '://' . $host;
}

function full_uri(string $rel): string
{
    $rel = trim(str_replace('\\', '/', $rel), '/');
    return site_origin() . '/' . ($rel === '' ? '' : $rel . '/');
}

function keyword_uri(string $keyword): string
{
    return site_origin() . '/?k=' . rawurlencode($keyword);
}

function is_home(string $url): bool
{
    $host = parse_url($url, PHP_URL_HOST);
    $mine = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : 'cmdr.site';
    return $host && (
        strcasecmp($host, $mine) === 0
        || strcasecmp($host, 'cmdr.site') === 0
        || strcasecmp($host, 'www.cmdr.site') === 0
    );
}

// ---------------------------------------------------------------------------
// Robots.txt Handling
// ---------------------------------------------------------------------------

function host_robots(string $host): string
{
    if (!is_dir(DIR_ROBOTS)) {
        mkdir(DIR_ROBOTS, 0755, true);
    }
    $file = DIR_ROBOTS . '/' . preg_replace('/[^a-z0-9.-]+/i', '_', strtolower($host)) . '.txt';
    if (!is_file($file) || time() - filemtime($file) > 86400) {
        $body = http_get('https://' . $host . '/robots.txt');
        file_put_contents($file, $body === '' ? "User-agent: *\nAllow: /\n" : $body, LOCK_EX);
    }
    return is_file($file) ? file_get_contents($file) : '';
}

function robots_allows(string $url): bool
{
    $host = parse_url($url, PHP_URL_HOST);
    $path = parse_url($url, PHP_URL_PATH) ?: '/';
    if (!$host) {
        return false;
    }
    $txt = host_robots($host);
    $ua = '*';
    $disallows = [];
    foreach (preg_split('/\r\n|\n|\r/', $txt) as $line) {
        $line = trim(preg_replace('/#.*$/', '', $line));
        if ($line === '') {
            continue;
        }
        if (stripos($line, 'User-agent:') === 0) {
            $ua = trim(substr($line, 11));
            continue;
        }
        if ($ua !== '*') {
            continue;
        }
        if (stripos($line, 'Disallow:') === 0) {
            $rule = trim(substr($line, 9));
            if ($rule !== '') {
                $disallows[] = $rule;
            }
        }
    }
    foreach ($disallows as $rule) {
        if (strpos($path, $rule) === 0) {
            return false;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// Keyword Web (crawl state)
// ---------------------------------------------------------------------------

function load_web(): array
{
    $home = [
        'keyword' => "Mister Rogers'",
        'uri'     => keyword_uri("Mister Rogers'"),
        'source'  => full_uri(''),
        'log'     => full_uri(''),
        'back'    => true,
        'related' => [],
    ];
    $nodes = [$home];
    foreach (SOCIAL_SEEDS as $seed) {
        $nodes[] = [
            'keyword' => $seed['keyword'],
            'uri'     => keyword_uri($seed['keyword']),
            'source'  => $seed['uri'],
            'log'     => $seed['uri'],
            'back'    => false,
            'related' => [keyword_uri("Mister Rogers'")],
        ];
    }
    $queue = [];
    foreach (SOCIAL_SEEDS as $seed) {
        $queue[] = [
            'uri'     => $seed['uri'],
            'depth'   => 0,
            'trail'   => [$seed['uri']],
            'keyword' => $seed['keyword'],
        ];
    }
    $state = [
        'nodes' => $nodes,
        'queue' => $queue,
        'seen'  => [full_uri('') => true],
        'next'  => 0,
    ];
    if (is_file(STORE_WEB)) {
        $data = json_decode(file_get_contents(STORE_WEB), true);
        if (is_array($data) && !empty($data['nodes'])) {
            $state = array_merge($state, $data);
        }
    }
    return $state;
}

function save_web(array $state): bool
{
    return save_json(STORE_WEB, $state);
}

function lookup_k(array $web, string $keyword): ?array
{
    $keyword = trim($keyword);
    if ($keyword === '') {
        return null;
    }
    $best = null;
    foreach ($web['nodes'] as $node) {
        if (strcasecmp($node['keyword'], $keyword) !== 0) {
            continue;
        }
        if (empty($node['source']) || is_home($node['source'])) {
            continue;
        }
        $best = $node;
        if (!empty($node['back'])) {
            break;
        }
    }
    if ($best) {
        return $best;
    }
    foreach (SOCIAL_SEEDS as $seed) {
        if (strcasecmp($seed['keyword'], $keyword) === 0) {
            return [
                'keyword' => $seed['keyword'],
                'uri'     => keyword_uri($seed['keyword']),
                'source'  => $seed['uri'],
                'log'     => $seed['uri'],
                'back'    => false,
                'related' => [keyword_uri("Mister Rogers'")],
            ];
        }
    }
    return null;
}

function extract_hops(string $html, string $base): array
{
    $hops = [];
    if ($html === '') {
        return $hops;
    }
    if (preg_match_all('/<a\b[^>]*\bhref\s*=\s*([\'"])(.*?)\1[^>]*>(.*?)<\/a>/is', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $row) {
            $uri = abs_url($row[2], $base);
            if (!$uri) {
                continue;
            }
            $keyword = trim(preg_replace('/\s+/', ' ', strip_tags($row[3])));
            if ($keyword === '' || strlen($keyword) > 60) {
                $keyword = ucwords(str_replace(['-', '_'], ' ', basename(parse_url($uri, PHP_URL_PATH) ?: 'link')));
            }
            $hops[] = ['uri' => $uri, 'keyword' => $keyword];
        }
    }
    if (preg_match('/<link[^>]+rel=["\']canonical["\'][^>]*href=["\']([^"\']+)["\']/i', $html, $m)
        || preg_match('/<meta[^>]+property=["\']og:url["\'][^>]*content=["\']([^"\']+)["\']/i', $html, $m)
    ) {
        $uri = abs_url($m[1], $base);
        if ($uri) {
            $hops[] = ['uri' => $uri, 'keyword' => 'canonical'];
        }
    }
    return $hops;
}

function upsert_node(array &$state, array $node): array
{
    foreach ($state['nodes'] as &$row) {
        if (strcasecmp($row['keyword'], $node['keyword']) === 0 && $row['uri'] === $node['uri']) {
            if (!empty($node['back'])) {
                $row['back'] = true;
            }
            if (!empty($node['log'])) {
                $row['log'] = $node['log'];
            }
            if (!empty($node['source'])) {
                $row['source'] = $node['source'];
            }
            $row['related'] = array_values(array_unique(array_merge($row['related'] ?? [], $node['related'] ?? [])));
            return $row;
        }
    }
    unset($row);
    $state['nodes'][] = $node;
    return $node;
}

function crawl_step(): array
{
    $state = load_web();
    $wait = 3000;
    if (time() < ($state['next'] ?? 0)) {
        return [
            'ok'      => true,
            'pending' => !empty($state['queue']),
            'wait'    => max(500, ($state['next'] - time()) * 1000),
            'nodes'   => [],
        ];
    }
    $fresh = [];
    if (empty($state['queue'])) {
        $state['next'] = time() + 30;
        save_web($state);
        return ['ok' => true, 'pending' => false, 'wait' => 30000, 'nodes' => []];
    }
    $job = array_shift($state['queue']);
    $uri = $job['uri'];
    $state['seen'][$uri] = true;
    $state['next'] = time() + 3;

    if (robots_allows($uri)) {
        $html = http_get($uri);
        $trail = $job['trail'] ?? [$uri];
        $homeHit = is_home($uri);
        foreach (extract_hops($html, $uri) as $hop) {
            if (is_home($hop['uri'])) {
                $homeHit = true;
            }
            if (count($trail) < 6 && empty($state['seen'][$hop['uri']]) && count($state['queue']) < 40) {
                $prefer = is_home($hop['uri']) || stripos($hop['uri'], 'cmdr.site') !== false;
                $next = [
                    'uri'     => $hop['uri'],
                    'depth'   => $job['depth'] + 1,
                    'trail'   => array_merge($trail, [$hop['uri']]),
                    'keyword' => $hop['keyword'],
                ];
                if ($job['depth'] < 3) {
                    if ($prefer) {
                        array_unshift($state['queue'], $next);
                    } else {
                        $state['queue'][] = $next;
                    }
                }
            }
            if ($homeHit || is_home($hop['uri'])) {
                $log = implode(' -> ', array_merge($trail, [$hop['uri'], full_uri('')]));
                $node = [
                    'keyword' => $hop['keyword'] !== '' ? $hop['keyword'] : $job['keyword'],
                    'uri'     => keyword_uri($hop['keyword'] !== '' ? $hop['keyword'] : $job['keyword']),
                    'source'  => $hop['uri'],
                    'log'     => $log,
                    'back'    => true,
                    'related' => [keyword_uri("Mister Rogers'"), keyword_uri($job['keyword'])],
                ];
                $fresh[] = upsert_node($state, $node);
            }
        }
        if ($homeHit) {
            $log = implode(' -> ', array_merge($trail, [full_uri('')]));
            $fresh[] = upsert_node($state, [
                'keyword' => $job['keyword'],
                'uri'     => keyword_uri($job['keyword']),
                'source'  => $uri,
                'log'     => $log,
                'back'    => true,
                'related' => [keyword_uri("Mister Rogers'")],
            ]);
        }
    }
    if (count($state['nodes']) > 80) {
        $state['nodes'] = array_slice($state['nodes'], 0, 80);
    }
    save_web($state);
    return [
        'ok'      => true,
        'pending' => !empty($state['queue']),
        'wait'    => $wait,
        'nodes'   => $fresh,
    ];
}

// ---------------------------------------------------------------------------
// Robots.txt Publication
// ---------------------------------------------------------------------------

function build_robots(array $state): string
{
    $lines = [
        'User-agent: *',
        'Allow: /',
        'Disallow: /provider-logs/',
        'Disallow: /robots-cache/',
        'Disallow: /search-providers.json',
        'Disallow: /provider-ban.json',
        'Disallow: /crawl-web.json',
        'Disallow: /crawl-circular.log',
        'Crawl-delay: 3',
        'Sitemap: ' . full_uri(''),
        '# keyword web',
    ];
    foreach ($state['nodes'] as $node) {
        $lines[] = '# ' . $node['uri'];
        if (!empty($node['source'])) {
            $lines[] = '# source ' . $node['source'];
        }
        if (!empty($node['log'])) {
            $lines[] = '# log ' . $node['log'];
        }
    }
    return implode("\n", $lines) . "\n";
}

function publish_robots(array $state): string
{
    $body = build_robots($state);
    $targets = [__DIR__ . '/robots.txt'];
    if (!empty($_SERVER['DOCUMENT_ROOT'])) {
        $targets[] = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/robots.txt';
    }
    foreach (array_unique($targets) as $path) {
        if (is_file($path) && time() - filemtime($path) < 3600 && md5_file($path) === md5($body)) {
            continue;
        }
        file_put_contents($path, $body, LOCK_EX);
    }
    return $body;
}

// ---------------------------------------------------------------------------
// Local Folder Scan & Circular Detection
// ---------------------------------------------------------------------------

function resolve_href(string $href, string $fromRel): ?string
{
    $href = trim(html_entity_decode($href));
    if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'javascript:') === 0) {
        return null;
    }
    $mine = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : 'cmdr.site';
    if (preg_match('#^https?://#i', $href)) {
        $parts = parse_url($href);
        $host = $parts['host'] ?? '';
        if (strcasecmp($host, $mine) !== 0 && strcasecmp($host, 'cmdr.site') !== 0) {
            return null;
        }
        $path = $parts['path'] ?? '/';
    } elseif (strpos($href, '//') === 0) {
        return null;
    } else {
        $base = $fromRel === '' ? '/' : '/' . trim($fromRel, '/') . '/';
        $path = ($href[0] === '/') ? $href : $base . $href;
    }
    $segs = [];
    foreach (explode('/', $path) as $seg) {
        if ($seg === '' || $seg === '.') {
            continue;
        }
        if ($seg === '..') {
            array_pop($segs);
            continue;
        }
        $segs[] = $seg;
    }
    return full_uri(implode('/', $segs));
}

function page_links(string $absDir, string $rel): array
{
    $links = [];
    foreach (['index.html', 'index.htm'] as $name) {
        $file = rtrim($absDir, '/') . '/' . $name;
        if (!is_file($file)) {
            continue;
        }
        $html = file_get_contents($file);
        if (!$html || !preg_match_all('/<a\b[^>]*\bhref\s*=\s*([\'"])(.*?)\1/i', $html, $m)) {
            continue;
        }
        foreach ($m[2] as $href) {
            $uri = resolve_href($href, $rel);
            if ($uri) {
                $links[] = $uri;
            }
        }
    }
    return array_values(array_unique($links));
}

function note_circular(array &$logs, array $steps): string
{
    $trail = [];
    foreach ($steps as $step) {
        $trail[] = full_uri($step);
    }
    $line = implode(' -> ', $trail);
    foreach ($steps as $step) {
        if (!isset($logs[$step])) {
            $logs[$step] = [];
        }
        if (!in_array($line, $logs[$step], true)) {
            $logs[$step][] = $line;
        }
    }
    return $line;
}

function crawl_circular(string $base, array $folders, array &$logs): void
{
    $byUri = [full_uri('') => ''];
    foreach ($folders as $rel) {
        $byUri[full_uri($rel)] = $rel;
    }
    $stack = [];
    $walk = function (string $rel) use (&$walk, &$stack, &$logs, $base, $byUri): void {
        $uri = full_uri($rel);
        $loopAt = array_search($uri, $stack, true);
        if ($loopAt !== false) {
            $steps = [];
            foreach (array_slice($stack, $loopAt) as $step) {
                $steps[] = $byUri[$step] ?? trim((string) parse_url($step, PHP_URL_PATH), '/');
            }
            $steps[] = $rel;
            note_circular($logs, $steps);
            return;
        }
        if (count($stack) > 12) {
            return;
        }
        $stack[] = $uri;
        $dir = $base . ($rel === '' ? '' : '/' . $rel);
        if (is_dir($dir)) {
            foreach (page_links($dir, $rel) as $next) {
                if (isset($byUri[$next])) {
                    $walk($byUri[$next]);
                }
            }
        }
        array_pop($stack);
    };
    $walk('');
    foreach ($folders as $rel) {
        $walk($rel);
    }
}

function save_circular_log(array $logs): void
{
    $all = [];
    if (is_file(LOG_CIRCULAR)) {
        foreach (file(LOG_CIRCULAR, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $row) {
            $bit = strpos($row, "\t") !== false ? substr($row, strpos($row, "\t") + 1) : $row;
            $all[$bit] = true;
        }
    }
    foreach ($logs as $lines) {
        foreach ($lines as $line) {
            $all[$line] = true;
        }
    }
    $out = '';
    foreach (array_keys($all) as $line) {
        $out .= date('c') . "\t" . $line . "\n";
    }
    if ($out !== '') {
        file_put_contents(LOG_CIRCULAR, $out, LOCK_EX);
    }
}

// ---------------------------------------------------------------------------
// PWA Assets
// ---------------------------------------------------------------------------

function app_manifest(): string
{
    return json_encode([
        'id'                       => 'https://cmdr.site/',
        'name'                     => "Mister Rogers' Neighborhood",
        'short_name'               => "Mister Rogers'",
        'description'              => 'Inquiry, consultation, and integration for HyperWeb network work.',
        'start_url'                => '/?source=pwa',
        'scope'                    => '/',
        'display'                  => 'standalone',
        'display_override'         => ['window-controls-overlay', 'standalone', 'minimal-ui'],
        'background_color'         => '#ffffff',
        'theme_color'              => '#ffffff',
        'lang'                     => 'en',
        'dir'                      => 'ltr',
        'categories'               => ['utilities', 'lifestyle'],
        'prefer_related_applications' => false,
        'handle_links'             => 'preferred',
        'launch_handler'           => ['client_mode' => 'navigate-existing'],
        'icons'                    => [
            ['src' => '/favicon.svg', 'sizes' => 'any', 'type' => 'image/svg+xml', 'purpose' => 'any'],
            ['src' => '/Banner.jpg', 'sizes' => '1792x1008', 'type' => 'image/jpeg', 'purpose' => 'any'],
        ],
    ], JSON_UNESCAPED_SLASHES);
}

function app_worker(): string
{
    $path = __DIR__ . '/sw.js';
    return is_file($path) ? file_get_contents($path) : "self.addEventListener('fetch',function(){});";
}

// ---------------------------------------------------------------------------
// Request Handling
// ---------------------------------------------------------------------------

$uriPath = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : '/';

if (isset($_GET['robots']) || preg_match('#/robots\.txt$#', $_SERVER['REQUEST_URI'] ?? '')) {
    header('Content-Type: text/plain; charset=utf-8');
    echo publish_robots(load_web());
    exit;
}

if (isset($_GET['manifest']) || $uriPath === '/manifest.webmanifest') {
    header('Content-Type: application/manifest+json; charset=utf-8');
    header('Cache-Control: public, max-age=3600');
    echo app_manifest();
    exit;
}

if (isset($_GET['sw']) || $uriPath === '/sw.js') {
    header('Content-Type: application/javascript; charset=utf-8');
    header('Service-Worker-Allowed: /');
    header('Cache-Control: no-cache');
    echo app_worker();
    exit;
}

if (isset($_GET['prepare']) || $uriPath === '/prepare') {
    header('HTTP/1.1 204 No Content');
    header('Cache-Control: no-store');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seek'])) {
    header('Content-Type: application/json');
    $list = load_providers();

    if ($_POST['seek'] === 'crawl') {
        $step = crawl_step();
        publish_robots(load_web());
        echo json_encode($step);
        exit;
    }

    if ($_POST['seek'] === 'hit' && isset($_POST['id'])) {
        foreach ($list as &$row) {
            if ($row['id'] === $_POST['id']) {
                $row['hits'] = ($row['hits'] ?? 0) + 1;
                $row['updated'] = time();
            }
        }
        unset($row);
        save_providers($list);
        echo json_encode(['ok' => true, 'providers' => $list]);
        exit;
    }

    if ($_POST['seek'] === 'discover') {
        $raw = $_POST['q'] ?? '';
        $via = $_POST['via'] ?? '';
        $ban = load_ban();
        if (is_banned($raw, $ban)) {
            echo json_encode(['ok' => false, 'banned' => true]);
            exit;
        }
        $fixed = autocorrect($raw);
        if ($fixed) {
            echo json_encode(['ok' => true, 'autocorrect' => $fixed]);
            exit;
        }
        $lookup = 'https://duckduckgo.com/html/?q={term}';
        $ai = 'https://www.perplexity.ai/search?q={term}';
        foreach ($list as $row) {
            if ($row['id'] === $via) {
                $lookup = $row['template'];
            }
            if ($row['id'] === 'perplexity' || $row['id'] === 'you') {
                $ai = $row['template'];
            }
        }
        $q = rawurlencode('"' . $raw . '" SearchAction URL pattern');
        $normal = patterns_from_dom(http_get(str_replace('{term}', $q, $lookup)), $raw);
        $ai1 = patterns_from_dom(http_get(str_replace('{term}', $q, $ai)), $raw);
        $ai2 = patterns_from_dom(http_get(str_replace('{term}', $q, $ai)), $raw);
        $chosen = pick_three([$normal, $ai1, $ai2], 1);
        if (!$chosen) {
            note_fail($raw);
            echo json_encode(['ok' => false, 'asks' => 3]);
            exit;
        }
        echo json_encode(['ok' => true, 'name' => $raw, 'template' => $chosen]);
        exit;
    }

    if ($_POST['seek'] === 'add') {
        $name = substr(preg_replace('/[^\w .\-]/', '', trim($_POST['name'] ?? '')), 0, 40);
        $template = normalize_template(trim($_POST['template'] ?? ''));
        if ($name !== '' && valid_template($template)) {
            $id = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));
            $found = false;
            foreach ($list as &$row) {
                if ($row['id'] === $id) {
                    $row['template'] = $template;
                    $row['name'] = $name;
                    $row['updated'] = time();
                    $found = true;
                }
            }
            unset($row);
            if (!$found) {
                $list[] = ['id' => $id, 'name' => $name, 'template' => $template, 'hits' => 0, 'updated' => time()];
            }
            save_providers($list);
            claim_aliases($name);
            echo json_encode(['ok' => true, 'id' => $id, 'providers' => $list]);
            exit;
        }
        echo json_encode(['ok' => false]);
        exit;
    }

    echo json_encode(['ok' => false]);
    exit;
}

// ---------------------------------------------------------------------------
// Main Page Data
// ---------------------------------------------------------------------------

$web = load_web();
publish_robots($web);
$providers = load_providers();
usort($providers, function ($a, $b) {
    $na = ($a['hits'] ?? 0) + ((time() - ($a['updated'] ?? 0)) < 604800 ? 3 : 0);
    $nb = ($b['hits'] ?? 0) + ((time() - ($b['updated'] ?? 0)) < 604800 ? 3 : 0);
    if ($na === $nb) {
        return ($b['updated'] ?? 0) - ($a['updated'] ?? 0);
    }
    return $nb - $na;
});
$providers = array_slice($providers, 0, 16);

$base = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : __DIR__;
$skip = '/^(?:cgi-bin|node_modules|vendor|assets|static|css|js|img|images|fonts)$/i';
$circular = [];
$realStack = [];
$relStack = [];

$scan = function (string $rel) use (&$scan, &$circular, &$realStack, &$relStack, $base, $skip): array {
    $full = $base . ($rel === '' ? '' : '/' . $rel);
    $real = realpath($full);
    if ($real && in_array($real, $realStack, true)) {
        note_circular($circular, array_merge($relStack, [$rel]));
        return [];
    }
    if ($real) {
        $realStack[] = $real;
    }
    $relStack[] = $rel;
    $found = [];
    $files = false;
    $subs = [];
    $names = @scandir($full);
    if (!$names) {
        array_pop($relStack);
        if ($real) {
            array_pop($realStack);
        }
        return $found;
    }
    foreach ($names as $name) {
        if ($name === '.' || $name === '..' || $name[0] === '.') {
            continue;
        }
        $path = $full . '/' . $name;
        if (is_dir($path)) {
            if (!preg_match($skip, $name)) {
                $subs[] = ($rel === '' ? $name : $rel . '/' . $name);
            }
        } elseif (is_file($path)) {
            $files = true;
        }
    }
    $children = [];
    foreach ($subs as $sub) {
        $children = array_merge($children, $scan($sub));
    }
    if ($rel !== '' && ($files || $children)) {
        $found[] = $rel;
    }
    array_pop($relStack);
    if ($real) {
        array_pop($realStack);
    }
    return array_merge($found, $children);
};

$folders = array_values(array_unique($scan('')));
crawl_circular($base, $folders, $circular);
save_circular_log($circular);

$parts = [];
foreach ($folders as $p) {
    $parts[] = explode('/', $p);
}
$items = [];
foreach ($parts as $i => $segs) {
    $label = $segs[count($segs) - 1];
    for ($n = 1; $n <= count($segs); $n++) {
        $tail = implode('/', array_slice($segs, -$n));
        $hits = 0;
        foreach ($parts as $other) {
            if (implode('/', array_slice($other, -$n)) === $tail) {
                $hits++;
            }
        }
        if ($hits === 1) {
            $label = $tail;
            break;
        }
    }
    $items[] = [
        'path'    => $folders[$i],
        'label'   => $label,
        'keyword' => $label,
        'uri'     => full_uri($folders[$i]),
        'log'     => isset($circular[$folders[$i]]) ? implode(' | ', $circular[$folders[$i]]) : '',
    ];
}
foreach ($web['nodes'] as $node) {
    $items[] = [
        'path'    => 'k/' . strtolower(preg_replace('/[^a-z0-9]+/i', '-', $node['keyword'])),
        'label'   => $node['keyword'],
        'keyword' => $node['keyword'],
        'uri'     => $node['uri'],
        'source'  => $node['source'] ?? '',
        'log'     => $node['log'] ?? '',
    ];
}
shuffle($items);

$focus = isset($_GET['k']) ? (string) $_GET['k'] : '';
$warn = lookup_k($web, $focus);
$prepare = $warn ? site_origin() . '/prepare?k=' . rawurlencode($warn['keyword']) : '';
$ping = $warn ? $warn['source'] . ' ' . $prepare : '';
$pageTitle = $warn ? ($warn['keyword'] . " — leaving Mister Rogers'") : "Mister Rogers' - Website";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, user-scalable=yes">
<title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></title>
<link rel="icon" href="image/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="https://cmdr.site/manifest.webmanifest">
<meta name="theme-color" content="#ffffff">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Mister Rogers'">
<meta property="og:site_name" content="Mister Rogers'">
<meta property="og:title" content="<?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?>">
<meta property="og:url" content="<?php echo htmlspecialchars($focus !== '' ? keyword_uri($focus) : 'https://cmdr.site/', ENT_QUOTES, 'UTF-8'); ?>">
<meta property="og:type" content="website">
<meta property="og:image" content="https://cmdr.site/image/banner.jpg">
<meta property="og:image:secure_url" content="https://cmdr.site/image/banner.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1792">
<meta property="og:image:height" content="1008">
<meta property="og:image:alt" content="Mister Rogers' Neighborhood banner.">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?>">
<meta name="twitter:image" content="https://cmdr.site/image/banner.jpg">
<meta name="twitter:image:alt" content="Mister Rogers' Neighborhood banner.">
<meta property="fb:app_id" content="1131234549584012" />
<meta name="description" content="Mister Rogers' Neighborhood offers inquiry, consultation, and integration services and products for HyperWeb network work, research, and project management.">
<meta property="og:description" content="Mister Rogers' Neighborhood offers inquiry, consultation, and integration services and products for HyperWeb network work, research, and project management.">
<meta name="twitter:description" content="Mister Rogers' Neighborhood offers inquiry, consultation, and integration services and products for HyperWeb network work, research, and project management.">
<link rel="stylesheet" href="https://cmdr.site/style/a.css">
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v25.0&appId=965328948410130"></script>
<script src="script/d.js"></script>
</head>
<body>
<nav>
<ul>
<li><p>&para;<a href="https://cmdr.site" title="Mister Rogers' - Website"><b>M</b>ister&nbsp;<b>R</b>ogers'</a>&nbsp;<img src="favicon.svg" alt="LinkedIn" /></p></li>
<li><p><a href="#" title="Mister Rogers' - Neighborhood">Neighborhood</a>:</p></li>
<li><p><a href="https://www.youtube.com/@CMDRSit" target="_blank" title="Mister Rogers' - YouTube"><img src="https://cmdr.site/image/youtube.png" alt="YouTube" /></a>&#44;</p></li>
<li><p><a href="https://www.linkedin.com/in/cmdr-site/" target="_blank" title="Mister Rogers' - LinkedIn"><img src="https://cmdr.site/image/linkedin.svg" alt="LinkedIn" /></a>&#44;</p></li>
<li><p><a href="https://github.com/FecITheLion/" target="_blank" title="Mister Rogers' - GitHub"><img src="https://cmdr.site/image/github.svg" alt="GitHub" /></a>&#44;</p></li>
<li><p><a href="https://www.facebook.com/CMDRSit/" target="_blank" title="Mister Rogers' - Facebook"><img src="https://cmdr.site/image/facebook.ico" alt="Facebook" /></a>&#44;</p></li>
<li><p><a href="https://x.com/bidth64892" target="_blank" title="Mister Rogers' - Twitter"><img src="https://cmdr.site/image/twitter.ico" alt="Twitter" /></a>&nbsp;&amp;</p></li>
<li><p><a href="https://www.instagram.com/cmdr.site" target="_blank" title="Mister Rogers' - Instagram"><img src="https://cmdr.site/image/instagram.png" alt="Instagram" /></a>&period;&dagger;</p></li>
<li><p><button type="button" id="install-app" hidden>Install</button></p></li>
</ul>
</nav>
<?php if ($warn): ?>
<div id="redirect-warn" role="dialog" aria-labelledby="warn-title">
<div class="card">
<h1 id="warn-title">Leaving Mister Rogers'</h1>
<p><b><?php echo htmlspecialchars($warn['keyword'], ENT_QUOTES, 'UTF-8'); ?></b> resolves off this application.</p>
<p>Destination: <code><?php echo htmlspecialchars($warn['source'], ENT_QUOTES, 'UTF-8'); ?></code></p>
<p>Continue sends a ping so the destination can prepare, then opens it.</p>
<p>
<a class="go" href="<?php echo htmlspecialchars($warn['source'], ENT_QUOTES, 'UTF-8'); ?>"
   ping="<?php echo htmlspecialchars($ping, ENT_QUOTES, 'UTF-8'); ?>"
   rel="noopener noreferrer">Continue</a>
<a href="<?php echo htmlspecialchars(site_origin() . '/', ENT_QUOTES, 'UTF-8'); ?>">Stay</a>
</p>
<?php if (!empty($warn['log'])): ?><p><?php echo htmlspecialchars($warn['log'], ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>
</div>
</div>
<?php endif; ?>
<section id="keywordweb" aria-label="Keyword web">
<?php foreach ($web['nodes'] as $node): ?>
<a href="<?php echo htmlspecialchars($node['uri'], ENT_QUOTES, 'UTF-8'); ?>"
   data-keyword="<?php echo htmlspecialchars($node['keyword'], ENT_QUOTES, 'UTF-8'); ?>"
   data-log="<?php echo htmlspecialchars($node['log'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
   data-source="<?php echo htmlspecialchars($node['source'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
   data-back="<?php echo !empty($node['back']) ? '1' : '0'; ?>"
   <?php if ($focus !== '' && strcasecmp($focus, $node['keyword']) === 0) echo 'data-current="1"'; ?>><?php echo htmlspecialchars($node['keyword'], ENT_QUOTES, 'UTF-8'); ?></a>
<?php if (!empty($node['source']) && !is_home($node['source'])): ?>
<a href="<?php echo htmlspecialchars($node['source'], ENT_QUOTES, 'UTF-8'); ?>" rel="external"
   ping="<?php echo htmlspecialchars($node['source'] . ' ' . site_origin() . '/prepare?k=' . rawurlencode($node['keyword']), ENT_QUOTES, 'UTF-8'); ?>"
   data-keyword="<?php echo htmlspecialchars($node['keyword'], ENT_QUOTES, 'UTF-8'); ?>"
   data-log="<?php echo htmlspecialchars($node['log'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($node['keyword'], ENT_QUOTES, 'UTF-8'); ?> source</a>
<?php endif; ?>
<?php if (!empty($node['related'])): foreach ($node['related'] as $relUri): ?>
<a href="<?php echo htmlspecialchars($relUri, ENT_QUOTES, 'UTF-8'); ?>"
   data-keyword="<?php echo htmlspecialchars($node['keyword'], ENT_QUOTES, 'UTF-8'); ?>"
   data-related="1"><?php echo htmlspecialchars($node['keyword'], ENT_QUOTES, 'UTF-8'); ?> related</a>
<?php endforeach; endif; ?>
<?php endforeach; ?>
</section>
<?php if ($items): ?>
<div id="folderpool" aria-label="Folders">
<form id="seekbox">
<input id="prov" placeholder="Provider" list="provlist" autocomplete="off">
<datalist id="provlist"></datalist>
<input id="q" placeholder="Search term">
<button type="button" data-ai="specify" title="Specify">+</button>
<button type="button" data-ai="general" title="Generalize">−</button>
<button type="submit">Search</button>
</form>
</div>
<!-- [A|B&C] -->
<script>

(function () {
    var items = <?php echo json_encode($items); ?>;
    var providers = <?php echo json_encode($providers); ?>;
    var host = document.getElementById('folderpool');
    var box = document.getElementById('seekbox');
    var prov = document.getElementById('prov');
    var q = document.getElementById('q');
    var list = document.getElementById('provlist');
    var web = document.getElementById('keywordweb');
    var cars = [], last = 0, aim = null, mouseSpeed = 0, hueOf = {}, AGGRO = 160;
    var endpoint = location.pathname;
    var activeTouchId = null;
    var isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
    var tracking = false;
    var touchStart = null;
    var TAP_THRESHOLD = 12;
    var TAP_TIME = 300;

    function getConsent() { return localStorage.getItem('cmdr-consent') === 'accepted'; }
    function setConsent(val) { localStorage.setItem('cmdr-consent', val); }
    function getPref() { return getConsent() ? (localStorage.getItem('cmdr-search-pref') || '') : ''; }
    function setPref(id) { if (getConsent()) localStorage.setItem('cmdr-search-pref', id); }
    var pref = getPref();

    if (pref) providers = providers.filter(function (p) { return p.id === pref; }).concat(providers.filter(function (p) { return p.id !== pref; })).slice(0, 1);

    function hue(path) {
        if (hueOf[path]) return hueOf[path];
        var h = 0;
        for (var i = 0; i < path.length; i++) h = (h * 33 + path.charCodeAt(i)) % 360;
        hueOf[path] = h;
        return h;
    }
    function postSeek(body) {
        return fetch(endpoint, { method: 'POST', body: body, headers: { 'Accept': 'application/json' } }).then(function (r) {
            return r.text().then(function (text) {
                if (text.charAt(0) !== '{') throw new Error('not json');
                return JSON.parse(text);
            });
        });
    }
    function fillList(needle) {
        var n = (needle || '').toLowerCase();
        list.innerHTML = '';
        providers.filter(function (p) { return !n || p.name.toLowerCase().indexOf(n) === 0; }).forEach(function (p) {
            var o = document.createElement('option');
            o.value = p.name;
            list.appendChild(o);
        });
    }
    function matchProv(text) {
        var t = text.trim().toLowerCase();
        for (var i = 0; i < providers.length; i++) if (providers[i].name.toLowerCase() === t) return providers[i];
        return null;
    }
    function parseNew(text) {
        text = text.trim();
        if (text.charAt(0) === '{') {
            try {
                var ld = JSON.parse(text);
                var action = ld.potentialAction;
                if (Array.isArray(action)) action = action[0];
                var target = action && action.target;
                var template = typeof target === 'string' ? target : (target && target.urlTemplate) || ld.urlTemplate || '';
                var name = ld.name || (template.indexOf('youtube.com') !== -1 ? 'YouTube' : 'Custom');
                return template ? { name: name, template: template.replace(/\{[a-z0-9_]+\}/i, '{term}') } : null;
            } catch (e) { return null; }
        }
        var url = text.match(/https:\/\/\S+/);
        if (!url) return null;
        var template = url[0].replace(/\{[a-z0-9_]+\}/i, '{term}');
        if (template.indexOf('{term}') === -1) template += (template.indexOf('?') === -1 ? '?q={term}' : '&q={term}');
        var name = text.slice(0, url.index).trim();
        if (!name) name = /youtube\.com/.test(template) ? 'YouTube' : 'Custom';
        return { name: name, template: template };
    }
    function failProv() {
        prov.classList.remove('bad');
        void prov.offsetWidth;
        prov.classList.add('bad');
        prov.style.background = '#ffd0d0';
        prov.focus();
        prov.select();
    }
    function saveNew(info) {
        var body = new FormData();
        body.append('seek', 'add');
        body.append('name', info.name);
        body.append('template', info.template);
        return postSeek(body).then(function (data) {
            if (!data.ok) return null;
            providers = data.providers;
            pref = data.id;
            setPref(data.id);
            prov.value = info.name;
            prov.classList.remove('bad');
            prov.style.background = '';
            fillList('');
            return matchProv(info.name);
        });
    }
    function discover(text) {
        var body = new FormData();
        body.append('seek', 'discover');
        body.append('q', text);
        body.append('via', pref || (providers[0] && providers[0].id) || '');
        return postSeek(body).then(function (data) {
            if (data.banned) { failProv(); return null; }
            if (data.autocorrect) {
                var hit = providers.filter(function (p) { return p.id === data.autocorrect; })[0];
                if (hit) { prov.value = hit.name; pref = hit.id; setPref(hit.id); return hit; }
            }
            if (!data.ok) { failProv(); return null; }
            return saveNew({ name: data.name, template: data.template });
        }).catch(function () { failProv(); return null; });
    }
    function commitProv() {
        var known = matchProv(prov.value);
        if (known) { pref = known.id; setPref(known.id); prov.classList.remove('bad'); prov.style.background = ''; return Promise.resolve(known); }
        var info = parseNew(prov.value);
        if (info) return saveNew(info);
        if (prov.value.trim().length < 2) return Promise.resolve(null);
        return discover(prov.value);
    }
    function go(p) {
        if (!p || !q.value.trim()) { if (!p) failProv(); return; }
        window.open(p.template.replace('{term}', encodeURIComponent(q.value.trim())), '_blank', 'noopener');
        var body = new FormData();
        body.append('seek', 'hit');
        body.append('id', p.id);
        postSeek(body).catch(function () {});
        box.style.display = 'none';
    }
    function rewrite(mode) {
        var words = q.value.replace(/[_-]+/g, ' ').trim();
        q.value = mode === 'specify' ? words + ' exact directory name meaning' : words.split('/').pop().split(' ')[0];
        q.focus();
    }
    function placeBox() {
        box.style.display = 'flex';
        box.style.left = '0';
        box.style.top = '0';
        box.style.transform = 'none';
        var pad = 12;
        var vw = window.innerWidth;
        var vh = window.innerHeight;
        var bw = box.offsetWidth;
        var bh = box.offsetHeight;
        var left = Math.max(pad, Math.min((vw - bw) / 2, vw - bw - pad));
        var top  = Math.max(pad, Math.min((vh - bh) / 2, vh - bh - pad));
        box.style.left = left + 'px';
        box.style.top  = top  + 'px';
    }
    function paintLink(node) {
        if (!web || !node || !node.uri) return;
        var sel = 'a[data-keyword="' + node.keyword.replace(/"/g, '') + '"][href="' + node.uri.replace(/"/g, '') + '"]';
        if (web.querySelector(sel)) return;
        var a = document.createElement('a');
        a.href = node.uri;
        a.textContent = node.keyword;
        a.setAttribute('data-keyword', node.keyword);
        a.setAttribute('data-log', node.log || '');
        a.setAttribute('data-source', node.source || '');
        a.setAttribute('data-back', node.back ? '1' : '0');
        web.appendChild(a);
        if (node.source) {
            var s = document.createElement('a');
            s.href = node.source;
            s.rel = 'external';
            s.setAttribute('ping', node.source + ' ' + location.origin + '/prepare?k=' + encodeURIComponent(node.keyword));
            s.textContent = node.keyword + ' source';
            s.setAttribute('data-keyword', node.keyword);
            s.setAttribute('data-log', node.log || '');
            web.appendChild(s);
        }
    }
    function crawlStep() {
        var body = new FormData();
        body.append('seek', 'crawl');
        postSeek(body).then(function (data) {
            (data.nodes || []).forEach(paintLink);
            if (data.pending) setTimeout(crawlStep, data.wait || 3000);
        }).catch(function () { setTimeout(crawlStep, 8000); });
    }
    var provTimer = null;
    prov.addEventListener('input', function () {
        fillList(prov.value);
        clearTimeout(provTimer);
        provTimer = setTimeout(function () { commitProv(); }, 700);
    });
    prov.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        commitProv().then(function (p) { if (p) q.focus(); });
    });
    box.addEventListener('click', function (e) {
        var ai = e.target.getAttribute('data-ai');
        if (ai) { e.preventDefault(); rewrite(ai); }
    });
    box.addEventListener('submit', function (e) {
        e.preventDefault();
        commitProv().then(go);
    });
    q.addEventListener('keydown', function (e) {
        if (e.key === '+') { e.preventDefault(); rewrite('specify'); }
        if (e.key === '-') { e.preventDefault(); rewrite('general'); }
    });

    function mark(e) {
        var r = host.getBoundingClientRect();
        var x = (e.clientX || (e.touches && e.touches[0] && e.touches[0].clientX)) - r.left;
        var y = (e.clientY || (e.touches && e.touches[0] && e.touches[0].clientY)) - r.top;
        if (isNaN(x) || isNaN(y)) return;
        if (aim) mouseSpeed = Math.hypot(x - aim.x, y - aim.y) / Math.max(0.016, ((e.timeStamp || Date.now()) - aim.t) / 1000);
        aim = { x: x, y: y, t: e.timeStamp || Date.now() };
    }

    function setHotFromPoint(x, y) {
        var closest = null, minDist = Infinity;
        cars.forEach(function (car) {
            var dx = x - (car.x + (car.el.offsetWidth || 80) * 0.5);
            var dy = y - (car.y + (car.el.offsetHeight || 24) * 0.5);
            var d = Math.hypot(dx, dy);
            if (d < minDist && d < AGGRO * 1.4) {
                minDist = d;
                closest = car;
            }
        });
        cars.forEach(function (car) { car.hot = (car === closest); });
        return closest;
    }

    function elementAt(x, y) {
        var el = document.elementFromPoint(x, y);
        return el && el.closest ? el.closest('.pill') : null;
    }

    window.addEventListener('pointermove', mark);
    window.addEventListener('pointerdown', mark);
    window.addEventListener('pointerleave', function () { aim = null; });

    host.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) return;
        var t = e.touches[0];
        activeTouchId = t.identifier;
        mark(e);
        var pill = elementAt(t.clientX, t.clientY);
        touchStart = { x: t.clientX, y: t.clientY, t: Date.now(), pill: pill };
        tracking = !!pill;
        if (pill) setHotFromPoint(aim.x, aim.y);
    }, { passive: true });

    host.addEventListener('touchmove', function (e) {
        if (!activeTouchId || !touchStart) return;
        for (var i = 0; i < e.touches.length; i++) {
            if (e.touches[i].identifier === activeTouchId) {
                var t = e.touches[i];
                var dx = t.clientX - touchStart.x;
                var dy = t.clientY - touchStart.y;
                if (Math.hypot(dx, dy) > TAP_THRESHOLD) {
                    tracking = true;
                    mark(e);
                    setHotFromPoint(aim.x, aim.y);
                    e.preventDefault();
                }
                break;
            }
        }
    }, { passive: false });

    host.addEventListener('touchend', function (e) {
        var still = false;
        for (var i = 0; i < e.touches.length; i++) {
            if (e.touches[i].identifier === activeTouchId) still = true;
        }
        if (still) return;

        if (touchStart && touchStart.pill) {
            var dt = Date.now() - touchStart.t;
            var dx = 0, dy = 0;
            if (e.changedTouches && e.changedTouches[0]) {
                dx = e.changedTouches[0].clientX - touchStart.x;
                dy = e.changedTouches[0].clientY - touchStart.y;
            }
            if (dt < TAP_TIME && Math.hypot(dx, dy) < TAP_THRESHOLD) {
                var target = document.elementFromPoint(touchStart.x, touchStart.y);
                var seek = target && target.closest ? target.closest('.seek') : null;
                var link = target && target.closest ? target.closest('a') : null;
                var toClick = seek || link || touchStart.pill;
                if (toClick) {
                    var click = new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window,
                        clientX: touchStart.x,
                        clientY: touchStart.y
                    });
                    toClick.dispatchEvent(click);
                }
            }
        }

        activeTouchId = null;
        tracking = false;
        touchStart = null;
        cars.forEach(function (car) { car.hot = false; });
        setTimeout(function () { if (!activeTouchId) aim = null; }, 400);
    });

    host.addEventListener('touchcancel', function () {
        activeTouchId = null;
        tracking = false;
        touchStart = null;
        cars.forEach(function (car) { car.hot = false; });
        aim = null;
    });

    fillList('');

    var seen = {};
    items.forEach(function (item) {
        if (seen[item.path]) return;
        seen[item.path] = true;
        var pill = document.createElement('div');
        pill.className = 'pill';
        var a = document.createElement('a');
        a.href = item.uri;
        a.textContent = item.label;
        a.title = item.log ? item.uri + ' | ' + item.log : item.uri;
        a.setAttribute('data-keyword', item.keyword || item.label);
        a.setAttribute('data-log', item.log || '');
        if (item.source) {
            a.setAttribute('data-source', item.source);
            a.setAttribute('ping', item.source + ' ' + location.origin + '/prepare?k=' + encodeURIComponent(item.keyword || item.label));
        }
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'seek';
        b.textContent = '⌕';
        var ang = Math.random() * Math.PI * 2, spd = 18 + Math.random() * 42;
        var car = {
            el: pill, path: item.path, uri: item.uri, log: item.log || '',
            x: Math.random() * (host.clientWidth || 800),
            y: Math.random() * (host.clientHeight || 500),
            vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd,
            heat: 0, hot: false, off: Math.random() * Math.PI * 2
        };
        b.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            q.value = item.keyword || item.label;
            var chosen = providers.filter(function (p) { return p.id === pref; })[0] || providers[0];
            prov.value = chosen ? chosen.name : '';
            placeBox();
            prov.focus();
        });
        pill.appendChild(a);
        pill.appendChild(b);
        if (item.log) {
            var log = document.createElement('span');
            log.className = 'crawl-log';
            log.hidden = true;
            log.textContent = item.log;
            pill.appendChild(log);
        }
        host.appendChild(pill);
        cars.push(car);
        pill.addEventListener('mouseenter', function () { car.hot = true; });
        pill.addEventListener('mouseleave', function () { car.hot = false; });
    });

    function frame(now) {
        var dt = Math.min(0.05, (now - last) / 1000 || 0.016);
        last = now;
        var w = host.clientWidth || 1, h = host.clientHeight || 1, caught = null;
        cars.forEach(function (car) {
            var wide = car.el.offsetWidth || 80, tall = car.el.offsetHeight || 24;
            var dist = aim ? Math.hypot(aim.x - car.x, aim.y - car.y) : Infinity;
            var near = aim && dist < AGGRO;
            if (car.hot && aim) {
                var cap = Math.max(40, mouseSpeed * 0.45);
                var dx = aim.x - wide * 0.35 - car.x, dy = aim.y - tall * 0.45 - car.y, len = Math.hypot(dx, dy) || 1;
                car.vx += (dx / len) * cap * 3 * dt;
                car.vy += (dy / len) * cap * 3 * dt;
                var sp = Math.hypot(car.vx, car.vy);
                if (sp > cap) { car.vx = car.vx / sp * cap; car.vy = car.vy / sp * cap; }
                caught = car;
            } else if (near) {
                car.vx += (aim.x + Math.cos(car.off) * 36 - car.x) * 0.35 * dt;
                car.vy += (aim.y + Math.sin(car.off) * 28 - car.y) * 0.35 * dt;
            } else {
                car.vx += (Math.random() - 0.5) * 40 * dt;
                car.vy += (Math.random() - 0.5) * 40 * dt;
            }
            var drift = Math.hypot(car.vx, car.vy), maxDrift = car.hot ? 999 : 70;
            if (drift > maxDrift) { car.vx = car.vx / drift * maxDrift; car.vy = car.vy / drift * maxDrift; }
            car.x += car.vx * dt; car.y += car.vy * dt;
            if (car.x < -wide) car.x = w;
            if (car.x > w) car.x = -wide;
            if (car.y < -tall) car.y = h;
            if (car.y > h) car.y = -tall;
            car.heat = car.hot ? car.heat + dt : Math.max(0, car.heat - dt);
            var unit = Math.min(car.heat, 8) / 8;
            car.el.style.zIndex = car.hot ? 6 : (near ? 4 : 3);
            car.el.style.transform = 'translate(' + car.x + 'px,' + car.y + 'px)';
            car.el.style.filter = 'grayscale(' + (1 - unit) + ') brightness(' + (0.75 + unit * 0.7) + ')';
            car.el.style.background = 'hsl(' + hue(car.path) + ', ' + Math.round(8 + unit * 42) + '%, ' + Math.round(96 - unit * 18) + '%)';
        });
        if (caught) caught.el.style.zIndex = 7;
        requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    setTimeout(crawlStep, 1500);
})();

</script>
<?php endif; ?>
<!-- [B&C] -->
<script src="script/b.js" defer></script>
<script src="script/c.js" defer></script>
</body>
</html>