<?php

declare(strict_types=1);

/**
 * Front controller.
 * Business logic is split into object-oriented modules in ./local/.
 */
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Cross-Origin-Resource-Policy: cross-origin');

require_once __DIR__ . '/local/bootstrap.php';

AppController::run();
