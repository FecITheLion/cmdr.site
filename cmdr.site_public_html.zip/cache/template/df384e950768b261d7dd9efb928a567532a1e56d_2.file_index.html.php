<?php
/* Smarty version 5.8.5, created on 2026-10-16 06:39:28
  from 'file:index.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.8.5',
  'unifunc' => 'content_6ad1c6a0b26d10_40132674',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'df384e950768b261d7dd9efb928a567532a1e56d' => 
    array (
      0 => 'index.html',
      1 => 1792132766,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6ad1c6a0b26d10_40132674 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/home/nukeofwar/public_html/templates';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, user-scalable=yes">
<title><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('pageTitle')), ENT_QUOTES, 'UTF-8');?>
</title>
<link rel="icon" href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['favicon']), ENT_QUOTES, 'UTF-8');?>
" type="image/svg+xml">
<link rel="manifest" href="https://cmdr.site/manifest.webmanifest">
<meta name="theme-color" content="#ffffff">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Mister Rogers'">
<meta property="og:site_name" content="Mister Rogers'">
<meta property="og:title" content="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('pageTitle')), ENT_QUOTES, 'UTF-8');?>
">
<meta property="og:url" content="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('ogUrl')), ENT_QUOTES, 'UTF-8');?>
">
<meta property="og:type" content="website">
<meta property="og:image" content="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['banner']), ENT_QUOTES, 'UTF-8');?>
">
<meta property="og:image:secure_url" content="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['banner']), ENT_QUOTES, 'UTF-8');?>
">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1792">
<meta property="og:image:height" content="1008">
<meta property="og:image:alt" content="Mister Rogers' Neighborhood banner.">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('pageTitle')), ENT_QUOTES, 'UTF-8');?>
">
<meta name="twitter:image" content="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['banner']), ENT_QUOTES, 'UTF-8');?>
">
<meta name="twitter:image:alt" content="Mister Rogers' Neighborhood banner.">
<meta property="fb:app_id" content="1131234549584012" />
<meta name="description" content="Search smarter with floating pills. Instantly query Google, Bing, DuckDuckGo, Brave, Wikipedia, Perplexity and custom engines. Discover related keywords, build a live keyword web, and jump between providers in one place.">
<meta property="og:description" content="Search smarter with floating pills. Instantly query Google, Bing, DuckDuckGo, Brave, Wikipedia, Perplexity and custom engines. Discover related keywords, build a live keyword web, and jump between providers in one place.">
<meta name="twitter:description" content="Search smarter with floating pills. Instantly query Google, Bing, DuckDuckGo, Brave, Wikipedia, Perplexity and custom engines. Discover related keywords, build a live keyword web, and jump between providers in one place.">
<meta name="google-adsense-account" content="ca-pub-2774592096336570">
<?php echo '<script'; ?>
 async src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['ads']), ENT_QUOTES, 'UTF-8');?>
" crossorigin="anonymous"><?php echo '</script'; ?>
>
<link rel="stylesheet" href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['css']), ENT_QUOTES, 'UTF-8');?>
">
<div id="fb-root"></div>
<?php echo '<script'; ?>
 async defer crossorigin="anonymous" src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['fbsdk']), ENT_QUOTES, 'UTF-8');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['fbinit']), ENT_QUOTES, 'UTF-8');?>
" defer><?php echo '</script'; ?>
>
<!-- HEAD (drop-in) -->
<link rel="manifest" href="/index.php?manifest=1" crossorigin="anonymous">
<?php echo '<script'; ?>
>
const LOCAL_VERSION_KEY = 'cmdr-sw-version';

if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    const reg = await navigator.serviceWorker.register('/index.php?sw=1');

    // Ask the active SW for its version
    function getSWVersion() {
      return new Promise((resolve) => {
        if (!navigator.serviceWorker.controller) return resolve(null);

        const msgChannel = new MessageChannel();
        msgChannel.port1.onmessage = (event) => resolve(event.data.version);

        navigator.serviceWorker.controller.postMessage('GET_VERSION', [msgChannel.port2]);
      });
    }

    const activeVersion = await getSWVersion();
    const storedVersion = localStorage.getItem(LOCAL_VERSION_KEY);

    // If no version stored yet, store it
    if (!storedVersion && activeVersion) {
      localStorage.setItem(LOCAL_VERSION_KEY, activeVersion);
      return;
    }

    // If version changed → reload silently
    if (activeVersion && storedVersion && activeVersion !== storedVersion) {
      console.log('New version detected:', activeVersion);
      localStorage.setItem(LOCAL_VERSION_KEY, activeVersion);

      // Silent background reload
      setTimeout(() => location.reload(), 500);
    }

    // Detect new worker installing in background
    reg.addEventListener('updatefound', () => {
      const newWorker = reg.installing;
      newWorker.addEventListener('statechange', async () => {
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          const newVersion = await getSWVersion();
          if (newVersion && newVersion !== localStorage.getItem(LOCAL_VERSION_KEY)) {
            localStorage.setItem(LOCAL_VERSION_KEY, newVersion);
            setTimeout(() => location.reload(), 500);
          }
        }
      });
    });
  });
}
<?php echo '</script'; ?>
>
</head>
<body>
<nav>
<ul>
<li><p>&para;<a href="https://www.cmdr.site/" title="Mister Rogers' - Website"><b>M</b>ister&nbsp;<b>R</b>ogers'</a>&nbsp;<img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['favicon']), ENT_QUOTES, 'UTF-8');?>
" alt="Mister Rogers' Neighborhood" /></p></li>
<li><p><a href="https://linktr.ee/cmdr.site" title="Mister Rogers' - Neighborhood" target="_blank">Neighborhood</a>:</p></li>
<li><p><a href="https://www.youtube.com/@CMDRSit" target="_blank" title="Mister Rogers' - YouTube"><img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['youtube']), ENT_QUOTES, 'UTF-8');?>
" alt="YouTube" /></a>&#44;</p></li>
<li><p><a href="https://www.linkedin.com/in/cmdr-site/" target="_blank" title="Mister Rogers' - LinkedIn"><img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['linkedin']), ENT_QUOTES, 'UTF-8');?>
" alt="LinkedIn" /></a>&#44;</p></li>
<li><p><a href="https://github.com/FecITheLion/" target="_blank" title="Mister Rogers' - GitHub"><img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['github']), ENT_QUOTES, 'UTF-8');?>
" alt="GitHub" /></a>&#44;</p></li>
<li><p><a href="https://www.facebook.com/CMDRSit/" target="_blank" title="Mister Rogers' - Facebook"><img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['facebook']), ENT_QUOTES, 'UTF-8');?>
" alt="Facebook" /></a>&#44;</p></li>
<li><p><a href="https://x.com/bidth64892" target="_blank" title="Mister Rogers' - Twitter"><img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['twitter']), ENT_QUOTES, 'UTF-8');?>
" alt="Twitter" /></a>&nbsp;&amp;</p></li>
<li><p><a href="https://www.instagram.com/cmdr.site" target="_blank" title="Mister Rogers' - Instagram"><img src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['instagram']), ENT_QUOTES, 'UTF-8');?>
" alt="Instagram" /></a>&period;&dagger;</p></li>
<li><p><button type="button" id="install-app" hidden>Install</button></p></li>
</ul>
</nav>
<?php if ($_smarty_tpl->getValue('warn')) {?>
<div id="redirect-warn" role="dialog" aria-labelledby="warn-title">
<div class="card">
<h1 id="warn-title">Leaving Mister Rogers'</h1>
<p><b><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('warn')['keyword']), ENT_QUOTES, 'UTF-8');?>
</b> resolves off this application.</p>
<p>Destination: <code><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('warn')['source']), ENT_QUOTES, 'UTF-8');?>
</code></p>
<p>Continue sends a ping so the destination can prepare, then opens it.</p>
<p>
<a class="go" href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('warn')['source']), ENT_QUOTES, 'UTF-8');?>
"
   ping="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('warn')['ping']), ENT_QUOTES, 'UTF-8');?>
"
   rel="noopener noreferrer">Continue</a>
<a href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('homeUrl')), ENT_QUOTES, 'UTF-8');?>
">Stay</a>
</p>
<?php if ($_smarty_tpl->getValue('warn')['log']) {?><p><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('warn')['log']), ENT_QUOTES, 'UTF-8');?>
</p><?php }?>
</div>
</div>
<?php }?>
<section id="keywordweb" aria-label="Keyword web">
<?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('nodes'), 'node');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('node')->value) {
$foreach0DoElse = false;
?>
<a href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['uri']), ENT_QUOTES, 'UTF-8');?>
"
   data-keyword="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['keyword']), ENT_QUOTES, 'UTF-8');?>
"
   data-log="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['log']), ENT_QUOTES, 'UTF-8');?>
"
   data-source="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['source']), ENT_QUOTES, 'UTF-8');?>
"
   data-back="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['back']), ENT_QUOTES, 'UTF-8');?>
"
   <?php if ($_smarty_tpl->getValue('node')['current']) {?>data-current="1"<?php }?>><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['keyword']), ENT_QUOTES, 'UTF-8');?>
</a>
<?php if ($_smarty_tpl->getValue('node')['external']) {?>
<a href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['source']), ENT_QUOTES, 'UTF-8');?>
" rel="external"
   ping="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['ping']), ENT_QUOTES, 'UTF-8');?>
"
   data-keyword="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['keyword']), ENT_QUOTES, 'UTF-8');?>
"
   data-log="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['log']), ENT_QUOTES, 'UTF-8');?>
"><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['keyword']), ENT_QUOTES, 'UTF-8');?>
 source</a>
<?php }
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('node')['related'], 'relUri');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('relUri')->value) {
$foreach1DoElse = false;
?>
<a href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('relUri')), ENT_QUOTES, 'UTF-8');?>
"
   data-keyword="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['keyword']), ENT_QUOTES, 'UTF-8');?>
"
   data-related="1"><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('node')['keyword']), ENT_QUOTES, 'UTF-8');?>
 related</a>
<?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
</section>
<?php if ($_smarty_tpl->getValue('hasItems')) {
echo '<script'; ?>
>window.CMDR = <?php echo $_smarty_tpl->getValue('pageVars');?>
;<?php echo '</script'; ?>
>

<div id="folderpool" aria-label="Folders">
<form id="seekbox">
<input id="prov" placeholder="Provider" list="provlist" autocomplete="off">
<datalist id="provlist"></datalist>
<input id="q" placeholder="Search term">
<button type="button" data-ai="specify" title="Specify">+</button>
<button type="button" data-ai="general" title="Generalize">−</button>
<button type="submit">Search</button>
</form>
</div>
<!-- [A|B&C] -->
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['seek']), ENT_QUOTES, 'UTF-8');?>
" defer><?php echo '</script'; ?>
>
<?php }?>
<!-- [B&C] -->
<?php echo '<script'; ?>
>window.CMDR = window.CMDR || <?php echo $_smarty_tpl->getValue('pageVars');?>
;<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['redirect']), ENT_QUOTES, 'UTF-8');?>
" defer><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['install']), ENT_QUOTES, 'UTF-8');?>
" defer><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['bodyclick']), ENT_QUOTES, 'UTF-8');?>
" defer><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('assets')['cjs']), ENT_QUOTES, 'UTF-8');?>
" defer><?php echo '</script'; ?>
>
</body>
</html><?php }
}
