<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';

// Domain modules. Each file exposes a focused static class.
require_once __DIR__ . '/Defaults.php';
require_once __DIR__ . '/FileStore.php';
require_once __DIR__ . '/VendorManager.php';
require_once __DIR__ . '/AssetCache.php';
require_once __DIR__ . '/ProviderManager.php';
require_once __DIR__ . '/HttpTools.php';
require_once __DIR__ . '/UrlTools.php';
require_once __DIR__ . '/KeywordWeb.php';
require_once __DIR__ . '/RobotsPublisher.php';
require_once __DIR__ . '/SitemapManager.php';
require_once __DIR__ . '/LocalCrawler.php';
require_once __DIR__ . '/PwaAssets.php';
require_once __DIR__ . '/legacy_api.php';
require_once __DIR__ . '/AppController.php';
