<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class FileStoreModule
{

    public static function ensure_dir(string $path): bool
    {
        if (is_dir($path)) {
            return true;
        }
        if (is_file($path)) {
            return false;
        }
        return @mkdir($path, 0755, true) || is_dir($path);
    }

    public static function load_json(string $path, array $fallback = []): array
    {
        if (!is_file($path)) {
            return $fallback;
        }
        $data = json_decode(file_get_contents($path), true);
        return is_array($data) ? $data : $fallback;
    }

    public static function save_json(string $path, array $data): bool
    {
        $fp = fopen($path, 'c+');
        if (!$fp) {
            return false;
        }
        flock($fp, LOCK_EX);
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode(array_values($data)));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        return true;
    }
}
