<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class HttpToolsModule
{

    public static function http_get(string $url): string
    {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_USERAGENT      => 'cmdr-site/1.0 (+https://www.cmdr.site//; keyword-web)',
            CURLOPT_MAXREDIRS      => 3,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body && $code >= 200 && $code < 400) ? $body : '';
    }

    public static function term_pct(string $html, string $raw): float
    {
        $text = strtolower(strip_tags($html));
        $parts = preg_split('/\s+/', strtolower(trim($raw)));
        $hit = 0;
        $n = 0;
        foreach ($parts as $p) {
            if (strlen($p) < 2) {
                continue;
            }
            $n++;
            if (strpos($text, $p) !== false) {
                $hit++;
            }
        }
        return $n ? $hit / $n : 0.0;
    }

    public static function abs_url(?string $href, string $base): ?string
    {
        $href = trim(html_entity_decode((string) $href));
        if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'javascript:') === 0) {
            return null;
        }
        if (preg_match('#^https?://#i', $href)) {
            return preg_replace('/#.*$/', '', $href);
        }
        if (strpos($href, '//') === 0) {
            $scheme = parse_url($base, PHP_URL_SCHEME) ?: 'https';
            return $scheme . ':' . preg_replace('/#.*$/', '', $href);
        }
        $parts = parse_url($base);
        if (!$parts || empty($parts['host'])) {
            return null;
        }
        $scheme = $parts['scheme'] ?? 'https';
        $path = $parts['path'] ?? '/';
        if ($href[0] !== '/') {
            $path = preg_replace('#/[^/]*$#', '/', $path) . $href;
        } else {
            $path = $href;
        }
        $segs = [];
        foreach (explode('/', $path) as $seg) {
            if ($seg === '' || $seg === '.') {
                continue;
            }
            if ($seg === '..') {
                array_pop($segs);
                continue;
            }
            $segs[] = $seg;
        }
        return $scheme . '://' . $parts['host'] . '/' . implode('/', $segs);
    }

    public static function patterns_from_dom(string $html, string $raw): string
    {
        if ($html === '') {
            return '';
        }
        $found = [];
        $doc = new DOMDocument();
        @$doc->loadHTML($html);
        $xp = new DOMXPath($doc);
    
        foreach ($xp->query('//a[@href]|//link[@href]|//*[@content]') as $node) {
            $url = $node->getAttribute('href') ?: $node->getAttribute('content');
            if (!preg_match('#^https?://#', $url)) {
                continue;
            }
            if (!preg_match('/(?:[?&](?:q|query|search|search_query|p)=)|\{(?:term|searchTerms|search_term_string)\}/i', $url)) {
                continue;
            }
            $found[] = ['url' => normalize_template($url), 'pct' => term_pct($html, $raw)];
        }
    
        if (preg_match_all('#https?://[^\s"\'<>]+\{(?:term|searchTerms|search_term_string)\}[^\s"\'<>]*#i', $html, $m)) {
            foreach ($m[0] as $url) {
                $found[] = ['url' => normalize_template(html_entity_decode($url)), 'pct' => term_pct($html, $raw)];
            }
        }
    
        usort($found, fn($a, $b) => $b['pct'] <=> $a['pct']);
        return $found[0]['url'] ?? '';
    }

    public static function pick_three(array $candidates, int $wanted): string
    {
        $best = null;
        foreach ($candidates as $url) {
            if (!$url) {
                continue;
            }
            $score = strlen($url) + abs(param_count($url) - $wanted) * 40;
            if ($best === null || $score < $best[0]) {
                $best = [$score, $url];
            }
        }
        return $best[1] ?? '';
    }
}
