<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class AssetCacheModule
{

    public static function asset_catalog(): array
    {
        return [
            'favicon'   => ['url' => 'https://www.cmdr.site/image/favicon.svg', 'path' => 'image/favicon.svg'],
            'banner'    => ['url' => 'https://www.cmdr.site/image/banner.jpg', 'path' => 'image/banner.jpg'],
            'css'       => ['url' => 'https://www.cmdr.site/style/a.css', 'path' => 'style/a.css'],
            'youtube'   => ['url' => 'https://www.cmdr.site/image/youtube.png', 'path' => 'image/youtube.png'],
            'linkedin'  => ['url' => 'https://www.cmdr.site/image/linkedin.svg', 'path' => 'image/linkedin.svg'],
            'github'    => ['url' => 'https://www.cmdr.site/image/github.svg', 'path' => 'image/github.svg'],
            'facebook'  => ['url' => 'https://www.cmdr.site/image/facebook.ico', 'path' => 'image/facebook.ico'],
            'twitter'   => ['url' => 'https://www.cmdr.site/image/twitter.ico', 'path' => 'image/twitter.ico'],
            'instagram' => ['url' => 'https://www.cmdr.site/image/instagram.png', 'path' => 'image/instagram.png'],
            'cjs'       => ['url' => 'https://www.cmdr.site/script/c.js', 'path' => 'script/c.js'],
            'ads'       => ['url' => 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2774592096336570', 'path' => 'script/adsbygoogle.js'],
            'fbsdk'     => ['url' => 'https://connect.facebook.net/en_US/sdk.js', 'path' => 'script/facebook-sdk.js'],
            'seek'      => ['url' => '', 'path' => 'script/seek.js'],
            'redirect'  => ['url' => '', 'path' => 'script/redirect.js'],
            'install'   => ['url' => '', 'path' => 'script/install.js'],
            'bodyclick' => ['url' => '', 'path' => 'script/body-click.js'],
            'fbinit'    => ['url' => '', 'path' => 'script/facebook-init.js'],
        ];
    }

    public static function asset_fetch(string $url): string
    {
        if ($url === '' || !function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_USERAGENT => 'cmdr-site/1.0 (+https://www.cmdr.site/; fragment-cache)',
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body !== false && $code >= 200 && $code < 400) ? (string) $body : '';
    }

    public static function asset_sync(bool $force = false): array
    {
        ensure_dir(DIR_CACHE);
        $metaPath = DIR_CACHE . '/assets.json';
        $meta = is_file($metaPath) ? json_decode((string) file_get_contents($metaPath), true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        $out = [];
        $origin = site_origin();
        foreach (asset_catalog() as $name => $spec) {
            $rel = $spec['path'];
            $disk = APP_ROOT . '/' . $rel;
            $web = $origin . '/' . $rel;
            $fetched = (int) ($meta[$name]['fetched'] ?? 0);
            $stale = $force || !is_file($disk) || (time() - $fetched) >= ASSET_TTL;
            if ($stale && $spec['url'] !== '') {
                $body = asset_fetch($spec['url']);
                if ($body !== '') {
                    ensure_dir(dirname($disk));
                    file_put_contents($disk, $body, LOCK_EX);
                    $meta[$name] = ['url' => $spec['url'], 'path' => $rel, 'fetched' => time(), 'bytes' => strlen($body)];
                } elseif (!isset($meta[$name])) {
                    $meta[$name] = ['url' => $spec['url'], 'path' => $rel, 'fetched' => is_file($disk) ? filemtime($disk) : 0, 'bytes' => is_file($disk) ? filesize($disk) : 0];
                }
            } elseif (!isset($meta[$name])) {
                $meta[$name] = ['url' => $spec['url'], 'path' => $rel, 'fetched' => is_file($disk) ? filemtime($disk) : time(), 'bytes' => is_file($disk) ? filesize($disk) : 0];
            }
            $out[$name] = $web;
        }
        file_put_contents($metaPath, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
        return $out;
    }

    public static function var_cache_get(bool $force = false): ?array
    {
        $path = DIR_CACHE . '/vars.json';
        if ($force || !is_file($path) || (time() - filemtime($path)) >= VAR_TTL) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);
        return is_array($data) ? $data : null;
    }

    public static function var_cache_put(array $data): void
    {
        ensure_dir(DIR_CACHE);
        $data['cached_at'] = time();
        file_put_contents(DIR_CACHE . '/vars.json', json_encode($data), LOCK_EX);
    }
}
