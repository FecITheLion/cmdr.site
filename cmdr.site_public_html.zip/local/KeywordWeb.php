<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class KeywordWebModule
{

    public static function load_web(): array
    {
        $defaults = load_defaults();
        $social = $defaults['social'];
        $home = [
            'keyword' => "Mister Rogers'",
            'uri'     => keyword_uri("Mister Rogers'"),
            'source'  => full_uri(''),
            'log'     => full_uri(''),
            'back'    => true,
            'related' => [],
        ];
        $nodes = [$home];
        foreach ($social as $seed) {
            $nodes[] = [
                'keyword' => $seed['keyword'],
                'uri'     => keyword_uri($seed['keyword']),
                'source'  => $seed['uri'],
                'log'     => $seed['uri'],
                'back'    => false,
                'related' => [keyword_uri("Mister Rogers'")],
            ];
        }
        $queue = [];
        foreach ($social as $seed) {
            $queue[] = [
                'uri'     => $seed['uri'],
                'depth'   => 0,
                'trail'   => [$seed['uri']],
                'keyword' => $seed['keyword'],
            ];
        }
        $state = [
            'nodes' => $nodes,
            'queue' => $queue,
            'seen'  => [full_uri('') => true],
            'next'  => 0,
        ];
        if (is_file(STORE_WEB)) {
            $data = json_decode(file_get_contents(STORE_WEB), true);
            if (is_array($data) && !empty($data['nodes'])) {
                $state = array_merge($state, $data);
            }
        }
        return $state;
    }

    public static function save_web(array $state): bool
    {
        return save_json(STORE_WEB, $state);
    }

    public static function lookup_k(array $web, string $keyword): ?array
    {
        $keyword = trim($keyword);
        if ($keyword === '') {
            return null;
        }
        $best = null;
        foreach ($web['nodes'] as $node) {
            if (strcasecmp($node['keyword'], $keyword) !== 0) {
                continue;
            }
            if (empty($node['source']) || is_home($node['source'])) {
                continue;
            }
            $best = $node;
            if (!empty($node['back'])) {
                break;
            }
        }
        if ($best) {
            return $best;
        }
        foreach (load_defaults()['social'] as $seed) {
            if (strcasecmp($seed['keyword'], $keyword) === 0) {
                return [
                    'keyword' => $seed['keyword'],
                    'uri'     => keyword_uri($seed['keyword']),
                    'source'  => $seed['uri'],
                    'log'     => $seed['uri'],
                    'back'    => false,
                    'related' => [keyword_uri("Mister Rogers'")],
                ];
            }
        }
        return null;
    }

    public static function extract_hops(string $html, string $base): array
    {
        $hops = [];
        if ($html === '') {
            return $hops;
        }
        if (preg_match_all('/<a\b[^>]*\bhref\s*=\s*([\'"])(.*?)\1[^>]*>(.*?)<\/a>/is', $html, $m, PREG_SET_ORDER)) {
            foreach ($m as $row) {
                $uri = abs_url($row[2], $base);
                if (!$uri) {
                    continue;
                }
                $keyword = trim(preg_replace('/\s+/', ' ', strip_tags($row[3])));
                if ($keyword === '' || strlen($keyword) > 60) {
                    $keyword = ucwords(str_replace(['-', '_'], ' ', basename(parse_url($uri, PHP_URL_PATH) ?: 'link')));
                }
                $hops[] = ['uri' => $uri, 'keyword' => $keyword];
            }
        }
        if (preg_match('/<link[^>]+rel=["\']canonical["\'][^>]*href=["\']([^"\']+)["\']/i', $html, $m)
            || preg_match('/<meta[^>]+property=["\']og:url["\'][^>]*content=["\']([^"\']+)["\']/i', $html, $m)
        ) {
            $uri = abs_url($m[1], $base);
            if ($uri) {
                $hops[] = ['uri' => $uri, 'keyword' => 'canonical'];
            }
        }
        return $hops;
    }

    public static function upsert_node(array &$state, array $node): array
    {
        foreach ($state['nodes'] as &$row) {
            if (strcasecmp($row['keyword'], $node['keyword']) === 0 && $row['uri'] === $node['uri']) {
                if (!empty($node['back'])) {
                    $row['back'] = true;
                }
                if (!empty($node['log'])) {
                    $row['log'] = $node['log'];
                }
                if (!empty($node['source'])) {
                    $row['source'] = $node['source'];
                }
                $row['related'] = array_values(array_unique(array_merge($row['related'] ?? [], $node['related'] ?? [])));
                return $row;
            }
        }
        unset($row);
        $state['nodes'][] = $node;
        return $node;
    }

    public static function crawl_step(): array
    {
        $state = load_web();
        $wait = 3000;
        if (time() < ($state['next'] ?? 0)) {
            return [
                'ok'      => true,
                'pending' => !empty($state['queue']),
                'wait'    => max(500, ($state['next'] - time()) * 1000),
                'nodes'   => [],
            ];
        }
        $fresh = [];
        if (empty($state['queue'])) {
            $state['next'] = time() + 30;
            save_web($state);
            return ['ok' => true, 'pending' => false, 'wait' => 30000, 'nodes' => []];
        }
        $job = array_shift($state['queue']);
        $uri = $job['uri'];
        $state['seen'][$uri] = true;
        $state['next'] = time() + 3;
    
        if (robots_allows($uri)) {
            $html = http_get($uri);
            $trail = $job['trail'] ?? [$uri];
            $homeHit = is_home($uri);
            foreach (extract_hops($html, $uri) as $hop) {
                if (is_home($hop['uri'])) {
                    $homeHit = true;
                }
                if (count($trail) < 6 && empty($state['seen'][$hop['uri']]) && count($state['queue']) < 40) {
                    $prefer = is_home($hop['uri']) || stripos($hop['uri'], 'cmdr.site') !== false;
                    $next = [
                        'uri'     => $hop['uri'],
                        'depth'   => $job['depth'] + 1,
                        'trail'   => array_merge($trail, [$hop['uri']]),
                        'keyword' => $hop['keyword'],
                    ];
                    if ($job['depth'] < 3) {
                        if ($prefer) {
                            array_unshift($state['queue'], $next);
                        } else {
                            $state['queue'][] = $next;
                        }
                    }
                }
                if ($homeHit || is_home($hop['uri'])) {
                    $log = implode(' -> ', array_merge($trail, [$hop['uri'], full_uri('')]));
                    $node = [
                        'keyword' => $hop['keyword'] !== '' ? $hop['keyword'] : $job['keyword'],
                        'uri'     => keyword_uri($hop['keyword'] !== '' ? $hop['keyword'] : $job['keyword']),
                        'source'  => $hop['uri'],
                        'log'     => $log,
                        'back'    => true,
                        'related' => [keyword_uri("Mister Rogers'"), keyword_uri($job['keyword'])],
                    ];
                    $fresh[] = upsert_node($state, $node);
                }
            }
            if ($homeHit) {
                $log = implode(' -> ', array_merge($trail, [full_uri('')]));
                $fresh[] = upsert_node($state, [
                    'keyword' => $job['keyword'],
                    'uri'     => keyword_uri($job['keyword']),
                    'source'  => $uri,
                    'log'     => $log,
                    'back'    => true,
                    'related' => [keyword_uri("Mister Rogers'")],
                ]);
            }
        }
        if (count($state['nodes']) > 80) {
            $state['nodes'] = array_slice($state['nodes'], 0, 80);
        }
        save_web($state);
        return [
            'ok'      => true,
            'pending' => !empty($state['queue']),
            'wait'    => $wait,
            'nodes'   => $fresh,
        ];
    }
}
