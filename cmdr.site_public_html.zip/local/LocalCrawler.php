<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class LocalCrawlerModule
{

    public static function resolve_href(string $href, string $fromRel): ?string
    {
        $href = trim(html_entity_decode($href));
        if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'javascript:') === 0) {
            return null;
        }
        $mine = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : 'cmdr.site';
        if (preg_match('#^https?://#i', $href)) {
            $parts = parse_url($href);
            $host = $parts['host'] ?? '';
            if (strcasecmp($host, $mine) !== 0 && strcasecmp($host, 'cmdr.site') !== 0) {
                return null;
            }
            $path = $parts['path'] ?? '/';
        } elseif (strpos($href, '//') === 0) {
            return null;
        } else {
            $base = $fromRel === '' ? '/' : '/' . trim($fromRel, '/') . '/';
            $path = ($href[0] === '/') ? $href : $base . $href;
        }
        $segs = [];
        foreach (explode('/', $path) as $seg) {
            if ($seg === '' || $seg === '.') {
                continue;
            }
            if ($seg === '..') {
                array_pop($segs);
                continue;
            }
            $segs[] = $seg;
        }
        return full_uri(implode('/', $segs));
    }

    public static function page_links(string $absDir, string $rel): array
    {
        $links = [];
        foreach (['index.html', 'index.htm'] as $name) {
            $file = rtrim($absDir, '/') . '/' . $name;
            if (!is_file($file)) {
                continue;
            }
            $html = file_get_contents($file);
            if (!$html || !preg_match_all('/<a\b[^>]*\bhref\s*=\s*([\'"])(.*?)\1/i', $html, $m)) {
                continue;
            }
            foreach ($m[2] as $href) {
                $uri = resolve_href($href, $rel);
                if ($uri) {
                    $links[] = $uri;
                }
            }
        }
        return array_values(array_unique($links));
    }

    public static function note_circular(array &$logs, array $steps): string
    {
        $trail = [];
        foreach ($steps as $step) {
            $trail[] = full_uri($step);
        }
        $line = implode(' -> ', $trail);
        foreach ($steps as $step) {
            if (!isset($logs[$step])) {
                $logs[$step] = [];
            }
            if (!in_array($line, $logs[$step], true)) {
                $logs[$step][] = $line;
            }
        }
        return $line;
    }

    public static function crawl_circular(string $base, array $folders, array &$logs): void
    {
        $byUri = [full_uri('') => ''];
        foreach ($folders as $rel) {
            $byUri[full_uri($rel)] = $rel;
        }
        $stack = [];
        $walk = function (string $rel) use (&$walk, &$stack, &$logs, $base, $byUri): void {
            $uri = full_uri($rel);
            $loopAt = array_search($uri, $stack, true);
            if ($loopAt !== false) {
                $steps = [];
                foreach (array_slice($stack, $loopAt) as $step) {
                    $steps[] = $byUri[$step] ?? trim((string) parse_url($step, PHP_URL_PATH), '/');
                }
                $steps[] = $rel;
                note_circular($logs, $steps);
                return;
            }
            if (count($stack) > 12) {
                return;
            }
            $stack[] = $uri;
            $dir = $base . ($rel === '' ? '' : '/' . $rel);
            if (is_dir($dir)) {
                foreach (page_links($dir, $rel) as $next) {
                    if (isset($byUri[$next])) {
                        $walk($byUri[$next]);
                    }
                }
            }
            array_pop($stack);
        };
        $walk('');
        foreach ($folders as $rel) {
            $walk($rel);
        }
    }

    public static function save_circular_log(array $logs): void
    {
        $all = [];
        if (is_file(LOG_CIRCULAR)) {
            foreach (file(LOG_CIRCULAR, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $row) {
                $bit = strpos($row, "\t") !== false ? substr($row, strpos($row, "\t") + 1) : $row;
                $all[$bit] = true;
            }
        }
        foreach ($logs as $lines) {
            foreach ($lines as $line) {
                $all[$line] = true;
            }
        }
        $out = '';
        foreach (array_keys($all) as $line) {
            $out .= date('c') . "\t" . $line . "\n";
        }
        if ($out !== '') {
            file_put_contents(LOG_CIRCULAR, $out, LOCK_EX);
        }
    }
}
