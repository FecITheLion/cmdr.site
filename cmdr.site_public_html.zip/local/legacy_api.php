<?php

declare(strict_types=1);

/**
 * Compatibility façade. Existing internal calls remain stable while implementation
 * lives in domain classes under local/.
 */

function default_providers(): array
{
    return DefaultsModule::default_providers();
}

function default_social_seeds(): array
{
    return DefaultsModule::default_social_seeds();
}

function load_defaults(): array
{
    return DefaultsModule::load_defaults();
}

function save_defaults(array $data): bool
{
    return DefaultsModule::save_defaults($data);
}

function default_phrase_list(): array
{
    return DefaultsModule::default_phrase_list();
}

function load_phrase_history(): array
{
    return DefaultsModule::load_phrase_history();
}

function save_phrase_history(array $list): bool
{
    return DefaultsModule::save_phrase_history($list);
}

function ensure_dir(string $path): bool
{
    return FileStoreModule::ensure_dir($path);
}

function load_json(string $path, array $fallback = []): array
{
    return FileStoreModule::load_json($path, $fallback);
}

function save_json(string $path, array $data): bool
{
    return FileStoreModule::save_json($path, $data);
}

function default_vendor_packages(): array
{
    return VendorManagerModule::default_vendor_packages();
}

function vendor_packages(): array
{
    return VendorManagerModule::vendor_packages();
}

function vendor_dir(string $name): string
{
    return VendorManagerModule::vendor_dir($name);
}

function vendor_meta(string $name): array
{
    return VendorManagerModule::vendor_meta($name);
}

function vendor_http(string $url, int $timeout = 20): string
{
    return VendorManagerModule::vendor_http($url, $timeout);
}

function vendor_latest(string $repo): array
{
    return VendorManagerModule::vendor_latest($repo);
}

function vendor_extract(string $zip, string $dest): bool
{
    return VendorManagerModule::vendor_extract($zip, $dest);
}

function vendor_install(array $pkg, bool $force = false): bool
{
    return VendorManagerModule::vendor_install($pkg, $force);
}

function vendor_rrmdir(string $dir): void
{
    VendorManagerModule::vendor_rrmdir($dir);
}

function vendor_rcopy(string $src, string $dest): void
{
    VendorManagerModule::vendor_rcopy($src, $dest);
}

function vendor_ensure_all(bool $force = false): void
{
    VendorManagerModule::vendor_ensure_all($force);
}

function vendor_register_autoload(): void
{
    VendorManagerModule::vendor_register_autoload();
}

function vendor_load(string $name): string
{
    return VendorManagerModule::vendor_load($name);
}

function vendor_boot(bool $force = false): void
{
    VendorManagerModule::vendor_boot($force);
}

function asset_catalog(): array
{
    return AssetCacheModule::asset_catalog();
}

function asset_fetch(string $url): string
{
    return AssetCacheModule::asset_fetch($url);
}

function asset_sync(bool $force = false): array
{
    return AssetCacheModule::asset_sync($force);
}

function var_cache_get(bool $force = false): ?array
{
    return AssetCacheModule::var_cache_get($force);
}

function var_cache_put(array $data): void
{
    AssetCacheModule::var_cache_put($data);
}

function load_providers(): array
{
    return ProviderManagerModule::load_providers();
}

function save_providers(array $list): bool
{
    return ProviderManagerModule::save_providers($list);
}

function valid_template(string $url): bool
{
    return ProviderManagerModule::valid_template($url);
}

function normalize_template(string $url): string
{
    return ProviderManagerModule::normalize_template($url);
}

function param_count(string $url): int
{
    return ProviderManagerModule::param_count($url);
}

function load_ban(): array
{
    return ProviderManagerModule::load_ban();
}

function save_ban(array $ban): void
{
    ProviderManagerModule::save_ban($ban);
}

function is_banned(string $raw, array $ban): bool
{
    return ProviderManagerModule::is_banned($raw, $ban);
}

function note_fail(string $raw): void
{
    ProviderManagerModule::note_fail($raw);
}

function claim_aliases(string $name): void
{
    ProviderManagerModule::claim_aliases($name);
}

function autocorrect(string $raw): ?string
{
    return ProviderManagerModule::autocorrect($raw);
}

function http_get(string $url): string
{
    return HttpToolsModule::http_get($url);
}

function term_pct(string $html, string $raw): float
{
    return HttpToolsModule::term_pct($html, $raw);
}

function abs_url(?string $href, string $base): ?string
{
    return HttpToolsModule::abs_url($href, $base);
}

function patterns_from_dom(string $html, string $raw): string
{
    return HttpToolsModule::patterns_from_dom($html, $raw);
}

function pick_three(array $candidates, int $wanted): string
{
    return HttpToolsModule::pick_three($candidates, $wanted);
}

function site_origin(): string
{
    return UrlToolsModule::site_origin();
}

function full_uri(string $rel): string
{
    return UrlToolsModule::full_uri($rel);
}

function keyword_uri(string $keyword): string
{
    return UrlToolsModule::keyword_uri($keyword);
}

function is_home(string $url): bool
{
    return UrlToolsModule::is_home($url);
}

function host_robots(string $host): string
{
    return UrlToolsModule::host_robots($host);
}

function robots_allows(string $url): bool
{
    return UrlToolsModule::robots_allows($url);
}

function load_web(): array
{
    return KeywordWebModule::load_web();
}

function save_web(array $state): bool
{
    return KeywordWebModule::save_web($state);
}

function lookup_k(array $web, string $keyword): ?array
{
    return KeywordWebModule::lookup_k($web, $keyword);
}

function extract_hops(string $html, string $base): array
{
    return KeywordWebModule::extract_hops($html, $base);
}

function upsert_node(array &$state, array $node): array
{
    return KeywordWebModule::upsert_node($state, $node);
}

function crawl_step(): array
{
    return KeywordWebModule::crawl_step();
}

function build_robots(array $state): string
{
    return RobotsPublisherModule::build_robots($state);
}

function publish_robots(array $state): string
{
    return RobotsPublisherModule::publish_robots($state);
}

function w3c_datetime(int $ts): string
{
    return SitemapManagerModule::w3c_datetime($ts);
}

function collect_sitemap_urls(): array
{
    return SitemapManagerModule::collect_sitemap_urls();
}

function build_sitemap(array $urls): string
{
    return SitemapManagerModule::build_sitemap($urls);
}

function build_sitemap_index(array $sitemaps): string
{
    return SitemapManagerModule::build_sitemap_index($sitemaps);
}

function serve_sitemap(): void
{
    SitemapManagerModule::serve_sitemap();
}

function publish_sitemaps(): void
{
    SitemapManagerModule::publish_sitemaps();
}

function resolve_href(string $href, string $fromRel): ?string
{
    return LocalCrawlerModule::resolve_href($href, $fromRel);
}

function page_links(string $absDir, string $rel): array
{
    return LocalCrawlerModule::page_links($absDir, $rel);
}

function note_circular(array &$logs, array $steps): string
{
    return LocalCrawlerModule::note_circular($logs, $steps);
}

function crawl_circular(string $base, array $folders, array &$logs): void
{
    LocalCrawlerModule::crawl_circular($base, $folders, $logs);
}

function save_circular_log(array $logs): void
{
    LocalCrawlerModule::save_circular_log($logs);
}

function app_manifest(): string
{
    return PwaAssetsModule::app_manifest();
}

function app_worker(): string
{
    return PwaAssetsModule::app_worker();
}
