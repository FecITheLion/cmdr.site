<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class SitemapManagerModule
{

    public static function w3c_datetime(int $ts): string
    {
        return gmdate('Y-m-d\TH:i:s\Z', $ts);
    }

    public static function collect_sitemap_urls(): array
    {
        $urls = [];
        $home = full_uri('');
        $urls[$home] = [
            'loc'        => $home,
            'lastmod'    => w3c_datetime(time()),
            'changefreq' => 'daily',
            'priority'   => '1.0',
        ];
    
        // Keyword web nodes
        $web = load_web();
        foreach ($web['nodes'] as $node) {
            $uri = $node['uri'] ?? '';
            if ($uri === '' || isset($urls[$uri])) {
                continue;
            }
            $urls[$uri] = [
                'loc'        => $uri,
                'lastmod'    => w3c_datetime(time()),
                'changefreq' => 'weekly',
                'priority'   => '0.6',
            ];
        }
    
        // Local folders that contain content
        $base = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : APP_ROOT;
        $skip = '/^(?:cgi-bin|node_modules|vendor|assets|static|css|js|img|images|fonts|templates|cache)$/i';
        $circular = [];
        $realStack = [];
        $relStack = [];
    
        $scan = function (string $rel) use (&$scan, &$circular, &$realStack, &$relStack, $base, $skip): array {
            $full = $base . ($rel === '' ? '' : '/' . $rel);
            $real = realpath($full);
            if ($real && in_array($real, $realStack, true)) {
                note_circular($circular, array_merge($relStack, [$rel]));
                return [];
            }
            if ($real) {
                $realStack[] = $real;
            }
            $relStack[] = $rel;
            $found = [];
            $files = false;
            $subs = [];
            $names = @scandir($full);
            if (!$names) {
                array_pop($relStack);
                if ($real) {
                    array_pop($realStack);
                }
                return $found;
            }
            foreach ($names as $name) {
                if ($name === '.' || $name === '..' || $name[0] === '.') {
                    continue;
                }
                $path = $full . '/' . $name;
                if (is_dir($path)) {
                    if (!preg_match($skip, $name)) {
                        $subs[] = ($rel === '' ? $name : $rel . '/' . $name);
                    }
                } elseif (is_file($path)) {
                    $files = true;
                }
            }
            $children = [];
            foreach ($subs as $sub) {
                $children = array_merge($children, $scan($sub));
            }
            if ($rel !== '' && ($files || $children)) {
                $found[] = $rel;
            }
            array_pop($relStack);
            if ($real) {
                array_pop($realStack);
            }
            return array_merge($found, $children);
        };
    
        $folders = array_values(array_unique($scan('')));
        foreach ($folders as $rel) {
            $uri = full_uri($rel);
            if (isset($urls[$uri])) {
                continue;
            }
            $last = time();
            foreach (['index.html', 'index.htm'] as $name) {
                $file = $base . '/' . $rel . '/' . $name;
                if (is_file($file)) {
                    $last = filemtime($file);
                    break;
                }
            }
            $urls[$uri] = [
                'loc'        => $uri,
                'lastmod'    => w3c_datetime($last),
                'changefreq' => 'weekly',
                'priority'   => '0.8',
            ];
        }
    
        return array_values($urls);
    }

    public static function build_sitemap(array $urls): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as $u) {
            $xml .= "  <url>\n";
            $xml .= '    <loc>' . htmlspecialchars($u['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</loc>\n";
            if (!empty($u['lastmod'])) {
                $xml .= '    <lastmod>' . htmlspecialchars($u['lastmod'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</lastmod>\n";
            }
            if (!empty($u['changefreq'])) {
                $xml .= '    <changefreq>' . htmlspecialchars($u['changefreq'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</changefreq>\n";
            }
            if (!empty($u['priority'])) {
                $xml .= '    <priority>' . htmlspecialchars($u['priority'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</priority>\n";
            }
            $xml .= "  </url>\n";
        }
        $xml .= "</urlset>\n";
        return $xml;
    }

    public static function build_sitemap_index(array $sitemaps): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($sitemaps as $s) {
            $xml .= "  <sitemap>\n";
            $xml .= '    <loc>' . htmlspecialchars($s['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</loc>\n";
            if (!empty($s['lastmod'])) {
                $xml .= '    <lastmod>' . htmlspecialchars($s['lastmod'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</lastmod>\n";
            }
            $xml .= "  </sitemap>\n";
        }
        $xml .= "</sitemapindex>\n";
        return $xml;
    }

    public static function serve_sitemap(): void
    {
        $urls = collect_sitemap_urls();
        // Split into chunks of 50,000 if needed (protocol limit)
        $chunks = array_chunk($urls, 50000);
        $sitemaps = [];
        $base = site_origin();
        foreach ($chunks as $i => $chunk) {
            $name = $i === 0 ? 'sitemap.xml' : 'sitemap-' . ($i + 1) . '.xml';
            $sitemaps[] = [
                'loc'     => $base . '/' . $name,
                'lastmod' => w3c_datetime(time()),
            ];
        }
    
        $req = $_SERVER['REQUEST_URI'] ?? '';
        header('Content-Type: application/xml; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
    
        if (preg_match('#/sitemap-index\.xml$#', $req) || isset($_GET['sitemap-index'])) {
            echo build_sitemap_index($sitemaps);
            return;
        }
    
        $index = 0;
        if (preg_match('#/sitemap-(\d+)\.xml$#', $req, $m)) {
            $index = (int) $m[1] - 1;
        }
        if (!isset($chunks[$index])) {
            http_response_code(404);
            echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>';
            return;
        }
        echo build_sitemap($chunks[$index]);
    }

    public static function publish_sitemaps(): void
    {
        $urls = collect_sitemap_urls();
        $chunks = array_chunk($urls, 50000);
        $sitemaps = [];
        $origin = site_origin();
        $dirs = [APP_ROOT];
        if (!empty($_SERVER['DOCUMENT_ROOT'])) {
            $dirs[] = rtrim($_SERVER['DOCUMENT_ROOT'], '/');
        }
        $dirs = array_unique($dirs);
    
        foreach ($chunks as $i => $chunk) {
            $name = $i === 0 ? 'sitemap.xml' : 'sitemap-' . ($i + 1) . '.xml';
            $body = build_sitemap($chunk);
            $sitemaps[] = [
                'loc'     => $origin . '/' . $name,
                'lastmod' => w3c_datetime(time()),
            ];
            foreach ($dirs as $dir) {
                $path = $dir . '/' . $name;
                if (is_file($path) && time() - filemtime($path) < 3600 && md5_file($path) === md5($body)) {
                    continue;
                }
                file_put_contents($path, $body, LOCK_EX);
            }
        }
    
        $indexBody = build_sitemap_index($sitemaps);
        foreach ($dirs as $dir) {
            $path = $dir . '/sitemap-index.xml';
            if (is_file($path) && time() - filemtime($path) < 3600 && md5_file($path) === md5($indexBody)) {
                continue;
            }
            file_put_contents($path, $indexBody, LOCK_EX);
        }
    }
}
