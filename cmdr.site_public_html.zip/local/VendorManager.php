<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class VendorManagerModule
{

    public static function default_vendor_packages(): array
    {
        return [
            [
                'name' => 'polyfill-mbstring',
                'repo' => 'symfony/polyfill-mbstring',
                'namespace' => 'Symfony\\Polyfill\\Mbstring\\',
                'path' => 'src',
                'files' => ['bootstrap.php'],
            ],
            [
                'name' => 'smarty',
                'repo' => 'smarty-php/smarty',
                'namespace' => 'Smarty\\',
                'path' => 'src',
                'files' => ['src/functions.php'],
            ],
        ];
    }

    public static function vendor_packages(): array
    {
        if (!is_file(STORE_VENDOR)) {
            file_put_contents(STORE_VENDOR, json_encode(default_vendor_packages(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
        $data = json_decode((string) file_get_contents(STORE_VENDOR), true);
        return is_array($data) && $data ? $data : default_vendor_packages();
    }

    public static function vendor_dir(string $name): string
    {
        $safe = strtolower(preg_replace('/[^a-z0-9._-]+/i', '-', $name));
        return DIR_VENDOR . '/' . $safe;
    }

    public static function vendor_meta(string $name): array
    {
        $file = vendor_dir($name) . '/.vendor-meta.json';
        if (!is_file($file)) {
            return [];
        }
        $data = json_decode((string) file_get_contents($file), true);
        return is_array($data) ? $data : [];
    }

    public static function vendor_http(string $url, int $timeout = 20): string
    {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'cmdr-site/1.0 (+https://www.cmdr.site/; vendor-cache)',
            CURLOPT_HTTPHEADER => ['Accept: application/vnd.github+json'],
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body && $code >= 200 && $code < 400) ? $body : '';
    }

    public static function vendor_latest(string $repo): array
    {
        $body = vendor_http('https://api.github.com/repos/' . $repo . '/releases/latest');
        $data = json_decode($body, true);
        if (is_array($data) && !empty($data['tag_name'])) {
            return [
                'tag' => (string) $data['tag_name'],
                'zip' => (string) ($data['zipball_url'] ?? ('https://github.com/' . $repo . '/archive/refs/tags/' . $data['tag_name'] . '.zip')),
            ];
        }
        return [
            'tag' => 'master',
            'zip' => 'https://github.com/' . $repo . '/archive/refs/heads/master.zip',
        ];
    }

    public static function vendor_extract(string $zip, string $dest): bool
    {
        ensure_dir($dest);
        if (class_exists('ZipArchive')) {
            $za = new ZipArchive();
            if ($za->open($zip) === true) {
                $ok = $za->extractTo($dest);
                $za->close();
                return $ok;
            }
        }
        $unzip = trim((string) shell_exec('command -v unzip 2>/dev/null'));
        if ($unzip === '') {
            return false;
        }
        $cmd = escapeshellarg($unzip) . ' -qo ' . escapeshellarg($zip) . ' -d ' . escapeshellarg($dest);
        exec($cmd, $out, $code);
        return $code === 0;
    }

    public static function vendor_install(array $pkg, bool $force = false): bool
    {
        $name = (string) ($pkg['name'] ?? '');
        if ($name === '') {
            return false;
        }
        $dir = vendor_dir($name);
        $meta = vendor_meta($name);
        $fresh = is_dir($dir) && !empty($meta['tag']) && (time() - (int) ($meta['fetched'] ?? 0) < 604800);
        if ($fresh && !$force) {
            return true;
        }
        $latest = vendor_latest((string) $pkg['repo']);
        if (!$force && $fresh === false && is_dir($dir) && ($meta['tag'] ?? '') === $latest['tag'] && $latest['tag'] !== '') {
            $meta['fetched'] = time();
            file_put_contents($dir . '/.vendor-meta.json', json_encode($meta));
            return true;
        }
        $tmp = sys_get_temp_dir() . '/vendor-' . $name . '-' . getmypid();
        $zip = $tmp . '.zip';
        $extract = $tmp . '-src';
        $body = vendor_http($latest['zip'], 40);
        if ($body === '') {
            return is_dir($dir);
        }
        file_put_contents($zip, $body);
        if (!vendor_extract($zip, $extract)) {
            @unlink($zip);
            return is_dir($dir);
        }
        $roots = array_values(array_filter(scandir($extract) ?: [], fn($n) => $n !== '.' && $n !== '..'));
        $root = count($roots) === 1 && is_dir($extract . '/' . $roots[0]) ? $extract . '/' . $roots[0] : $extract;
        if (is_dir($dir)) {
            vendor_rrmdir($dir);
        }
        ensure_dir(dirname($dir));
        if (!@rename($root, $dir)) {
            vendor_rcopy($root, $dir);
            vendor_rrmdir($extract);
        }
        @unlink($zip);
        if (is_dir($extract) && $extract !== $dir) {
            vendor_rrmdir($extract);
        }
        file_put_contents($dir . '/.vendor-meta.json', json_encode([
            'name' => $name,
            'repo' => $pkg['repo'],
            'tag' => $latest['tag'],
            'fetched' => time(),
        ]));
        return is_dir($dir);
    }

    public static function vendor_rrmdir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $items = scandir($dir) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . '/' . $item;
            if (is_dir($path)) {
                vendor_rrmdir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    public static function vendor_rcopy(string $src, string $dest): void
    {
        ensure_dir($dest);
        foreach (scandir($src) ?: [] as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $from = $src . '/' . $item;
            $to = $dest . '/' . $item;
            if (is_dir($from)) {
                vendor_rcopy($from, $to);
            } else {
                @copy($from, $to);
            }
        }
    }

    public static function vendor_ensure_all(bool $force = false): void
    {
        ensure_dir(DIR_VENDOR);
        foreach (vendor_packages() as $pkg) {
            vendor_install($pkg, $force);
        }
    }

    public static function vendor_register_autoload(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        $map = [];
        foreach (vendor_packages() as $pkg) {
            $prefix = (string) ($pkg['namespace'] ?? '');
            $path = trim((string) ($pkg['path'] ?? ''), '/');
            if ($prefix === '') {
                continue;
            }
            $map[$prefix] = vendor_dir((string) $pkg['name']) . ($path !== '' ? '/' . $path : '');
        }
        spl_autoload_register(static function (string $class) use ($map): void {
            foreach ($map as $prefix => $dir) {
                if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
                    continue;
                }
                $rel = str_replace('\\', '/', substr($class, strlen($prefix)));
                $file = rtrim($dir, '/') . '/' . $rel . '.php';
                if (is_file($file)) {
                    require $file;
                    return;
                }
            }
        });
    }

    public static function vendor_load(string $name): string
    {
        $wanted = null;
        foreach (vendor_packages() as $pkg) {
            if (strcasecmp((string) $pkg['name'], $name) === 0) {
                $wanted = $pkg;
                break;
            }
        }
        if (!$wanted) {
            return '';
        }
        vendor_install($wanted);
        foreach ($wanted['files'] ?? [] as $file) {
            $path = vendor_dir($name) . '/' . ltrim((string) $file, '/');
            if (is_file($path)) {
                require_once $path;
            }
        }
        vendor_register_autoload();
        return vendor_dir($name);
    }

    public static function vendor_boot(bool $force = false): void
    {
        vendor_ensure_all($force);
        foreach (vendor_packages() as $pkg) {
            vendor_load((string) $pkg['name']);
        }
    }
}
