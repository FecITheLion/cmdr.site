<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class DefaultsModule
{

    public static function default_providers(): array
    {
        return [
            ['id' => 'google',     'name' => 'Google',     'template' => 'https://www.google.com/search?q={term}', 'hits' => 0, 'updated' => 0],
            ['id' => 'bing',       'name' => 'Bing',       'template' => 'https://www.bing.com/search?q={term}', 'hits' => 0, 'updated' => 0],
            ['id' => 'ddg',        'name' => 'DuckDuckGo', 'template' => 'https://duckduckgo.com/?q={term}', 'hits' => 0, 'updated' => 0],
            ['id' => 'brave',      'name' => 'Brave',      'template' => 'https://search.brave.com/search?q={term}', 'hits' => 0, 'updated' => 0],
            ['id' => 'wiki',       'name' => 'Wikipedia',  'template' => 'https://en.wikipedia.org/w/index.php?search={term}', 'hits' => 0, 'updated' => 0],
            ['id' => 'perplexity', 'name' => 'Perplexity', 'template' => 'https://www.perplexity.ai/search?q={term}', 'hits' => 0, 'updated' => 0],
            ['id' => 'cmdr',        'name' => 'CMDR.Site',    'template' => 'https://www.cmdr.site/?k={term}', 'hits' => 0, 'updated' => 0],
        ];
    }

    public static function default_social_seeds(): array
    {
        return [
            ['keyword' => 'YouTube',   'uri' => 'https://www.youtube.com/@CMDRSit'],
            ['keyword' => 'LinkedIn',  'uri' => 'https://www.linkedin.com/in/cmdr-site/'],
            ['keyword' => 'GitHub',    'uri' => 'https://github.com/FecITheLion/'],
            ['keyword' => 'Facebook',  'uri' => 'https://www.facebook.com/CMDRSit/'],
            ['keyword' => 'Twitter',   'uri' => 'https://x.com/bidth64892'],
            ['keyword' => 'Instagram', 'uri' => 'https://www.instagram.com/cmdr.site'],
        ];
    }

    public static function load_defaults(): array
    {
        $fallback = [
            'providers' => default_providers(),
            'social'    => default_social_seeds(),
        ];
        if (!is_file(STORE_DEFAULTS)) {
            save_json(STORE_DEFAULTS, $fallback);
            return $fallback;
        }
        $data = load_json(STORE_DEFAULTS, $fallback);
        if (!isset($data['providers']) || !is_array($data['providers'])) {
            $data['providers'] = $fallback['providers'];
        }
        if (!isset($data['social']) || !is_array($data['social'])) {
            $data['social'] = $fallback['social'];
        }
        return $data;
    }

    public static function save_defaults(array $data): bool
    {
        return save_json(STORE_DEFAULTS, $data);
    }

    public static function default_phrase_list(): array
    {
        // Seed: most-adjacent phrases for brands and search terms the dictionary will miss.
        // "linkedin" is listed first so + falls back here when dictionaryapi has no entry.
        $explicit = [
            'linkedin profile', 'linkedin search', 'linkedin network', 'linkedin connections',
            'linkedin headline', 'linkedin recruiter', 'linkedin jobs', 'linkedin company page',
            'linkedin inmail', 'linkedin sales navigator', 'linkedin boolean search',
            'linkedin open to work', 'linkedin recommendations', 'linkedin endorsements',
            'linkedin about section', 'linkedin experience', 'linkedin skills',
            'linkedin professional network', 'linkedin career opportunities', 'linkedin job search',
            'professional network', 'professional profile', 'career opportunities', 'job search',
            'hiring manager', 'talent acquisition', 'recruiter outreach', 'connection request',
            'mutual connection', 'second degree connection', 'industry peers', 'personal branding',
            'thought leadership', 'profile optimization', 'headline keywords', 'open to hire',
            'sales navigator', 'boolean search', 'people search', 'company page',
            'skill endorsement', 'experience summary', 'featured content', 'warm introduction',
            'resume keywords', 'ats friendly', 'interview preparation', 'offer negotiation',
            'salary range', 'career growth', 'remote work', 'hybrid work',
        ];
        $heads = [
            'linkedin', 'professional', 'career', 'job', 'hiring', 'talent', 'network', 'profile',
            'recruiter', 'search', 'industry', 'skill', 'resume', 'interview', 'salary', 'remote',
            'leadership', 'marketing', 'sales', 'product', 'startup', 'saas', 'b2b', 'content', 'brand',
        ];
        $tails = [
            'profile', 'search', 'network', 'opportunities', 'insights', 'keywords', 'headline',
            'summary', 'experience', 'skills', 'endorsements', 'recommendations', 'connections',
            'outreach', 'pipeline', 'strategy', 'growth', 'visibility', 'optimization', 'results',
        ];
        $out = [];
        foreach ($explicit as $phrase) {
            $out[$phrase] = true;
        }
        foreach ($heads as $head) {
            foreach ($tails as $tail) {
                $out[$head . ' ' . $tail] = true;
                if (count($out) >= 500) {
                    break 2;
                }
            }
        }
        $i = 0;
        while (count($out) < 500) {
            $i++;
            $out['adjacent phrase ' . $i] = true;
        }
        return array_slice(array_keys($out), 0, 500);
    }

    public static function load_phrase_history(): array
    {
        if (!is_file(STORE_PHRASES)) {
            $list = default_phrase_list();
            save_json(STORE_PHRASES, $list);
            return $list;
        }
        $data = load_json(STORE_PHRASES, []);
        if (count($data) < 100) {
            $list = default_phrase_list();
            save_json(STORE_PHRASES, $list);
            return $list;
        }
        return array_values($data);
    }

    public static function save_phrase_history(array $list): bool
    {
        $clean = [];
        foreach ($list as $phrase) {
            $phrase = strtolower(trim(preg_replace('/\s+/', ' ', (string) $phrase)));
            $phrase = trim(preg_replace('/[^a-z0-9 \'-]+/', '', $phrase));
            if ($phrase === '' || strlen($phrase) > 120) {
                continue;
            }
            $clean[$phrase] = true;
            if (count($clean) >= 2000) {
                break;
            }
        }
        return save_json(STORE_PHRASES, array_keys($clean));
    }
}
