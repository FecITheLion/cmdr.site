<?php

declare(strict_types=1);

/** Main HTTP request controller. */
final class AppController
{
    public static function run(): void
    {
        $uriPath = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : '/';
        
        // CORS headers for assets and responses
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Accept');
        header('Cross-Origin-Resource-Policy: cross-origin');
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
        
        if (isset($_GET['cache']) && $_GET['cache'] === 'status') {
            header('Content-Type: application/json; charset=utf-8');
            $assets = asset_sync(false);
            $vars = var_cache_get(false);
            echo json_encode([
                'ok' => true,
                'assets' => $assets,
                'vars_cached' => is_array($vars),
                'vars_age' => is_file(DIR_CACHE . '/vars.json') ? time() - filemtime(DIR_CACHE . '/vars.json') : null,
            ]);
            exit;
        }
        
        if (isset($_GET['vendor']) && $_GET['vendor'] === 'status') {
            header('Content-Type: application/json; charset=utf-8');
            vendor_boot(false);
            $rows = [];
            foreach (vendor_packages() as $pkg) {
                $meta = vendor_meta((string) $pkg['name']);
                $rows[] = [
                    'name' => $pkg['name'],
                    'repo' => $pkg['repo'],
                    'tag' => $meta['tag'] ?? '',
                    'dir' => vendor_dir((string) $pkg['name']),
                    'ready' => is_dir(vendor_dir((string) $pkg['name'])),
                ];
            }
            echo json_encode(['ok' => true, 'packages' => $rows]);
            exit;
        }
        
        if (isset($_GET['robots']) || preg_match('#/robots\.txt$#', $_SERVER['REQUEST_URI'] ?? '')) {
            header('Content-Type: text/plain; charset=utf-8');
            echo publish_robots(load_web());
            exit;
        }
        
        if (isset($_GET['generate-sitemap']) || isset($_GET['sitemap']) || isset($_GET['sitemap-index'])
            || preg_match('#/sitemap(?:-index|-\\d+)?\\.xml$#', $_SERVER['REQUEST_URI'] ?? '')
        ) {
            publish_sitemaps();
            serve_sitemap();
            exit;
        }
        
        if (isset($_GET['manifest']) || $uriPath === '/manifest.webmanifest' || preg_match('#/manifest\.webmanifest$#', $uriPath)) {
            header('Access-Control-Allow-Origin: https://www.cmdr.site');
            header('Content-Type: application/manifest+json; charset=utf-8');
            header('Cache-Control: public, max-age=86400');
            header('X-Content-Type-Options: nosniff');
            $manifestPath = APP_ROOT . '/manifest.webmanifest';
            if (is_file($manifestPath)) {
                readfile($manifestPath);
            } else {
                echo app_manifest();
            }
            exit;
        }
        
        if (isset($_GET['sw']) || $uriPath === '/sw.js') {
            header('Content-Type: application/javascript; charset=utf-8');
            header('Service-Worker-Allowed: /');
            header('Cache-Control: no-cache');
            echo app_worker();
            exit;
        }
        
        if (isset($_GET['prepare']) || $uriPath === '/prepare') {
            header('HTTP/1.1 204 No Content');
            header('Cache-Control: no-store');
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seek'])) {
            header('Content-Type: application/json');
            $list = load_providers();
        
            if ($_POST['seek'] === 'crawl') {
                $step = crawl_step();
                publish_robots(load_web());
                publish_sitemaps();
                echo json_encode($step);
                exit;
            }
        
            if ($_POST['seek'] === 'hit' && isset($_POST['id'])) {
                foreach ($list as &$row) {
                    if ($row['id'] === $_POST['id']) {
                        $row['hits'] = ($row['hits'] ?? 0) + 1;
                        $row['updated'] = time();
                    }
                }
                unset($row);
                save_providers($list);
                echo json_encode(['ok' => true, 'providers' => $list]);
                exit;
            }
        
            if ($_POST['seek'] === 'discover') {
                $raw = $_POST['q'] ?? '';
                $via = $_POST['via'] ?? '';
                $ban = load_ban();
                if (is_banned($raw, $ban)) {
                    echo json_encode(['ok' => false, 'banned' => true]);
                    exit;
                }
                $fixed = autocorrect($raw);
                if ($fixed) {
                    echo json_encode(['ok' => true, 'autocorrect' => $fixed]);
                    exit;
                }
                $lookup = 'https://duckduckgo.com/html/?q={term}';
                $ai = 'https://www.perplexity.ai/search?q={term}';
                foreach ($list as $row) {
                    if ($row['id'] === $via) {
                        $lookup = $row['template'];
                    }
                    if ($row['id'] === 'perplexity' || $row['id'] === 'you') {
                        $ai = $row['template'];
                    }
                }
                $q = rawurlencode('"' . $raw . '" SearchAction URL pattern');
                $normal = patterns_from_dom(http_get(str_replace('{term}', $q, $lookup)), $raw);
                $ai1 = patterns_from_dom(http_get(str_replace('{term}', $q, $ai)), $raw);
                $ai2 = patterns_from_dom(http_get(str_replace('{term}', $q, $ai)), $raw);
                $chosen = pick_three([$normal, $ai1, $ai2], 1);
                if (!$chosen) {
                    note_fail($raw);
                    echo json_encode(['ok' => false, 'asks' => 3]);
                    exit;
                }
                echo json_encode(['ok' => true, 'name' => $raw, 'template' => $chosen]);
                exit;
            }
        
            if ($_POST['seek'] === 'add') {
                $name = substr(preg_replace('/[^\w .\-]/', '', trim($_POST['name'] ?? '')), 0, 40);
                $template = normalize_template(trim($_POST['template'] ?? ''));
                if ($name !== '' && valid_template($template)) {
                    $id = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));
                    $found = false;
                    foreach ($list as &$row) {
                        if ($row['id'] === $id) {
                            $row['template'] = $template;
                            $row['name'] = $name;
                            $row['updated'] = time();
                            $found = true;
                        }
                    }
                    unset($row);
                    if (!$found) {
                        $list[] = ['id' => $id, 'name' => $name, 'template' => $template, 'hits' => 0, 'updated' => time()];
                    }
                    save_providers($list);
                    claim_aliases($name);
                    echo json_encode(['ok' => true, 'id' => $id, 'providers' => $list]);
                    exit;
                }
                echo json_encode(['ok' => false]);
                exit;
            }
        
            if ($_POST['seek'] === 'phrases') {
                if (($_POST['action'] ?? 'load') === 'update') {
                    $incoming = json_decode((string) ($_POST['phrases'] ?? ''), true);
                    $current = load_phrase_history();
                    if (is_array($incoming)) {
                        foreach ($incoming as $phrase) {
                            $current[] = (string) $phrase;
                        }
                        save_phrase_history($current);
                        $current = load_phrase_history();
                    }
                    echo json_encode(['ok' => true, 'count' => count($current)]);
                    exit;
                }
                echo json_encode(['ok' => true, 'phrases' => load_phrase_history()]);
                exit;
            }
        
            echo json_encode(['ok' => false]);
            exit;
        }
        
        // ---------------------------------------------------------------------------
        // Main Page Data
        // ---------------------------------------------------------------------------
        
        $forceCache = isset($_GET['cache']) && $_GET['cache'] === 'update';
        $cachedVars = var_cache_get($forceCache);
        if ($cachedVars) {
            $web = $cachedVars['web'];
            $providers = $cachedVars['providers'];
            $items = $cachedVars['items'];
        } else {
            $web = load_web();
            publish_robots($web);
            publish_sitemaps();
            $providers = load_providers();
            usort($providers, function ($a, $b) {
                $na = ($a['hits'] ?? 0) + ((time() - ($a['updated'] ?? 0)) < 604800 ? 3 : 0);
                $nb = ($b['hits'] ?? 0) + ((time() - ($b['updated'] ?? 0)) < 604800 ? 3 : 0);
                if ($na === $nb) {
                    return ($b['updated'] ?? 0) - ($a['updated'] ?? 0);
                }
                return $nb - $na;
            });
            $providers = array_slice($providers, 0, 16);
        
            $base = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : APP_ROOT;
            $skip = '/^(?:cgi-bin|node_modules|vendor|assets|static|css|js|img|images|fonts|templates|cache)$/i';
            $circular = [];
            $realStack = [];
            $relStack = [];
        
            $scan = function (string $rel) use (&$scan, &$circular, &$realStack, &$relStack, $base, $skip): array {
                $full = $base . ($rel === '' ? '' : '/' . $rel);
                $real = realpath($full);
                if ($real && in_array($real, $realStack, true)) {
                    note_circular($circular, array_merge($relStack, [$rel]));
                    return [];
                }
                if ($real) {
                    $realStack[] = $real;
                }
                $relStack[] = $rel;
                $found = [];
                $files = false;
                $subs = [];
                $names = @scandir($full);
                if (!$names) {
                    array_pop($relStack);
                    if ($real) {
                        array_pop($realStack);
                    }
                    return $found;
                }
                foreach ($names as $name) {
                    if ($name === '.' || $name === '..' || $name[0] === '.') {
                        continue;
                    }
                    $path = $full . '/' . $name;
                    if (is_dir($path)) {
                        if (!preg_match($skip, $name)) {
                            $subs[] = ($rel === '' ? $name : $rel . '/' . $name);
                        }
                    } elseif (is_file($path)) {
                        $files = true;
                    }
                }
                $children = [];
                foreach ($subs as $sub) {
                    $children = array_merge($children, $scan($sub));
                }
                if ($rel !== '' && ($files || $children)) {
                    $found[] = $rel;
                }
                array_pop($relStack);
                if ($real) {
                    array_pop($realStack);
                }
                return array_merge($found, $children);
            };
        
            $folders = array_values(array_unique($scan('')));
            crawl_circular($base, $folders, $circular);
            save_circular_log($circular);
        
            $parts = [];
            foreach ($folders as $p) {
                $parts[] = explode('/', $p);
            }
            $items = [];
            foreach ($parts as $i => $segs) {
                $label = $segs[count($segs) - 1];
                for ($n = 1; $n <= count($segs); $n++) {
                    $tail = implode('/', array_slice($segs, -$n));
                    $hits = 0;
                    foreach ($parts as $other) {
                        if (implode('/', array_slice($other, -$n)) === $tail) {
                            $hits++;
                        }
                    }
                    if ($hits === 1) {
                        $label = $tail;
                        break;
                    }
                }
                $items[] = [
                    'path'    => $folders[$i],
                    'label'   => $label,
                    'keyword' => $label,
                    'uri'     => full_uri($folders[$i]),
                    'log'     => isset($circular[$folders[$i]]) ? implode(' | ', $circular[$folders[$i]]) : '',
                ];
            }
            foreach ($web['nodes'] as $node) {
                $items[] = [
                    'path'    => 'k/' . strtolower(preg_replace('/[^a-z0-9]+/i', '-', $node['keyword'])),
                    'label'   => $node['keyword'],
                    'keyword' => $node['keyword'],
                    'uri'     => $node['uri'],
                    'source'  => $node['source'] ?? '',
                    'log'     => $node['log'] ?? '',
                ];
            }
            shuffle($items);
            var_cache_put([
                'web' => $web,
                'providers' => $providers,
                'items' => $items,
            ]);
        }
        
        $focus = isset($_GET['k']) ? (string) $_GET['k'] : '';
        $warn = lookup_k($web, $focus);
        $prepare = $warn ? site_origin() . '/prepare?k=' . rawurlencode($warn['keyword']) : '';
        $ping = $warn ? $warn['source'] . ' ' . $prepare : '';
        $pageTitle = $warn ? ($warn['keyword'] . " — leaving Mister Rogers'") : "Mister Rogers' - Website";
        
        
        // dictionary proxy with caching
        if (isset($_GET['dict'])) {
            $word = trim($_GET['dict']);
        
            // sanitize: only letters/spaces
            $word = preg_replace('/[^a-zA-Z\s]/', '', $word);
        
            // cache directory
            $cacheDir = DIR_DICTIONARY;
            if (!is_dir($cacheDir)) {
                mkdir($cacheDir, 0777, true);
            }
        
            // cache file path
            $cacheFile = $cacheDir . "/" . md5($word) . ".json";
        
            // serve cached result if exists
            if (file_exists($cacheFile)) {
                header("Content-Type: application/json");
                echo file_get_contents($cacheFile);
                exit;
            }
        
            // fetch from dictionary API
            $url = "https://api.dictionaryapi.dev/api/v2/entries/en/" . urlencode($word);
        
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
            $result = curl_exec($ch);
            curl_close($ch);
        
            // save to cache
            file_put_contents($cacheFile, $result);
        
            header("Content-Type: application/json");
            echo $result;
            exit;
        }
        
        // ***********************************
        
        
        $homeUrl = site_origin() . '/';
        $ogUrl = $focus !== '' ? keyword_uri($focus) : 'https://www.cmdr.site/';
        $viewNodes = [];
        foreach ($web['nodes'] as $node) {
            $source = (string) ($node['source'] ?? '');
            $keyword = (string) ($node['keyword'] ?? '');
            $viewNodes[] = [
                'keyword' => $keyword,
                'uri' => (string) ($node['uri'] ?? ''),
                'log' => (string) ($node['log'] ?? ''),
                'source' => $source,
                'back' => !empty($node['back']) ? '1' : '0',
                'current' => $focus !== '' && strcasecmp($focus, $keyword) === 0,
                'external' => $source !== '' && !is_home($source),
                'ping' => $source !== '' ? ($source . ' ' . site_origin() . '/prepare?k=' . rawurlencode($keyword)) : '',
                'related' => array_values($node['related'] ?? []),
            ];
        }
        if (is_array($warn)) {
            $warn['ping'] = $ping;
        }
        
        vendor_boot(isset($_GET['vendor']) && $_GET['vendor'] === 'update');
        $assets = asset_sync($forceCache);
        if (!class_exists('\\Smarty\\Smarty')) {
            http_response_code(500);
            header('Content-Type: text/plain; charset=utf-8');
            echo "Smarty vendor is not available. Check cache/vendor/smarty and PHP zip/curl.\n";
            exit;
        }
        ensure_dir(DIR_TEMPLATES);
        ensure_dir(DIR_COMPILE);
        ensure_dir(DIR_SMARTY_CACHE);
        $smarty = new \Smarty\Smarty();
        $smarty->setLeftDelimiter('{{');
        $smarty->setRightDelimiter('}}');
        if (method_exists($smarty, 'setEscapeHtml')) {
            $smarty->setEscapeHtml(true);
        }
        $smarty->setTemplateDir(DIR_TEMPLATES);
        $smarty->setCompileDir(DIR_COMPILE);
        $smarty->setCacheDir(DIR_SMARTY_CACHE);
        $smarty->assign([
            'pageTitle' => $pageTitle,
            'ogUrl' => $ogUrl,
            'homeUrl' => $homeUrl,
            'warn' => $warn,
            'nodes' => $viewNodes,
            'hasItems' => !empty($items),
            'assets' => $assets,
            'pageVars' => json_encode([
                'items' => $items,
                'providers' => $providers,
                'focus' => $focus,
                'fbsdk' => $assets['fbsdk'] ?? '',
            ]),
        ]);
        
        
        // ===============================
        // SERVICE WORKER ENDPOINT
        // ===============================
        if (isset($_GET['sw'])) {
        
        header('Content-Type: application/javascript');
        header('Cache-Control: no-cache');
        
        $APP_VERSION = trim(file_get_contents(APP_ROOT . '/version.txt') ?: '1.0.0');
        
        echo <<<JS
        const APP_VERSION = '{$APP_VERSION}';
        const CACHE_NAME = 'cmdr-cache-' + APP_VERSION;
        
        // Report version to the page
        self.addEventListener('message', (event) => {
          if (event.data === 'GET_VERSION') {
            event.source.postMessage({ version: APP_VERSION });
          }
        });
        
        // Install: precache static assets only
        self.addEventListener('install', (event) => {
          event.waitUntil(
            caches.open(CACHE_NAME).then((cache) =>
              cache.addAll([
                '/css/app.css',
                '/js/app.js',
                '/icons/icon-192.png',
                '/icons/icon-512.png'
              ])
            )
          );
          self.skipWaiting();
        });
        
        // Activate: remove old caches
        self.addEventListener('activate', (event) => {
          event.waitUntil(
            caches.keys().then((keys) =>
              Promise.all(keys.map((key) => {
                if (key !== CACHE_NAME) return caches.delete(key);
              }))
            )
          );
          self.clients.claim();
        });
        
        // Runtime caching for static GET assets only
        self.addEventListener('fetch', (event) => {
          const req = event.request;
        
          if (req.method !== 'GET') return;
          if (req.mode === 'navigate') return;     // let browser handle navigation
          if (!req.url.startsWith('http')) return;
        
          const url = new URL(req.url);
          if (url.searchParams.has('sw')) return;  // skip ?sw=1
          if (url.pathname.endsWith('/index.php')) return; // dynamic
        
          event.respondWith(
            caches.match(req).then((cached) => {
              const fetchPromise = fetch(req).then((res) => {
                if (!res || res.status !== 200 || res.type === 'opaque') return res;
                const copy = res.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
                return res;
              }).catch(() => cached || Promise.reject('offline'));
              return cached || fetchPromise;
            })
          );
        });
        JS;
        
        exit;
        
        }
        
        // ===============================
        // NORMAL PAGE OUTPUT
        // ===============================
        $smarty->display('index.html');
    }
}
