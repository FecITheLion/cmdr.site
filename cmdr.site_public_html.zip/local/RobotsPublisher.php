<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class RobotsPublisherModule
{

    public static function build_robots(array $state): string
    {
        $lines = [
            'User-agent: *',
            'Allow: /',
            'Disallow: /provider-logs/',
            'Disallow: /cache/',
            'Disallow: /search-providers.json',
            'Disallow: /provider-ban.json',
            'Disallow: /crawl-web.json',
            'Disallow: /crawl-circular.log',
            'Disallow: /phrase-history.json',
            'Disallow: /vendor.json',
            'Disallow: /defaults.json',
            'Crawl-delay: 3',
            'Sitemap: ' . site_origin() . '/sitemap-index.xml',
            '# keyword web',
        ];
        foreach ($state['nodes'] as $node) {
            $lines[] = '# ' . $node['uri'];
            if (!empty($node['source'])) {
                $lines[] = '# source ' . $node['source'];
            }
            if (!empty($node['log'])) {
                $lines[] = '# log ' . $node['log'];
            }
        }
        return implode("\n", $lines) . "\n";
    }

    public static function publish_robots(array $state): string
    {
        $body = build_robots($state);
        $targets = [APP_ROOT . '/robots.txt'];
        if (!empty($_SERVER['DOCUMENT_ROOT'])) {
            $targets[] = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/robots.txt';
        }
        foreach (array_unique($targets) as $path) {
            if (is_file($path) && time() - filemtime($path) < 3600 && md5_file($path) === md5($body)) {
                continue;
            }
            file_put_contents($path, $body, LOCK_EX);
        }
        return $body;
    }
}
