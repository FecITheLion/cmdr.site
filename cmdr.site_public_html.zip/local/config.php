<?php

declare(strict_types=1);

// Application root is the parent of this local/ directory.
define('APP_ROOT', dirname(__DIR__));

define('STORE_PROVIDERS', APP_ROOT . '/search-providers.json');
define('STORE_WEB', APP_ROOT . '/crawl-web.json');
define('STORE_BAN', APP_ROOT . '/provider-ban.json');
define('STORE_DEFAULTS', APP_ROOT . '/defaults.json');
define('STORE_PHRASES', APP_ROOT . '/phrase-history.json');
define('STORE_VENDOR', APP_ROOT . '/vendor.json');
define('DIR_CACHE', APP_ROOT . '/cache');
define('DIR_VENDOR', DIR_CACHE . '/vendor');
define('DIR_TEMPLATES', APP_ROOT . '/templates');
define('DIR_COMPILE', DIR_CACHE . '/template');
define('DIR_SMARTY_CACHE', DIR_CACHE . '/smarty');
define('DIR_DICTIONARY', DIR_CACHE . '/dictionary');
define('DIR_ROBOTS', DIR_CACHE . '/robot');
define('DIR_LOGS', APP_ROOT . '/provider-logs');
define('LOG_CIRCULAR', APP_ROOT . '/crawl-circular.log');
define('ASSET_TTL', 86400);
define('VAR_TTL', 300);
