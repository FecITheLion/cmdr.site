<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class PwaAssetsModule
{

    public static function app_manifest(): string
    {
        return json_encode([
            'id'                       => 'https://www.cmdr.site/',
            'name'                     => "Mister Rogers' Neighborhood",
            'short_name'               => "Mister Rogers'",
            'description'              => 'Inquiry, consultation, and integration for HyperWeb network work.',
            'start_url'                => 'https://www.cmdr.site/?source=pwa',
            'scope'                    => 'https://www.cmdr.site/',
            'display'                  => 'standalone',
            'display_override'         => ['window-controls-overlay', 'standalone', 'minimal-ui'],
            'background_image'         => "url('https://www.cmdr.site/image/B-G-R.gif')",
            'theme_color'              => '#ffffff',
            'lang'                     => 'en',
            'dir'                      => 'ltr',
            'categories'               => ['utilities', 'lifestyle'],
            'prefer_related_applications' => false,
            'handle_links'             => 'preferred',
            'launch_handler'           => ['client_mode' => 'navigate-existing'],
            'icons'                    => [
                ['src' => 'https://www.cmdr.site/image/favicon.svg', 'sizes' => 'any', 'type' => 'image/svg+xml', 'purpose' => 'any'],
                ['src' => 'https://www.cmdr.site/image/banner.jpg', 'sizes' => '1792x1008', 'type' => 'image/jpeg', 'purpose' => 'any'],
            ],
        ], JSON_UNESCAPED_SLASHES);
    }

    public static function app_worker(): string
    {
        $path = APP_ROOT . '/sw.js';
        return is_file($path) ? file_get_contents($path) : "self.addEventListener('fetch',function(){});";
    }
}
