<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class ProviderManagerModule
{

    public static function load_providers(): array
    {
        $defaults = load_defaults();
        return load_json(STORE_PROVIDERS, $defaults['providers']);
    }

    public static function save_providers(array $list): bool
    {
        return save_json(STORE_PROVIDERS, $list);
    }

    public static function valid_template(string $url): bool
    {
        return preg_match('#^https://#i', $url) === 1
            && preg_match('/\{[a-z0-9_]+\}/i', $url) === 1;
    }

    public static function normalize_template(string $url): string
    {
        return preg_replace('/\{[a-z0-9_]+\}/i', '{term}', $url, 1);
    }

    public static function param_count(string $url): int
    {
        $query = parse_url($url, PHP_URL_QUERY);
        if (!$query) {
            return substr_count($url, '{term}');
        }
        parse_str($query, $params);
        return count($params);
    }

    public static function load_ban(): array
    {
        return load_json(STORE_BAN);
    }

    public static function save_ban(array $ban): void
    {
        file_put_contents(STORE_BAN, json_encode($ban));
    }

    public static function is_banned(string $raw, array $ban): bool
    {
        $key = strtolower(trim($raw));
        return isset($ban[$key]) && ($ban[$key]['fails'] ?? 0) >= 2;
    }

    public static function note_fail(string $raw): void
    {
        $ban = load_ban();
        $key = strtolower(trim($raw));
        if (!isset($ban[$key])) {
            $ban[$key] = ['fails' => 0, 'asks' => 0];
        }
        $ban[$key]['fails']++;
        $ban[$key]['asks'] += 3;
        save_ban($ban);
    }

    public static function claim_aliases(string $name): void
    {
        $ban = load_ban();
        $id = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));
        if (!ensure_dir(DIR_LOGS)) {
            return;
        }
        $kept = [];
        $log = [];
        foreach ($ban as $alias => $row) {
            similar_text(strtolower($name), $alias, $pct);
            if ($pct >= 55) {
                $log[] = $alias;
            } else {
                $kept[$alias] = $row;
            }
        }
        if ($log) {
            file_put_contents(DIR_LOGS . '/' . $id . '.log', implode("\n", $log) . "\n", FILE_APPEND);
        }
        save_ban($kept);
    }

    public static function autocorrect(string $raw): ?string
    {
        if (!is_dir(DIR_LOGS)) {
            return null;
        }
        foreach (glob(DIR_LOGS . '/*.log') as $file) {
            $lines = file($file, FILE_IGNORE_NEW_LINES);
            if (in_array(strtolower(trim($raw)), array_map('strtolower', $lines), true)) {
                return basename($file, '.log');
            }
        }
        return null;
    }
}
