<?php

declare(strict_types=1);

/**
 * Object-oriented module extracted from the original index.php.
 * Public static methods preserve the existing application behavior.
 */
final class UrlToolsModule
{

    public static function site_origin(): string
    {
        $host = $_SERVER['HTTP_HOST'] ?? 'cmdr.site';
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
            || (($_SERVER['SERVER_PORT'] ?? '') === '443');
        return ($https ? 'https' : 'http') . '://' . $host;
    }

    public static function full_uri(string $rel): string
    {
        $rel = trim(str_replace('\\', '/', $rel), '/');
        return site_origin() . '/' . ($rel === '' ? '' : $rel . '/');
    }

    public static function keyword_uri(string $keyword): string
    {
        return site_origin() . '/?k=' . rawurlencode($keyword);
    }

    public static function is_home(string $url): bool
    {
        $host = parse_url($url, PHP_URL_HOST);
        $mine = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : 'cmdr.site';
        return $host && (
            strcasecmp($host, $mine) === 0
            || strcasecmp($host, 'cmdr.site') === 0
            || strcasecmp($host, 'www.cmdr.site') === 0
        );
    }

    public static function host_robots(string $host): string
    {
        if (!ensure_dir(DIR_ROBOTS)) {
            return "User-agent: *\nAllow: /\n";
        }
        $file = DIR_ROBOTS . '/' . preg_replace('/[^a-z0-9.-]+/i', '_', strtolower($host)) . '.txt';
        if (!is_file($file) || time() - filemtime($file) > 86400) {
            $body = http_get('https://' . $host . '/robots.txt');
            file_put_contents($file, $body === '' ? "User-agent: *\nAllow: /\n" : $body, LOCK_EX);
        }
        return is_file($file) ? file_get_contents($file) : '';
    }

    public static function robots_allows(string $url): bool
    {
        $host = parse_url($url, PHP_URL_HOST);
        $path = parse_url($url, PHP_URL_PATH) ?: '/';
        if (!$host) {
            return false;
        }
        $txt = host_robots($host);
        $ua = '*';
        $disallows = [];
        foreach (preg_split('/\r\n|\n|\r/', $txt) as $line) {
            $line = trim(preg_replace('/#.*$/', '', $line));
            if ($line === '') {
                continue;
            }
            if (stripos($line, 'User-agent:') === 0) {
                $ua = trim(substr($line, 11));
                continue;
            }
            if ($ua !== '*') {
                continue;
            }
            if (stripos($line, 'Disallow:') === 0) {
                $rule = trim(substr($line, 9));
                if ($rule !== '') {
                    $disallows[] = $rule;
                }
            }
        }
        foreach ($disallows as $rule) {
            if (strpos($path, $rule) === 0) {
                return false;
            }
        }
        return true;
    }
}
