# PHP OOP modular refactor

## Layout

- `index.php` is the front controller and loads the application.
- `local/config.php` defines project paths and cache constants.
- `local/bootstrap.php` loads modules in a deterministic order.
- Domain classes (`DefaultsModule`, `VendorManagerModule`, `KeywordWebModule`, etc.) hold the extracted logic.
- `local/legacy_api.php` provides compatibility functions that delegate to the classes. This lets the request handler preserve existing call sites while the refactor is introduced safely.
- `local/AppController.php` contains the original request-routing and response flow in `AppController::run()`.

## Install

1. Back up the current `index.php`.
2. Copy the new `index.php` and the entire `local/` directory into the same project root.
3. Keep existing JSON data files, `templates/`, assets, and cache directories in place.
4. Ensure the web server can read the PHP files and write to the application's existing cache/data locations.

The refactor aims to preserve behavior rather than redesign it. Test on staging before replacing a production entry point.
