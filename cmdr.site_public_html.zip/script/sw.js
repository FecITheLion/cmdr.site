var CACHE = 'cmdr-app-v1';
var SHELL = ['https://www.cmdr.site/', 'https://www.cmdr.site/image/favicon.svg', 'https://www.cmdr.site/image/banner.jpg', 'https://www.cmdr.site/image/manifest.webmanifest'];

self.addEventListener('install', function (event) {
  event.waitUntil(caches.open(CACHE).then(function (cache) {
    return cache.addAll(SHELL).catch(function () {});
  }));
  self.skipWaiting();
});

self.addEventListener('activate', function (event) {
  event.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (key) { return key !== CACHE; }).map(function (key) {
      return caches.delete(key);
    }));
  }));
  self.clients.claim();
});

self.addEventListener('fetch', function (event) {
  var req = event.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname === '/sw.js' || url.pathname === '/prepare') return;
  event.respondWith(fetch(req).then(function (res) {
    if (res && res.ok && (req.mode === 'navigate' || /\.(svg|png|jpe?g|ico|webmanifest)$/.test(url.pathname))) {
      var copy = res.clone();
      caches.open(CACHE).then(function (cache) { cache.put(req, copy); });
    }
    return res;
  }).catch(function () {
    return caches.match(req).then(function (hit) {
      return hit || caches.match('/');
    });
  }));
});