(function () {
    var items = (window.CMDR && window.CMDR.items) || [];
    var providers = (window.CMDR && window.CMDR.providers) || [];
    var host = document.getElementById('folderpool');
    var box = document.getElementById('seekbox');
    var prov = document.getElementById('prov');
    var q = document.getElementById('q');
    var list = document.getElementById('provlist');
    var web = document.getElementById('keywordweb');
    var cars = [], last = 0, aim = null, mouseSpeed = 0, hueOf = {}, AGGRO = 160;
    var endpoint = location.pathname;
    var activeTouchId = null;
    var isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
    var tracking = false;
    var touchStart = null;
    var TAP_THRESHOLD = 12;
    var TAP_TIME = 300;

    function getConsent() { return localStorage.getItem('cmdr-consent') === 'accepted'; }
    function setConsent(val) { localStorage.setItem('cmdr-consent', val); }
    function getPref() { return getConsent() ? (localStorage.getItem('cmdr-search-pref') || '') : ''; }
    function setPref(id) { if (getConsent()) localStorage.setItem('cmdr-search-pref', id); }
    var pref = getPref();

    if (pref) providers = providers.filter(function (p) { return p.id === pref; }).concat(providers.filter(function (p) { return p.id !== pref; })).slice(0, 1);

    function hue(path) {
        if (hueOf[path]) return hueOf[path];
        var h = 0;
        for (var i = 0; i < path.length; i++) h = (h * 33 + path.charCodeAt(i)) % 360;
        hueOf[path] = h;
        return h;
    }
    function postSeek(body) {
        return fetch(endpoint, { method: 'POST', body: body, headers: { 'Accept': 'application/json' } }).then(function (r) {
            return r.text().then(function (text) {
                if (text.charAt(0) !== '{') throw new Error('not json');
                return JSON.parse(text);
            });
        });
    }
    function fillList(needle) {
        var n = (needle || '').toLowerCase();
        list.innerHTML = '';
        providers.filter(function (p) { return !n || p.name.toLowerCase().indexOf(n) === 0; }).forEach(function (p) {
            var o = document.createElement('option');
            o.value = p.name;
            list.appendChild(o);
        });
    }
    function matchProv(text) {
        var t = text.trim().toLowerCase();
        for (var i = 0; i < providers.length; i++) if (providers[i].name.toLowerCase() === t) return providers[i];
        return null;
    }
    function parseNew(text) {
        text = text.trim();
        if (text.charAt(0) === '{') {
            try {
                var ld = JSON.parse(text);
                var action = ld.potentialAction;
                if (Array.isArray(action)) action = action[0];
                var target = action && action.target;
                var template = typeof target === 'string' ? target : (target && target.urlTemplate) || ld.urlTemplate || '';
                var name = ld.name || (template.indexOf('youtube.com') !== -1 ? 'YouTube' : 'Custom');
                return template ? { name: name, template: template.replace(/\{[a-z0-9_]+\}/i, '{term}') } : null;
            } catch (e) { return null; }
        }
        var url = text.match(/https:\/\/\S+/);
        if (!url) return null;
        var template = url[0].replace(/\{[a-z0-9_]+\}/i, '{term}');
        if (template.indexOf('{term}') === -1) template += (template.indexOf('?') === -1 ? '?q={term}' : '&q={term}');
        var name = text.slice(0, url.index).trim();
        if (!name) name = /youtube\.com/.test(template) ? 'YouTube' : 'Custom';
        return { name: name, template: template };
    }
    function failProv() {
        prov.classList.remove('bad');
        void prov.offsetWidth;
        prov.classList.add('bad');
        prov.style.background = '#ffd0d0';
        prov.focus();
        prov.select();
    }
    function saveNew(info) {
        var body = new FormData();
        body.append('seek', 'add');
        body.append('name', info.name);
        body.append('template', info.template);
        return postSeek(body).then(function (data) {
            if (!data.ok) return null;
            providers = data.providers;
            pref = data.id;
            setPref(data.id);
            prov.value = info.name;
            prov.classList.remove('bad');
            prov.style.background = '';
            fillList('');
            return matchProv(info.name);
        });
    }
    function discover(text) {
        var body = new FormData();
        body.append('seek', 'discover');
        body.append('q', text);
        body.append('via', pref || (providers[0] && providers[0].id) || '');
        return postSeek(body).then(function (data) {
            if (data.banned) { failProv(); return null; }
            if (data.autocorrect) {
                var hit = providers.filter(function (p) { return p.id === data.autocorrect; })[0];
                if (hit) { prov.value = hit.name; pref = hit.id; setPref(hit.id); return hit; }
            }
            if (!data.ok) { failProv(); return null; }
            return saveNew({ name: data.name, template: data.template });
        }).catch(function () { failProv(); return null; });
    }
    function commitProv() {
        var known = matchProv(prov.value);
        if (known) { pref = known.id; setPref(known.id); prov.classList.remove('bad'); prov.style.background = ''; return Promise.resolve(known); }
        var info = parseNew(prov.value);
        if (info) return saveNew(info);
        if (prov.value.trim().length < 2) return Promise.resolve(null);
        return discover(prov.value);
    }
    function go(p) {
        if (!p || !q.value.trim()) { if (!p) failProv(); return; }
        window.open(p.template.replace('{term}', encodeURIComponent(q.value.trim())), '_blank', 'noopener');
        var body = new FormData();
        body.append('seek', 'hit');
        body.append('id', p.id);
        postSeek(body).catch(function () {});
        box.style.display = 'none';
    }
// Phrase list is loaded only when + or - is used.
// Dictionary expansion is tried first; brands like "linkedin" fall back to phrase-history.json.
let history = [];
let historyLoaded = false;

function ensureHistory() {
    if (historyLoaded) return Promise.resolve(history);
    var body = new FormData();
    body.append('seek', 'phrases');
    body.append('action', 'load');
    return postSeek(body).then(function (data) {
        if (data && data.ok && Array.isArray(data.phrases) && data.phrases.length) {
            history = data.phrases;
        }
        historyLoaded = true;
        return history;
    }).catch(function () {
        historyLoaded = true;
        return history;
    });
}

function rememberPhrases(terms) {
    var fresh = [];
    terms.forEach(function (term) {
        term = String(term || '').replace(/\s+/g, ' ').trim().toLowerCase();
        if (!term || history.indexOf(term) !== -1) return;
        history.push(term);
        fresh.push(term);
    });
    if (!fresh.length) return;
    var body = new FormData();
    body.append('seek', 'phrases');
    body.append('action', 'update');
    body.append('phrases', JSON.stringify(fresh));
    postSeek(body).catch(function () {});
}

const mandatoryAdjacency = {
    "of":   { after: true, before: false },
    "for":  { after: true, before: false },
    "to":   { after: true, before: false },
    "a":    { after: true, before: false },
    "an":   { after: true, before: false },
    "the":  { after: true, before: false },
    "of course": { sequence: ["of", "course"] },
    "for you":   { sequence: ["for", "you"] }
};

async function getSynAnt(phrase) {
    const words = String(phrase || '').split(/\s+/).filter(function (w) { return w.length > 2; });
    const syns = [];
    const ants = [];
    for (const w of words) {
        try {
            const res = await fetch(endpoint + (endpoint.indexOf('?') === -1 ? '?' : '&') + 'dict=' + encodeURIComponent(w));
            const json = await res.json();
            if (!Array.isArray(json)) continue;
            json.forEach(function (entry) {
                (entry.meanings || []).forEach(function (m) {
                    (m.definitions || []).forEach(function (d) {
                        if (d.synonyms) syns.push.apply(syns, d.synonyms);
                        if (d.antonyms) ants.push.apply(ants, d.antonyms);
                    });
                });
            });
        } catch (e) {}
    }
    return {
        syns: syns.filter(function (s, i) { return s && syns.indexOf(s) === i; }),
        ants: ants.filter(function (s, i) { return s && ants.indexOf(s) === i; })
    };
}

function enforceMandatoryAdjacency(words) {
    const out = words.slice();
    for (let i = 0; i < out.length; i++) {
        const w = out[i];
        if (mandatoryAdjacency[w] && mandatoryAdjacency[w].sequence) {
            const seq = mandatoryAdjacency[w].sequence;
            seq.forEach(function (part, idx) {
                if (out[i + idx] !== part) out.splice(i + idx, 0, part);
            });
            continue;
        }
        const rule = mandatoryAdjacency[w];
        if (!rule) continue;
        if (rule.after && !out[i + 1]) out.push('item');
        if (rule.before && !out[i - 1]) out.unshift('item');
    }
    return out;
}

function clampWords(words) {
    const unique = [];
    words.forEach(function (w) {
        if (w && unique.indexOf(w) === -1) unique.push(w);
    });
    if (unique.length > 7) unique.length = 7;
    return unique;
}

function pickAdjacent(seed) {
    const s = seed.toLowerCase();
    const list = history.filter(function (p) { return typeof p === 'string' && p; });
    let pool = list.filter(function (p) {
        const pl = p.toLowerCase();
        return pl !== s && pl.indexOf(s) !== -1;
    });
    if (!pool.length) {
        const tokens = s.split(/\s+/).filter(function (t) { return t.length > 2; });
        pool = list.filter(function (p) {
            const pl = p.toLowerCase();
            return pl !== s && tokens.some(function (t) { return pl.indexOf(t) !== -1; });
        });
    }
    if (!pool.length) return '';
    let cursor = 0;
    const key = 'cmdr-adj-' + s;
    try { cursor = parseInt(sessionStorage.getItem(key) || '0', 10) || 0; } catch (e) {}
    const choice = pool[cursor % pool.length];
    try { sessionStorage.setItem(key, String(cursor + 1)); } catch (e) {}
    return choice;
}

async function specifyTerm(raw) {
    const base = raw.trim().toLowerCase();
    await ensureHistory();
    const found = await getSynAnt(base);
    let phrase = '';
    if (found.syns.length) {
        const syn = found.syns[base.length % found.syns.length];
        phrase = base.indexOf(String(syn).toLowerCase()) === -1 ? (base + ' ' + syn) : base;
    } else {
        phrase = pickAdjacent(base);
    }
    if (!phrase || phrase.toLowerCase() === base) {
        phrase = base + ' profile';
    }
    let words = clampWords(enforceMandatoryAdjacency(phrase.toLowerCase().split(/\s+/).filter(Boolean)));
    if (words.length < 2) words.push('profile');
    phrase = words.join(' ');
    rememberPhrases([base, phrase]);
    return phrase;
}

async function rewrite(mode) {
    const qEl = document.getElementById('q');
    let words = qEl.value.replace(/[_-]+/g, ' ').trim();
    if (!words) return;
    const specify = mode === 'specify' || mode === '+';
    const general = mode === 'general' || mode === '-';
    if (specify) {
        words = await specifyTerm(words);
    } else if (general) {
        const parts = words.split(/\s+/).filter(Boolean);
        if (parts.length > 1) parts.pop();
        words = parts.join(' ');
    }
    qEl.value = words;
    qEl.focus();
}
    function placeBox() {
        box.style.display = 'flex';
        box.style.left = '0';
        box.style.top = '0';
        box.style.transform = 'none';
        var pad = 12;
        var vw = window.innerWidth;
        var vh = window.innerHeight;
        var bw = box.offsetWidth;
        var bh = box.offsetHeight;
        var left = Math.max(pad, Math.min((vw - bw) / 2, vw - bw - pad));
        var top  = Math.max(pad, Math.min((vh - bh) / 2, vh - bh - pad));
        box.style.left = left + 'px';
        box.style.top  = top  + 'px';
    }
    function paintLink(node) {
        if (!web || !node || !node.uri) return;
        var sel = 'a[data-keyword="' + node.keyword.replace(/"/g, '') + '"][href="' + node.uri.replace(/"/g, '') + '"]';
        if (web.querySelector(sel)) return;
        var a = document.createElement('a');
        a.href = node.uri;
        a.textContent = node.keyword;
        a.setAttribute('data-keyword', node.keyword);
        a.setAttribute('data-log', node.log || '');
        a.setAttribute('data-source', node.source || '');
        a.setAttribute('data-back', node.back ? '1' : '0');
        web.appendChild(a);
        if (node.source) {
            var s = document.createElement('a');
            s.href = node.source;
            s.rel = 'external';
            s.setAttribute('ping', node.source + ' ' + location.origin + '/prepare?k=' + encodeURIComponent(node.keyword));
            s.textContent = node.keyword + ' source';
            s.setAttribute('data-keyword', node.keyword);
            s.setAttribute('data-log', node.log || '');
            web.appendChild(s);
        }
    }
    function crawlStep() {
        var body = new FormData();
        body.append('seek', 'crawl');
        postSeek(body).then(function (data) {
            (data.nodes || []).forEach(paintLink);
            if (data.pending) setTimeout(crawlStep, data.wait || 3000);
        }).catch(function () { setTimeout(crawlStep, 8000); });
    }
    var provTimer = null;
    prov.addEventListener('input', function () {
        fillList(prov.value);
        clearTimeout(provTimer);
        provTimer = setTimeout(function () { commitProv(); }, 700);
    });
    prov.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        commitProv().then(function (p) { if (p) q.focus(); });
    });
    box.addEventListener('click', function (e) {
        var ai = e.target.getAttribute('data-ai');
        if (ai) { e.preventDefault(); rewrite(ai); }
    });
    box.addEventListener('submit', function (e) {
        e.preventDefault();
        commitProv().then(go);
    });
    q.addEventListener('keydown', function (e) {
        if (e.key === '+') { e.preventDefault(); rewrite('specify'); }
        if (e.key === '-') { e.preventDefault(); rewrite('general'); }
    });

    function mark(e) {
        var r = host.getBoundingClientRect();
        var x = (e.clientX || (e.touches && e.touches[0] && e.touches[0].clientX)) - r.left;
        var y = (e.clientY || (e.touches && e.touches[0] && e.touches[0].clientY)) - r.top;
        if (isNaN(x) || isNaN(y)) return;
        if (aim) mouseSpeed = Math.hypot(x - aim.x, y - aim.y) / Math.max(0.016, ((e.timeStamp || Date.now()) - aim.t) / 1000);
        aim = { x: x, y: y, t: e.timeStamp || Date.now() };
    }

    function setHotFromPoint(x, y) {
        var closest = null, minDist = Infinity;
        cars.forEach(function (car) {
            var dx = x - (car.x + (car.el.offsetWidth || 80) * 0.5);
            var dy = y - (car.y + (car.el.offsetHeight || 24) * 0.5);
            var d = Math.hypot(dx, dy);
            if (d < minDist && d < AGGRO * 1.4) {
                minDist = d;
                closest = car;
            }
        });
        cars.forEach(function (car) { car.hot = (car === closest); });
        return closest;
    }

    function elementAt(x, y) {
        var el = document.elementFromPoint(x, y);
        return el && el.closest ? el.closest('.pill') : null;
    }

    window.addEventListener('pointermove', mark);
    window.addEventListener('pointerdown', mark);
    window.addEventListener('pointerleave', function () { aim = null; });

    host.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) return;
        var t = e.touches[0];
        activeTouchId = t.identifier;
        mark(e);
        var pill = elementAt(t.clientX, t.clientY);
        touchStart = { x: t.clientX, y: t.clientY, t: Date.now(), pill: pill };
        tracking = !!pill;
        if (pill) setHotFromPoint(aim.x, aim.y);
    }, { passive: true });

    host.addEventListener('touchmove', function (e) {
        if (!activeTouchId || !touchStart) return;
        for (var i = 0; i < e.touches.length; i++) {
            if (e.touches[i].identifier === activeTouchId) {
                var t = e.touches[i];
                var dx = t.clientX - touchStart.x;
                var dy = t.clientY - touchStart.y;
                if (Math.hypot(dx, dy) > TAP_THRESHOLD) {
                    tracking = true;
                    mark(e);
                    setHotFromPoint(aim.x, aim.y);
                    e.preventDefault();
                }
                break;
            }
        }
    }, { passive: false });

    host.addEventListener('touchend', function (e) {
        var still = false;
        for (var i = 0; i < e.touches.length; i++) {
            if (e.touches[i].identifier === activeTouchId) still = true;
        }
        if (still) return;

        if (touchStart && touchStart.pill) {
            var dt = Date.now() - touchStart.t;
            var dx = 0, dy = 0;
            if (e.changedTouches && e.changedTouches[0]) {
                dx = e.changedTouches[0].clientX - touchStart.x;
                dy = e.changedTouches[0].clientY - touchStart.y;
            }
            if (dt < TAP_TIME && Math.hypot(dx, dy) < TAP_THRESHOLD) {
                var target = document.elementFromPoint(touchStart.x, touchStart.y);
                var seek = target && target.closest ? target.closest('.seek') : null;
                var link = target && target.closest ? target.closest('a') : null;
                var toClick = seek || link || touchStart.pill;
                if (toClick) {
                    var click = new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window,
                        clientX: touchStart.x,
                        clientY: touchStart.y
                    });
                    toClick.dispatchEvent(click);
                }
            }
        }

        activeTouchId = null;
        tracking = false;
        touchStart = null;
        cars.forEach(function (car) { car.hot = false; });
        setTimeout(function () { if (!activeTouchId) aim = null; }, 400);
    });

    host.addEventListener('touchcancel', function () {
        activeTouchId = null;
        tracking = false;
        touchStart = null;
        cars.forEach(function (car) { car.hot = false; });
        aim = null;
    });

    fillList('');

    var seen = {};
    items.forEach(function (item) {
        if (seen[item.path]) return;
        seen[item.path] = true;
        var pill = document.createElement('div');
        pill.className = 'pill';
        var a = document.createElement('a');
        a.href = item.uri;
        a.textContent = item.label;
        a.title = item.log ? item.uri + ' | ' + item.log : item.uri;
        a.setAttribute('data-keyword', item.keyword || item.label);
        a.setAttribute('data-log', item.log || '');
        if (item.source) {
            a.setAttribute('data-source', item.source);
            a.setAttribute('ping', item.source + ' ' + location.origin + '/prepare?k=' + encodeURIComponent(item.keyword || item.label));
        }
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'seek';
        b.textContent = '⌕';
        var ang = Math.random() * Math.PI * 2, spd = 18 + Math.random() * 42;
        var car = {
            el: pill, path: item.path, uri: item.uri, log: item.log || '',
            x: Math.random() * (host.clientWidth || 800),
            y: Math.random() * (host.clientHeight || 500),
            vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd,
            heat: 0, hot: false, off: Math.random() * Math.PI * 2
        };
        b.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            q.value = item.keyword || item.label;
            var chosen = providers.filter(function (p) { return p.id === pref; })[0] || providers[0];
            prov.value = chosen ? chosen.name : '';
            placeBox();
            prov.focus();
        });
        pill.appendChild(a);
        pill.appendChild(b);
        if (item.log) {
            var log = document.createElement('span');
            log.className = 'crawl-log';
            log.hidden = true;
            log.textContent = item.log;
            pill.appendChild(log);
        }
        host.appendChild(pill);
        cars.push(car);
        pill.addEventListener('mouseenter', function () { car.hot = true; });
        pill.addEventListener('mouseleave', function () { car.hot = false; });
    });

    function frame(now) {
        var dt = Math.min(0.05, (now - last) / 1000 || 0.016);
        last = now;
        var w = host.clientWidth || 1, h = host.clientHeight || 1, caught = null;
        cars.forEach(function (car) {
            var wide = car.el.offsetWidth || 80, tall = car.el.offsetHeight || 24;
            var dist = aim ? Math.hypot(aim.x - car.x, aim.y - car.y) : Infinity;
            var near = aim && dist < AGGRO;
            if (car.hot && aim) {
                var cap = Math.max(40, mouseSpeed * 0.45);
                var dx = aim.x - wide * 0.35 - car.x, dy = aim.y - tall * 0.45 - car.y, len = Math.hypot(dx, dy) || 1;
                car.vx += (dx / len) * cap * 3 * dt;
                car.vy += (dy / len) * cap * 3 * dt;
                var sp = Math.hypot(car.vx, car.vy);
                if (sp > cap) { car.vx = car.vx / sp * cap; car.vy = car.vy / sp * cap; }
                caught = car;
            } else if (near) {
                car.vx += (aim.x + Math.cos(car.off) * 36 - car.x) * 0.35 * dt;
                car.vy += (aim.y + Math.sin(car.off) * 28 - car.y) * 0.35 * dt;
            } else {
                car.vx += (Math.random() - 0.5) * 40 * dt;
                car.vy += (Math.random() - 0.5) * 40 * dt;
            }
            var drift = Math.hypot(car.vx, car.vy), maxDrift = car.hot ? 999 : 70;
            if (drift > maxDrift) { car.vx = car.vx / drift * maxDrift; car.vy = car.vy / drift * maxDrift; }
            car.x += car.vx * dt; car.y += car.vy * dt;
            if (car.x < -wide) car.x = w;
            if (car.x > w) car.x = -wide;
            if (car.y < -tall) car.y = h;
            if (car.y > h) car.y = -tall;
            car.heat = car.hot ? car.heat + dt : Math.max(0, car.heat - dt);
            var unit = Math.min(car.heat, 8) / 8;
            car.el.style.zIndex = car.hot ? 6 : (near ? 4 : 3);
            car.el.style.transform = 'translate(' + car.x + 'px,' + car.y + 'px)';
            car.el.style.filter = 'grayscale(' + (1 - unit) + ') brightness(' + (0.75 + unit * 0.7) + ')';
            car.el.style.background = 'hsl(' + hue(car.path) + ', ' + Math.round(8 + unit * 42) + '%, ' + Math.round(96 - unit * 18) + '%)';
        });
        if (caught) caught.el.style.zIndex = 7;
        requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    setTimeout(crawlStep, 1500);
})();
