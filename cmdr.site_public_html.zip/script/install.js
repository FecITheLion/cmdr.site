if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js');
var installBtn = document.getElementById('install-app');
var deferredInstall = null;
window.addEventListener('beforeinstallprompt', function (e) {
    // Do not call preventDefault(): that suppresses the browser banner
    // unless prompt() is invoked. Keep the event so the Install button can
    // still open the prompt if the user dismisses the banner.
    deferredInstall = e;
    if (installBtn) installBtn.hidden = false;
});
if (installBtn) installBtn.addEventListener('click', function () {
    if (!deferredInstall) return;
    deferredInstall.prompt();
    deferredInstall.userChoice.then(function () {
        deferredInstall = null;
        installBtn.hidden = true;
    });
});
window.addEventListener('appinstalled', function () { if (installBtn) installBtn.hidden = true; });
