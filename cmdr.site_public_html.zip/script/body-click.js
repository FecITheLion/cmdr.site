document.body.addEventListener('click', function (e) {
    var isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
    if (isTouchDevice) return;
    if (e.target === document.body || (e.target.id === 'folderpool')) {
        window.location.href = 'https://canva.link/gwp6bpbizp78gbf';
    }
});
