    (function () {
    var k = (window.CMDR && window.CMDR.focus) || "";
    if (!k || document.getElementById('redirect-warn')) return;
    var providers = (window.CMDR && window.CMDR.providers) || [];
    var pref = localStorage.getItem('cmdr-consent') === 'accepted' ? (localStorage.getItem('cmdr-search-pref') || '') : '';
    var favored = null;
    for (var i = 0; i < providers.length; i++) {
        if (providers[i].id === pref) { favored = providers[i]; break; }
    }
    if (!favored) favored = providers[0];
    if (!favored || !favored.template) return;
    var dest = favored.template.replace(/\{term\}/gi, encodeURIComponent(k));
    var prepare = location.origin + '/prepare?k=' + encodeURIComponent(k);
    var pingVal = dest + ' ' + prepare;

    var modal = document.createElement('div');
    modal.id = 'redirect-warn';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-labelledby', 'warn-title');

    var card = document.createElement('div');
    card.className = 'card';

    var h1 = document.createElement('h1');
    h1.id = 'warn-title';
    h1.textContent = "Leaving Mister Rogers'";
    card.appendChild(h1);

    var p1 = document.createElement('p');
    var b = document.createElement('b');
    b.textContent = k;
    p1.appendChild(b);
    p1.appendChild(document.createTextNode(' search on ' + (favored.name || 'provider') + '.'));
    card.appendChild(p1);

    var p2 = document.createElement('p');
    p2.appendChild(document.createTextNode('Destination: '));
    var code = document.createElement('code');
    code.textContent = dest;
    p2.appendChild(code);
    card.appendChild(p2);

    var p3 = document.createElement('p');
    p3.textContent = 'Continue sends a ping so the destination can prepare, then opens it.';
    card.appendChild(p3);

    var p4 = document.createElement('p');
    var aGo = document.createElement('a');
    aGo.className = 'go';
    aGo.href = dest;
    aGo.setAttribute('ping', pingVal);
    aGo.rel = 'noopener noreferrer';
    aGo.textContent = 'Continue';
    p4.appendChild(aGo);
    p4.appendChild(document.createTextNode(' '));
    var aStay = document.createElement('a');
    aStay.href = location.origin + '/';
    aStay.textContent = 'Stay';
    p4.appendChild(aStay);
    card.appendChild(p4);

    modal.appendChild(card);
    document.body.appendChild(modal);
})();
